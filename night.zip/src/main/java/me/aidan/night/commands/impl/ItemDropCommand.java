package night.commands.impl;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import night.commands.Command;
import night.commands.RegisterCommand;

@RegisterCommand(
   name = "itemdrop",
   aliases = {"drop"},
   tag = "ItemDrop",
   description = "Drops items from your inventory.",
   syntax = "<all|item name>"
)
public class ItemDropCommand extends Command {
   @Override
   public List<String> getSuggestions(String[] args) {
      if (args.length != 0) {
         return List.of();
      } else {
         ArrayList<String> options = new ArrayList<>(List.of("all"));

         for (Item item : BuiltInRegistries.ITEM) {
            options.add(BuiltInRegistries.ITEM.getKey(item).getPath());
         }

         return options;
      }
   }

   @Override
   public void execute(String[] args) {
      if (args.length == 0) {
         this.messageSyntax();
      } else if (args[0].equalsIgnoreCase("all")) {
         this.dropAllItems();
      } else {
         String itemName = String.join(" ", args);
         this.dropSpecificItem(itemName);
      }
   }

   private void dropAllItems() {
      if (mc.player != null && mc.gameMode != null) {
         int containerId = mc.player.containerMenu.containerId;

         for (int invSlot = 0; invSlot < 36; invSlot++) {
            ItemStack stack = mc.player.getInventory().getItem(invSlot);
            if (!stack.isEmpty()) {
               mc.gameMode.handleContainerInput(containerId, invToHandlerSlot(invSlot), 1, ContainerInput.THROW, mc.player);
            }
         }
      }
   }

   private void dropSpecificItem(String itemName) {
      if (mc.player != null && mc.gameMode != null) {
         int containerId = mc.player.containerMenu.containerId;

         for (int invSlot = 0; invSlot < 36; invSlot++) {
            ItemStack stack = mc.player.getInventory().getItem(invSlot);
            if (!stack.isEmpty()) {
               String key = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
               String customName = stack.getHoverName().getString();
               if (key.equalsIgnoreCase(itemName) || key.substring(key.indexOf(58) + 1).equalsIgnoreCase(itemName) || customName.equalsIgnoreCase(itemName)) {
                  mc.gameMode.handleContainerInput(containerId, invToHandlerSlot(invSlot), 1, ContainerInput.THROW, mc.player);
               }
            }
         }
      }
   }

   private static int invToHandlerSlot(int invSlot) {
      return invSlot <= 8 ? 36 + invSlot : invSlot;
   }
}
