package night.commands.impl;

import java.util.ArrayList;
import java.util.List;
import night.Night;
import night.commands.Command;
import night.commands.RegisterCommand;
import night.modules.Module;
import night.utils.chat.ChatUtils;
import night.utils.input.KeyboardUtils;

@RegisterCommand(
   name = "bind",
   tag = "Bind",
   description = "Changes the toggle keybind of a module.",
   syntax = "<[module]> <[key]|reset> | <reset|list> ",
   aliases = {"b", "key", "keybind"}
)
public class BindCommand extends Command {
   @Override
   public List<String> getSuggestions(String[] args) {
      if (args.length == 0) {
         ArrayList<String> names = new ArrayList<>(this.moduleNames());
         names.add("reset");
         names.add("list");
         return names;
      } else {
         return args.length == 1 && Night.MODULE_MANAGER.getModule(args[0]) != null ? List.of("<bind>") : List.of();
      }
   }

   @Override
   public void execute(String[] args) {
      if (args.length == 2) {
         Module module = Night.MODULE_MANAGER.getModule(args[0]);
         if (module == null) {
            Night.CHAT_MANAGER.tagged("Could not find the module specified.", this.getTag(), this.getName());
            return;
         }

         if (args[1].equalsIgnoreCase("reset")) {
            module.setBind(0);
            Night.CHAT_MANAGER
               .tagged(
                  "Successfully reset the toggle keybind of the " + ChatUtils.getPrimary() + module.getName() + ChatUtils.getSecondary() + " module.",
                  this.getTag(),
                  this.getName()
               );
         } else {
            module.setBind(KeyboardUtils.getKeyNumber(args[1]));
            Night.CHAT_MANAGER
               .tagged(
                  "Successfully bound the "
                     + ChatUtils.getPrimary()
                     + module.getName()
                     + ChatUtils.getSecondary()
                     + " module to the "
                     + ChatUtils.getPrimary()
                     + KeyboardUtils.getKeyName(module.getBind())
                     + ChatUtils.getSecondary()
                     + " key.",
                  this.getTag(),
                  this.getName()
               );
         }
      } else if (args.length == 1) {
         String var9 = args[0].toLowerCase();
         switch (var9) {
            case "reset":
               Night.MODULE_MANAGER.getModules().forEach(m -> m.bind.resetValue());
               Night.CHAT_MANAGER.tagged("Successfully reset every module's toggle keybind.", this.getTag(), this.getName());
               break;
            case "list":
               List<Module> modules = Night.MODULE_MANAGER.getModules().stream().filter(m -> m.getBind() != 0).toList();
               if (modules.isEmpty()) {
                  Night.CHAT_MANAGER.tagged("There are currently no bound modules.", this.getTag(), this.getName() + "-list");
               } else {
                  StringBuilder builder = new StringBuilder();
                  int index = 0;

                  for (Module modulex : modules) {
                     StringBuilder var10000 = builder.append(ChatUtils.getSecondary())
                        .append(modulex.getName())
                        .append(ChatUtils.getPrimary())
                        .append(" [")
                        .append(ChatUtils.getSecondary())
                        .append(KeyboardUtils.getKeyName(modulex.getBind()).toUpperCase())
                        .append(ChatUtils.getPrimary())
                        .append("]");
                     index++;
                     var10000.append(index == modules.size() ? "" : ", ");
                  }

                  Night.CHAT_MANAGER
                     .message(
                        "Bound Modules "
                           + ChatUtils.getPrimary()
                           + "["
                           + ChatUtils.getSecondary()
                           + modules.size()
                           + ChatUtils.getPrimary()
                           + "]: "
                           + ChatUtils.getSecondary()
                           + builder,
                        this.getName() + "-list"
                     );
               }
               break;
            default:
               this.messageSyntax();
         }
      } else {
         this.messageSyntax();
      }
   }
}
