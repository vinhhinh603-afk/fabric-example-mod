package night.core;

import java.io.IOException;
import java.io.InputStream;

final class PayloadClassLoader extends ClassLoader {
   private final ClassLoader jarResourceLoader;
   private final byte[] key;

   PayloadClassLoader(ClassLoader parent, ClassLoader jarResourceLoader, byte[] key) {
      super(parent);
      this.jarResourceLoader = jarResourceLoader;
      this.key = key;
   }

   @Override
   protected Class<?> findClass(String name) throws ClassNotFoundException {
      String resourcePath = name.replace('.', '/') + ".enc";

      try {
         Class var6;
         try (InputStream in = this.jarResourceLoader.getResourceAsStream(resourcePath)) {
            if (in == null) {
               throw new ClassNotFoundException(name);
            }

            byte[] encrypted = in.readAllBytes();
            byte[] decrypted = AesCrypto.decrypt(encrypted, this.key);
            var6 = this.defineClass(name, decrypted, 0, decrypted.length);
         }

         return var6;
      } catch (IOException var9) {
         throw new ClassNotFoundException(name, var9);
      }
   }
}
