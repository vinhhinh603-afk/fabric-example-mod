package night.managers;

import java.util.ArrayList;
import java.util.Objects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientConnectEvent;
import night.events.impl.PlayerDeathEvent;
import night.events.impl.TargetDeathEvent;
import night.events.impl.TickEvent;
import night.modules.impl.combat.AutoCrystalModule;
import night.modules.impl.combat.KillAuraModule;
import night.utils.IMinecraft;

public class TargetManager implements IMinecraft {
   private final ArrayList<TargetManager.Target> targets = new ArrayList<>();

   public TargetManager() {
      Night.EVENT_HANDLER.subscribe(this);
   }

   @SubscribeEvent
   public void onClientConnect(ClientConnectEvent event) {
      this.targets.clear();
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null) {
         Player caTarget = Night.MODULE_MANAGER.getModule(AutoCrystalModule.class).getTarget();
         Entity kaTarget = Night.MODULE_MANAGER.getModule(KillAuraModule.class).target;
         ArrayList<TargetManager.Target> arrayList = this.targets;
         synchronized (arrayList) {
            this.targets.removeIf(t -> System.currentTimeMillis() - t.time > 15000L);
            if (caTarget != null) {
               this.targets.add(new TargetManager.Target(this, caTarget));
            }

            if (kaTarget instanceof Player) {
               this.targets.add(new TargetManager.Target(this, (Player)kaTarget));
            }
         }
      }
   }

   @SubscribeEvent
   public void onPlayerDeath(PlayerDeathEvent event) {
      if (mc.player != null && mc.level != null && this.isTarget(event.getPlayer())) {
         ArrayList<TargetManager.Target> arrayList = this.targets;
         synchronized (arrayList) {
            Night.EVENT_HANDLER.post(new TargetDeathEvent(event.getPlayer()));
            this.targets.remove(this.getTarget(event.getPlayer()));
         }
      }
   }

   private TargetManager.Target getTarget(Player player) {
      for (TargetManager.Target target : this.targets) {
         if (target.player == player) {
            return target;
         }
      }

      return null;
   }

   public boolean isTarget(Player player) {
      for (TargetManager.Target target : this.targets) {
         if (target.player == player) {
            return true;
         }
      }

      return false;
   }

   private class Target {
      private final Player player;
      private final long time;

      public Target(TargetManager targetManager, Player player) {
         Objects.requireNonNull(TargetManager.this);
         super();
         Objects.requireNonNull(targetManager);
         this.player = player;
         this.time = System.currentTimeMillis();
      }
   }
}
