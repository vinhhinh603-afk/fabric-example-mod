package night.managers;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.platform.NativeImage.Format;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.imageio.ImageIO;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import night.Night;
import night.utils.graphics.CustomImageTexture;

public class ImageManager {
   public static final Path IMAGES_DIR = Paths.get("xnhau", "images");
   public static final Identifier CUSTOM_IMAGE_ID = Identifier.fromNamespaceAndPath("night", "textures/effect/custom_image.png");
   public static final Identifier CUSTOM_IMAGE_ID_LEGACY = Identifier.fromNamespaceAndPath("night", "textures/custom_image.png");
   private final Map<String, ImageManager.ImageEntry> cache = new ConcurrentHashMap<>();
   private String currentImageName = "None";

   public ImageManager() {
      this.ensureDirectoryExists();

      try {
         Minecraft.getInstance().getTextureManager().register(CUSTOM_IMAGE_ID, CustomImageTexture.INSTANCE);
         Minecraft.getInstance().getTextureManager().register(CUSTOM_IMAGE_ID_LEGACY, CustomImageTexture.INSTANCE);
      } catch (Throwable var2) {
      }

      String saved = findSavedActiveImage();
      if (saved != null && !saved.equalsIgnoreCase("None") && !saved.isEmpty()) {
         this.setCurrentActiveImage(saved);
      } else {
         this.initDefaultTexture();
      }
   }

   public static String findSavedActiveImage() {
      try {
         String currentCfg = "default";
         Path generalPath = Paths.get("xnhau", "General.json");
         if (Files.exists(generalPath)) {
            try (InputStream stream2 = Files.newInputStream(generalPath)) {
               JsonObject obj = JsonParser.parseReader(new InputStreamReader(stream2)).getAsJsonObject();
               if (obj.has("Config")) {
                  currentCfg = obj.get("Config").getAsString();
               }
            }
         }

         Path configPath;
         if (!Files.exists(configPath = Paths.get("xnhau", "Configs", currentCfg + ".json"))) {
            configPath = Paths.get("xnhau", "Configs", "default.json");
         }

         if (!Files.exists(configPath)) {
            return "None";
         } else {
            String var9;
            try (InputStream stream = Files.newInputStream(configPath)) {
               JsonObject obj = JsonParser.parseReader(new InputStreamReader(stream)).getAsJsonObject();
               if (!obj.has("Shaders")) {
                  return "None";
               }

               JsonObject shaders = obj.getAsJsonObject("Shaders");
               if (!shaders.has("Settings")) {
                  return "None";
               }

               JsonObject settings = shaders.getAsJsonObject("Settings");
               if (!settings.has("Image")) {
                  return "None";
               }

               String imgName = settings.get("Image").getAsString();
               if (imgName == null) {
                  return "None";
               }

               if (imgName.isEmpty()) {
                  return "None";
               }

               if (imgName.equalsIgnoreCase("None")) {
                  return "None";
               }

               var9 = imgName;
            }

            return var9;
         }
      } catch (Throwable var14) {
         Night.LOGGER.debug("Could not pre-read saved image config: {}", var14.getMessage());
         return "None";
      }
   }

   public void ensureDirectoryExists() {
      try {
         if (!Files.exists(IMAGES_DIR)) {
            Files.createDirectories(IMAGES_DIR);
         }
      } catch (Exception var2) {
         Night.LOGGER.error("Failed to create images directory", var2);
      }
   }

   public static NativeImage loadNativeImage(File file) throws Exception {
      BufferedImage bImg = ImageIO.read(file);
      if (bImg == null) {
         throw new Exception("ImageIO failed to read image file: " + file.getName());
      } else {
         NativeImage nativeImage = new NativeImage(Format.RGBA, bImg.getWidth(), bImg.getHeight(), false);

         for (int y = 0; y < bImg.getHeight(); y++) {
            for (int x = 0; x < bImg.getWidth(); x++) {
               nativeImage.setPixel(x, y, bImg.getRGB(x, y));
            }
         }

         return nativeImage;
      }
   }

   public static NativeImage loadNativeImage(InputStream stream) throws Exception {
      BufferedImage bImg = ImageIO.read(stream);
      if (bImg == null) {
         throw new Exception("ImageIO failed to read image stream");
      } else {
         NativeImage nativeImage = new NativeImage(Format.RGBA, bImg.getWidth(), bImg.getHeight(), false);

         for (int y = 0; y < bImg.getHeight(); y++) {
            for (int x = 0; x < bImg.getWidth(); x++) {
               nativeImage.setPixel(x, y, bImg.getRGB(x, y));
            }
         }

         return nativeImage;
      }
   }

   private void initDefaultTexture() {
      try {
         NativeImage image = new NativeImage(1, 1, false);
         image.setPixel(0, 0, 0);
         CustomImageTexture.INSTANCE.update(image);
      } catch (Throwable var2) {
         Night.LOGGER.warn("Failed to load default custom_image fallback", var2);
      }
   }

   public static File resolveImageFile(String name) {
      if (name != null && !name.isEmpty() && !name.equalsIgnoreCase("None")) {
         ArrayList<Path> dirs = new ArrayList<>();
         dirs.add(IMAGES_DIR);
         dirs.add(Paths.get("xnhau", "Images"));
         dirs.add(Paths.get("xnhau", "images"));
         dirs.add(Paths.get("xnhau", "Images"));
         dirs.add(Paths.get("night", "images"));

         try {
            Path gameDir = FabricLoader.getInstance().getGameDir();
            dirs.add(gameDir.resolve("xnhau").resolve("images"));
            dirs.add(gameDir.resolve("xnhau").resolve("Images"));
            dirs.add(gameDir.resolve("xnhau").resolve("images"));
         } catch (Throwable var5) {
         }

         for (Path d : dirs) {
            File f = d.resolve(name).toFile();
            if (f.exists() && f.isFile()) {
               return f;
            }
         }

         return IMAGES_DIR.resolve(name).toFile();
      } else {
         return null;
      }
   }

   public List<File> getImageFiles() {
      this.ensureDirectoryExists();
      LinkedHashMap<String, File> unique = new LinkedHashMap<>();
      ArrayList<Path> dirs = new ArrayList<>();
      dirs.add(IMAGES_DIR);
      dirs.add(Paths.get("xnhau", "Images"));
      dirs.add(Paths.get("xnhau", "images"));

      try {
         Path gameDir = FabricLoader.getInstance().getGameDir();
         dirs.add(gameDir.resolve("xnhau").resolve("images"));
         dirs.add(gameDir.resolve("xnhau").resolve("Images"));
      } catch (Throwable var11) {
      }

      for (Path d : dirs) {
         File dir = d.toFile();
         File[] files;
         if (dir.exists() && dir.isDirectory() && (files = dir.listFiles((dirFile, name) -> {
            String lower = name.toLowerCase();
            return lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".bmp") || lower.endsWith(".webp");
         })) != null) {
            for (File f : files) {
               unique.putIfAbsent(f.getName(), f);
            }
         }
      }

      ArrayList<File> result = new ArrayList<>(unique.values());
      result.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
      return result;
   }

   public ImageManager.ImageEntry getImageEntry(String name) {
      if (name != null && !name.isEmpty() && !name.equalsIgnoreCase("None")) {
         if (this.cache.containsKey(name)) {
            ImageManager.ImageEntry cached = this.cache.get(name);
            if (cached.file.exists()) {
               return cached;
            }

            cached.close();
            this.cache.remove(name);
         }

         File file;
         if ((file = resolveImageFile(name)) != null && file.exists() && file.isFile()) {
            try {
               NativeImage nativeImage = loadNativeImage(file);
               Identifier id = Identifier.fromNamespaceAndPath("night", "preview_" + Math.abs(name.hashCode()) + "_" + System.currentTimeMillis());
               DynamicTexture texture = new DynamicTexture(() -> "night/" + name, nativeImage);
               texture.upload();
               Minecraft.getInstance().getTextureManager().register(id, texture);
               ImageManager.ImageEntry entry = new ImageManager.ImageEntry(name, file, id, texture, nativeImage.getWidth(), nativeImage.getHeight());
               this.cache.put(name, entry);
               return entry;
            } catch (Throwable var7) {
               Night.LOGGER.error("Failed to load image: " + name, var7);
               return null;
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   public void setCurrentActiveImage(String name) {
      String string = this.currentImageName = name != null ? name : "None";
      if (!this.currentImageName.equalsIgnoreCase("None") && !this.currentImageName.isEmpty()) {
         File file = resolveImageFile(this.currentImageName);
         if (file != null && file.exists()) {
            try {
               NativeImage nativeImage = loadNativeImage(file);
               CustomImageTexture.INSTANCE.update(nativeImage);

               try {
                  Minecraft.getInstance().getTextureManager().register(CUSTOM_IMAGE_ID, CustomImageTexture.INSTANCE);
                  Minecraft.getInstance().getTextureManager().register(CUSTOM_IMAGE_ID_LEGACY, CustomImageTexture.INSTANCE);
               } catch (Throwable var6) {
               }
            } catch (Throwable var7) {
               Night.LOGGER.error("Failed to set active custom image: " + name, var7);
               this.initDefaultTexture();
            }
         } else {
            this.initDefaultTexture();
         }
      } else {
         this.initDefaultTexture();
      }
   }

   public String getCurrentImageName() {
      return this.currentImageName;
   }

   public static class ImageEntry {
      public final String name;
      public final File file;
      public final Identifier identifier;
      public final DynamicTexture texture;
      public final int width;
      public final int height;

      public ImageEntry(String name, File file, Identifier identifier, DynamicTexture texture, int width, int height) {
         this.name = name;
         this.file = file;
         this.identifier = identifier;
         this.texture = texture;
         this.width = width;
         this.height = height;
      }

      public void close() {
         try {
            if (this.texture != null) {
               this.texture.close();
            }

            if (this.identifier != null) {
               Minecraft.getInstance().getTextureManager().release(this.identifier);
            }
         } catch (Throwable var2) {
         }
      }
   }
}
