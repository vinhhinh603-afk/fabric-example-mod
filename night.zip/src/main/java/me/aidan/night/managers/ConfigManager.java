package night.managers;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Collections;
import java.util.StringJoiner;
import java.util.stream.Stream;
import lombok.Generated;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.modules.Module;
import night.modules.impl.core.PingBypassModule;
import night.modules.impl.miscellaneous.FakePlayerModule;
import night.pingbypass.PingBypassFlags;
import night.settings.Setting;
import night.settings.impl.BindSetting;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ImageSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.PositionSetting;
import night.settings.impl.StringSetting;
import night.settings.impl.WhitelistSetting;
import night.utils.minecraft.IdentifierUtils;
import night.utils.system.FileUtils;

public class ConfigManager {
   private String currentConfig = "default";
   private boolean loadingConfig = false;

   public ConfigManager() {
      this.loadConfig();
      Runtime.getRuntime().addShutdownHook(new Thread(this::saveConfig));
   }

   public void loadConfig() {
      try {
         this.migrateOldConfig();
         FileUtils.createDirectory("xnhau");
         FileUtils.createDirectory("Night/Configs");
         FileUtils.createDirectory("Night/Client");
         FileUtils.createDirectory("Night/Modules");
         FileUtils.createDirectory("Night/Binds");
         FileUtils.createDirectory("Night/Visuals");
         FileUtils.createDirectory("Night/GlobalConfigs");
         this.loadGeneral();
         this.loadWaypoints();
         this.loadModules(this.currentConfig);
      } catch (Exception var2) {
         Night.LOGGER.error("Failed to load the client's configuration!", var2);
         if (Night.CHAT_MANAGER != null) {
            Night.CHAT_MANAGER.await("The configuration has not been loaded properly. Read the stacktrace for more information.");
         }
      }
   }

   private void migrateOldConfig() {
      try {
         Path oldDir = Paths.get("EUClient");
         Path newDir = Paths.get("xnhau");
         if (Files.exists(oldDir) && (!Files.exists(newDir) || !Files.exists(newDir.resolve("Configs")))) {
            Night.LOGGER.info("Migrating configuration from EUClient to xnhau...");
            copyDirectory(oldDir, newDir);
         }
      } catch (Exception var3) {
         Night.LOGGER.warn("Failed to migrate old EUClient configuration: {}", var3.getMessage());
      }
   }

   private static void copyDirectory(Path source, Path target) throws IOException {
      try (Stream<Path> stream = Files.walk(source)) {
         stream.forEach(src -> {
            try {
               Path dest = target.resolve(source.relativize(src));
               if (Files.isDirectory(src)) {
                  if (!Files.exists(dest)) {
                     Files.createDirectories(dest);
                  }
               } else if (!Files.exists(dest)) {
                  if (dest.getParent() != null && !Files.exists(dest.getParent())) {
                     Files.createDirectories(dest.getParent());
                  }

                  Files.copy(src, dest, StandardCopyOption.COPY_ATTRIBUTES);
               }
            } catch (IOException var4) {
               Night.LOGGER.warn("Could not copy config file {}: {}", src, var4.getMessage());
            }
         });
      }
   }

   public void saveConfig() {
      try {
         FileUtils.createDirectory("xnhau");
         FileUtils.createDirectory("Night/Configs");
         FileUtils.createDirectory("Night/Client");
         FileUtils.createDirectory("Night/Modules");
         FileUtils.createDirectory("Night/Binds");
         FileUtils.createDirectory("Night/Visuals");
         FileUtils.createDirectory("Night/GlobalConfigs");
         this.saveGeneral();
         this.saveWaypoints();
         this.saveModules(this.currentConfig);
      } catch (IOException var2) {
         Night.LOGGER.error("Failed to save the client's configuration!", var2);
      }
   }

   public void loadWaypoints() throws IOException {
      if (FileUtils.fileExists("Night/Waypoints.json")) {
         InputStream stream = Files.newInputStream(Paths.get("Night/Waypoints.json"));

         try {
            JsonObject configObject;
            try {
               configObject = JsonParser.parseReader(new InputStreamReader(stream)).getAsJsonObject();
            } catch (IllegalStateException var9) {
               Night.LOGGER.error("Failed to load the client's Waypoint configuration!", var9);
               Night.CHAT_MANAGER.await("The Waypoint configuration has not been loaded properly. Read the stacktrace for more information.");
               if (Collections.singletonList(stream).get(0) != null) {
                  stream.close();
               }

               return;
            }

            if (configObject.has("Waypoints")) {
               for (JsonElement element : configObject.get("Waypoints").getAsJsonArray()) {
                  String[] args = element.getAsString().split(":");
                  if (!Night.WAYPOINT_MANAGER.contains(args[0])) {
                     Night.WAYPOINT_MANAGER
                        .add(args[0], new Vec3(Integer.parseInt(args[1]), Integer.parseInt(args[2]), Integer.parseInt(args[3])), args[4], args[5]);
                  }
               }
            }
         } finally {
            if (Collections.singletonList(stream).get(0) != null) {
               stream.close();
            }
         }
      }
   }

   public void loadGeneral() throws IOException {
      if (FileUtils.fileExists("Night/General.json")) {
         InputStream stream = Files.newInputStream(Paths.get("Night/General.json"));

         try {
            JsonElement parsed = JsonParser.parseReader(new InputStreamReader(stream));
            if (parsed == null || !parsed.isJsonObject()) {
               Night.LOGGER.warn("General.json is empty or invalid JSON.");
            } else {
               JsonObject configObject;
               try {
                  configObject = parsed.getAsJsonObject();
               } catch (Exception var14) {
                  Night.LOGGER.error("Failed to load the client's General configuration!", var14);
                  if (Night.CHAT_MANAGER != null) {
                     Night.CHAT_MANAGER.await("The General configuration has not been loaded properly. Read the stacktrace for more information.");
                  }

                  return;
               }

               if (configObject.has("Config")) {
                  this.currentConfig = configObject.get("Config").getAsString();
               }

               if (configObject.has("Prefix") && Night.COMMAND_MANAGER != null) {
                  Night.COMMAND_MANAGER.setPrefix(configObject.get("Prefix").getAsString());
               }

               if (configObject.has("Friends") && Night.FRIEND_MANAGER != null) {
                  for (JsonElement element : configObject.get("Friends").getAsJsonArray()) {
                     if (!Night.FRIEND_MANAGER.contains(element.getAsString())) {
                        Night.FRIEND_MANAGER.add(element.getAsString());
                     }
                  }
               }

               if (configObject.has("Macros") && Night.MACRO_MANAGER != null) {
                  for (JsonElement elementx : configObject.get("Macros").getAsJsonArray()) {
                     try {
                        String[] split = elementx.getAsString().split(":", 2);
                        if (split.length > 1) {
                           int key = Integer.parseInt(split[0]);
                           String message = split[1];
                           Night.MACRO_MANAGER.add(message, key);
                        }
                     } catch (NumberFormatException var13) {
                        Night.LOGGER.error("Failed to load the " + elementx.getAsString() + " macro!", var13);
                        if (Night.CHAT_MANAGER != null) {
                           Night.CHAT_MANAGER.await("The " + elementx.getAsString() + " macro has failed to load. Read the stacktrace for more information.");
                        }
                     }
                  }
               }
            }
         } finally {
            if (Collections.singletonList(stream).get(0) != null) {
               stream.close();
            }
         }
      }
   }

   public void saveGeneral() throws IOException {
      FileUtils.resetFile("Night/General.json");
      JsonObject configObject = new JsonObject();
      configObject.add("Config", new JsonPrimitive(this.currentConfig));
      configObject.add("Prefix", new JsonPrimitive(Night.COMMAND_MANAGER.getPrefix()));
      JsonArray friendsArray = new JsonArray();
      Night.FRIEND_MANAGER.getFriends().forEach(arg_0 -> friendsArray.add(arg_0));
      configObject.add("Friends", friendsArray);
      JsonArray macroArray = new JsonArray();
      Night.MACRO_MANAGER.getMacros().forEach((key, value) -> macroArray.add(value + ":" + key));
      configObject.add("Macros", macroArray);
      OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream("Night/General.json"), StandardCharsets.UTF_8);

      try {
         writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(JsonParser.parseString(configObject.toString())));
      } finally {
         if (Collections.singletonList(writer).get(0) != null) {
            writer.close();
         }
      }
   }

   public void saveWaypoints() throws IOException {
      FileUtils.resetFile("Night/Waypoints.json");
      JsonObject configObject = new JsonObject();
      JsonArray waypointArray = new JsonArray();

      for (WaypointManager.Waypoint waypoint : Night.WAYPOINT_MANAGER.getWaypoints()) {
         waypointArray.add(
            waypoint.getName()
               + ":"
               + (int)waypoint.getPos().x
               + ":"
               + (int)waypoint.getPos().y
               + ":"
               + (int)waypoint.getPos().z
               + ":"
               + waypoint.getDimension()
               + ":"
               + waypoint.getServer()
         );
      }

      configObject.add("Waypoints", waypointArray);
      OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream("Night/Waypoints.json"), StandardCharsets.UTF_8);

      try {
         writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(JsonParser.parseString(configObject.toString())));
      } finally {
         if (Collections.singletonList(writer).get(0) != null) {
            writer.close();
         }
      }
   }

   public void loadModules(String config) throws IOException {
      if (FileUtils.fileExists("Night/Configs/" + config + ".json")) {
         InputStream stream = Files.newInputStream(Paths.get("Night/Configs/" + config + ".json"));

         try {
            JsonElement parsed = JsonParser.parseReader(new InputStreamReader(stream));
            if (parsed == null || !parsed.isJsonObject()) {
               Night.LOGGER.warn("Module configuration is empty or invalid JSON: {}", config);
            } else {
               JsonObject configObject;
               try {
                  configObject = parsed.getAsJsonObject();
               } catch (Exception var19) {
                  Night.LOGGER.error("Failed to load the client's Module configuration!", var19);
                  if (Night.CHAT_MANAGER != null) {
                     Night.CHAT_MANAGER.await("The configuration for the Modules has not been loaded properly. Read the stacktrace for more information.");
                  }

                  return;
               }

               if (configObject.has("Modules")) {
                  JsonObject modulesObject = configObject.get("Modules").getAsJsonObject();
                  this.loadingConfig = true;

                  try {
                     this.loadModulesInner(modulesObject);
                  } finally {
                     this.loadingConfig = false;
                  }

                  this.currentConfig = config;

                  try {
                     this.saveGeneral();
                  } catch (IOException var17) {
                  }

                  PingBypassModule pbModule;
                  if (PingBypassFlags.proxyForwardingActive
                     && Night.PINGBYPASS_CONFIG != null
                     && !Night.PINGBYPASS_CONFIG.isServer()
                     && (pbModule = Night.MODULE_MANAGER.getModule(PingBypassModule.class)) != null
                     && pbModule.isToggled()) {
                     pbModule.syncAllSettingsToProxy();
                  }
               }
            }
         } finally {
            if (Collections.singletonList(stream).get(0) != null) {
               stream.close();
            }
         }
      }
   }

   private void loadModulesInner(JsonObject modulesObject) {
      for (Module module : Night.MODULE_MANAGER.getModules()) {
         if (!modulesObject.has(module.getName())) {
            module.setToggled(false);
            module.resetValues();
         } else {
            this.applyModuleJson(module, modulesObject.get(module.getName()).getAsJsonObject());
         }
      }
   }

   public void applyModuleJson(Module module, JsonObject moduleObject) {
      this.applyModuleJson(module, moduleObject, true);
   }

   public void applyModuleJson(Module module, JsonObject moduleObject, boolean includeBinds) {
      boolean toggled = moduleObject.has("Status") && moduleObject.get("Status").getAsBoolean();
      if (!moduleObject.has("Settings")) {
         if (includeBinds) {
            module.resetValues();
         }

         module.setToggled(toggled, false);
      } else {
         JsonObject settingsObject = moduleObject.get("Settings").getAsJsonObject();

         for (Setting uncastedSetting : module.getSettings()) {
            if (includeBinds || !(uncastedSetting instanceof BindSetting)) {
               JsonElement valueObject = settingsObject.get(uncastedSetting.getName());
               if (valueObject != null && valueObject.isJsonPrimitive()) {
                  switch (uncastedSetting) {
                     case BooleanSetting setting:
                        if (valueObject.getAsJsonPrimitive().isBoolean()) {
                           setting.setValue(valueObject.getAsBoolean());
                        } else {
                           setting.resetValue();
                        }
                        break;
                     case NumberSetting settingx:
                        if (valueObject.getAsJsonPrimitive().isNumber()) {
                           settingx.setValue(valueObject.getAsNumber());
                        } else {
                           settingx.resetValue();
                        }
                        break;
                     case ModeSetting settingxx:
                        settingxx.setValue(valueObject.getAsString());
                        break;
                     case StringSetting settingxxx:
                        String str = valueObject.getAsString();
                        if (str != null && str.equalsIgnoreCase("EUClient")) {
                           str = "xnhau";
                        }

                        settingxxx.setValue(str);
                        break;
                     case ImageSetting settingxxxx:
                        settingxxxx.setValue(valueObject.getAsString());
                        if (Night.IMAGE_MANAGER != null) {
                           Night.IMAGE_MANAGER.setCurrentActiveImage(valueObject.getAsString());
                        }
                        break;
                     case BindSetting settingxxxxx: {
                        if (valueObject.isJsonPrimitive() && valueObject.getAsJsonPrimitive().isNumber()) {
                           settingxxxxx.setValue(valueObject.getAsInt());
                        } else {
                           String[] dataxx = valueObject.getAsString().split(",", 2);
                           settingxxxxx.setValue(Integer.parseInt(dataxx[0]));
                           if (dataxx.length > 1) {
                              settingxxxxx.setMode(dataxx[1]);
                           }
                        }
                        break;
                     }
                     case ColorSetting settingxxxxxx:
                        String[] datax = valueObject.getAsString().split(",");
                        if (datax.length == 6) {
                           settingxxxxxx.setColor(
                              new Color(
                                 Math.clamp((long)Integer.parseInt(datax[0]), 0, 255),
                                 Math.clamp((long)Integer.parseInt(datax[1]), 0, 255),
                                 Math.clamp((long)Integer.parseInt(datax[2]), 0, 255),
                                 Math.clamp((long)Integer.parseInt(datax[3]), 0, 255)
                              )
                           );
                           settingxxxxxx.setSync(Boolean.parseBoolean(datax[4]));
                           settingxxxxxx.setRainbow(Boolean.parseBoolean(datax[5]));
                        }
                        break;
                     case PositionSetting settingxxxxxxx:
                        String[] data = valueObject.getAsString().split(",");
                        if (data.length == 2) {
                           settingxxxxxxx.set(Float.parseFloat(data[0]), Float.parseFloat(data[1]));
                        }
                        break;
                     case WhitelistSetting var421: {
                        WhitelistSetting var42x = (WhitelistSetting)uncastedSetting;
                        WhitelistSetting settingxxxxxxxx = (WhitelistSetting)uncastedSetting;
                        settingxxxxxxxx.clear();
                        String[] dataxx = valueObject.getAsString().split(",");
                        if (dataxx.length != 0) {
                           for (String object : dataxx) {
                              if (settingxxxxxxxx.getType() == WhitelistSetting.Type.ITEMS) {
                                 Item item = IdentifierUtils.getItem(object);
                                 if (item != null) {
                                    settingxxxxxxxx.add(item);
                                 }
                              } else if (settingxxxxxxxx.getType() == WhitelistSetting.Type.BLOCKS) {
                                 Block block = IdentifierUtils.getBlock(object);
                                 if (block != null) {
                                    settingxxxxxxxx.add(block);
                                 }
                              }
                           }
                        }
                        break;
                     }
                     default:
                  }
               } else {
                  switch (uncastedSetting) {
                     case BooleanSetting settingxxxxxxxx:
                        settingxxxxxxxx.resetValue();
                        break;
                     case NumberSetting settingxxxxxxxxx:
                        settingxxxxxxxxx.resetValue();
                        break;
                     case ModeSetting settingxxxxxxxxxx:
                        settingxxxxxxxxxx.resetValue();
                        break;
                     case StringSetting settingxxxxxxxxxxx:
                        settingxxxxxxxxxxx.resetValue();
                        break;
                     case ImageSetting settingxxxxxxxxxxxx:
                        settingxxxxxxxxxxxx.resetValue();
                        break;
                     case BindSetting settingxxxxxxxxxxxxx:
                        settingxxxxxxxxxxxxx.resetValue();
                        break;
                     case ColorSetting settingxxxxxxxxxxxxxx:
                        settingxxxxxxxxxxxxxx.resetValue();
                        break;
                     case WhitelistSetting settingxxxxxxxxxxxxxxx:
                        settingxxxxxxxxxxxxxxx.clear();
                        break;
                     case PositionSetting settingxxxxxxxxxxxxxxxx:
                        settingxxxxxxxxxxxxxxxx.resetValue();
                        break;
                     default:
                  }
               }
            }
         }

         module.setToggled(toggled, false);
      }
   }

   public void saveModules(String config) throws IOException {
      FileUtils.resetFile("Night/Configs/" + config + ".json");
      JsonObject configObject = new JsonObject();
      configObject.add("Config", new JsonPrimitive(config));
      JsonObject modulesObject = new JsonObject();

      for (Module module : Night.MODULE_MANAGER.getModules()) {
         JsonObject moduleObject = this.serializeModuleJson(module);
         if (module instanceof FakePlayerModule) {
            moduleObject.add("Status", new JsonPrimitive(false));
         }

         modulesObject.add(module.getName(), moduleObject);
      }

      configObject.add("Modules", modulesObject);
      OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream("Night/Configs/" + config + ".json"), StandardCharsets.UTF_8);

      try {
         writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(JsonParser.parseString(configObject.toString())));
         this.currentConfig = config;

         try {
            this.saveGeneral();
         } catch (IOException var10) {
         }
      } finally {
         if (Collections.singletonList(writer).get(0) != null) {
            writer.close();
         }
      }
   }

   public JsonObject serializeModuleJson(Module module) {
      return this.serializeModuleJson(module, true);
   }

   public JsonObject serializeModuleJson(Module module, boolean includeBinds) {
      JsonObject moduleObject = new JsonObject();
      moduleObject.add("Status", new JsonPrimitive(module.isToggled()));
      JsonObject settingsObject = new JsonObject();

      for (Setting uncastedSetting : module.getSettings()) {
         if (includeBinds || !(uncastedSetting instanceof BindSetting)) {
            switch (uncastedSetting) {
               case BooleanSetting setting:
                  settingsObject.add(setting.getName(), new JsonPrimitive(setting.getValue()));
                  break;
               case NumberSetting settingx:
                  settingsObject.add(settingx.getName(), new JsonPrimitive(settingx.getValue()));
                  break;
               case ModeSetting settingxx:
                  settingsObject.add(settingxx.getName(), new JsonPrimitive(settingxx.getValue()));
                  break;
               case StringSetting settingxxx:
                  settingsObject.add(settingxxx.getName(), new JsonPrimitive(settingxxx.getValue()));
                  break;
               case ImageSetting settingxxxx:
                  settingsObject.add(settingxxxx.getName(), new JsonPrimitive(settingxxxx.getValue()));
                  break;
               case BindSetting settingxxxxx:
                  settingsObject.add(settingxxxxx.getName(), new JsonPrimitive(settingxxxxx.getValue() + "," + settingxxxxx.getMode()));
                  break;
               case ColorSetting settingxxxxxx:
                  settingsObject.add(
                     settingxxxxxx.getName(),
                     new JsonPrimitive(
                        settingxxxxxx.getValue().getColor().getRed()
                           + ","
                           + settingxxxxxx.getValue().getColor().getGreen()
                           + ","
                           + settingxxxxxx.getValue().getColor().getBlue()
                           + ","
                           + settingxxxxxx.getValue().getColor().getAlpha()
                           + ","
                           + settingxxxxxx.isSync()
                           + ","
                           + settingxxxxxx.isRainbow()
                     )
                  );
                  break;
               case WhitelistSetting settingxxxxxxx:
                  StringJoiner objects = new StringJoiner(",");

                  for (String id : settingxxxxxxx.getWhitelistIds()) {
                     objects.add(id);
                  }

                  settingsObject.add(settingxxxxxxx.getName(), new JsonPrimitive(objects.toString()));
                  break;
               case PositionSetting var23:
                  PositionSetting var21 = (PositionSetting)uncastedSetting;
                  PositionSetting settingxxxxxxxx = (PositionSetting)uncastedSetting;
                  settingsObject.add(settingxxxxxxxx.getName(), new JsonPrimitive(settingxxxxxxxx.getX() + "," + settingxxxxxxxx.getY()));
                  break;
               default:
            }
         }
      }

      moduleObject.add("Settings", settingsObject);
      return moduleObject;
   }

   @Generated
   public String getCurrentConfig() {
      return this.currentConfig;
   }

   @Generated
   public boolean isLoadingConfig() {
      return this.loadingConfig;
   }

   @Generated
   public void setCurrentConfig(String currentConfig) {
      this.currentConfig = currentConfig;
   }

   @Generated
   public void setLoadingConfig(boolean loadingConfig) {
      this.loadingConfig = loadingConfig;
   }
}
