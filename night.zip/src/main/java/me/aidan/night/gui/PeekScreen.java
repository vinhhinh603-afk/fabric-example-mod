package night.gui;

import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class PeekScreen extends ContainerScreen {
   public PeekScreen(PeekMenu menu, Inventory playerInventory, Component title) {
      super(menu, playerInventory, title);
   }
}
