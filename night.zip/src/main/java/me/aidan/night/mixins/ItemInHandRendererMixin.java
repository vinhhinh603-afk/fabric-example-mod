package night.mixins;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import night.Night;
import night.modules.impl.player.SwingModule;
import night.modules.impl.visuals.ShadersModule;
import night.modules.impl.visuals.ViewModelModule;
import night.utils.mixins.HandsRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemInHandRenderer.class})
public abstract class ItemInHandRendererMixin {
   @Shadow
   private float mainHandHeight;
   @Shadow
   private float oMainHandHeight;
   @Shadow
   private float offHandHeight;
   @Shadow
   private float oOffHandHeight;
   @Shadow
   private ItemStack mainHandItem;
   @Shadow
   private ItemStack offHandItem;

   @Inject(
      method = {"submitHandsWithItems"},
      at = {@At("HEAD")}
   )
   private void night$startHands(float partialTick, PoseStack pose, SubmitNodeCollector collector, LocalPlayer player, int light, CallbackInfo ci) {
      HandsRenderState.renderingHands = true;
   }

   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void night$tickViewModel(CallbackInfo ci) {
      ViewModelModule vm = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ViewModelModule.class) : null;
      if (vm != null && vm.isToggled()) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player != null) {
            if (!vm.mainhandSwap.getValue()) {
               this.mainHandHeight = 1.0F;
               this.oMainHandHeight = 1.0F;
               this.mainHandItem = mc.player.getMainHandItem();
            }

            if (!vm.offhandSwap.getValue()) {
               this.offHandHeight = 1.0F;
               this.oOffHandHeight = 1.0F;
               this.offHandItem = mc.player.getOffhandItem();
            }
         }
      }
   }

   @Inject(
      method = {"submitArmWithItem"},
      at = {@At("HEAD")}
   )
   private void night$applyViewModelTransformHead(
      AbstractClientPlayer player,
      float partialTick,
      float pitch,
      InteractionHand hand,
      float swingProgress,
      ItemStack stack,
      float equippedProgress,
      PoseStack poseStack,
      SubmitNodeCollector collector,
      int light,
      CallbackInfo ci
   ) {
      ViewModelModule vm = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ViewModelModule.class) : null;
      if (vm != null && vm.isToggled()) {
         poseStack.pushPose();
         boolean useMain = hand == InteractionHand.MAIN_HAND || vm.mode.getValue().equalsIgnoreCase("Both");
         if (useMain) {
            poseStack.translate(vm.positionMainX.getValue().floatValue(), vm.positionMainY.getValue().floatValue(), vm.positionMainZ.getValue().floatValue());
            poseStack.scale(vm.scaleMainX.getValue().floatValue(), vm.scaleMainY.getValue().floatValue(), vm.scaleMainZ.getValue().floatValue());
            poseStack.mulPose(Axis.XP.rotationDegrees(vm.rotationMainX.getValue().floatValue()));
            poseStack.mulPose(Axis.YP.rotationDegrees(vm.rotationMainY.getValue().floatValue()));
            poseStack.mulPose(Axis.ZP.rotationDegrees(vm.rotationMainZ.getValue().floatValue()));
         } else {
            poseStack.translate(vm.positionOffX.getValue().floatValue(), vm.positionOffY.getValue().floatValue(), vm.positionOffZ.getValue().floatValue());
            poseStack.scale(vm.scaleOffX.getValue().floatValue(), vm.scaleOffY.getValue().floatValue(), vm.scaleOffZ.getValue().floatValue());
            poseStack.mulPose(Axis.XP.rotationDegrees(vm.rotationOffX.getValue().floatValue()));
            poseStack.mulPose(Axis.YP.rotationDegrees(vm.rotationOffY.getValue().floatValue()));
            poseStack.mulPose(Axis.ZP.rotationDegrees(vm.rotationOffZ.getValue().floatValue()));
         }
      }
   }

   @Inject(
      method = {"submitArmWithItem"},
      at = {@At("RETURN")}
   )
   private void night$applyViewModelTransformReturn(
      AbstractClientPlayer player,
      float partialTick,
      float pitch,
      InteractionHand hand,
      float swingProgress,
      ItemStack stack,
      float equippedProgress,
      PoseStack poseStack,
      SubmitNodeCollector collector,
      int light,
      CallbackInfo ci
   ) {
      ViewModelModule vm = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ViewModelModule.class) : null;
      if (vm != null && vm.isToggled()) {
         poseStack.popPose();
      }
   }

   @Inject(
      method = {"applyEatTransform"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$applyEatTransform(PoseStack poseStack, float partialTick, HumanoidArm arm, ItemStack stack, Player player, CallbackInfo ci) {
      ViewModelModule vm = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ViewModelModule.class) : null;
      if (vm != null && vm.isToggled()) {
         float multiplier = vm.eatingMultiplier.getValue().floatValue();
         if (multiplier < 1.0F) {
            float currUsageTime = player.getUseItemRemainingTicks() - partialTick + 1.0F;
            float scaledUsageTime = currUsageTime / stack.getUseDuration(player);
            if (scaledUsageTime < 0.8F) {
               float extraHeightOffset = Mth.abs(Mth.cos(currUsageTime / 4.0F * (float) Math.PI) * 0.1F) * multiplier;
               poseStack.translate(0.0F, extraHeightOffset, 0.0F);
            }

            float eatJiggle = 1.0F - (float)Math.pow(scaledUsageTime, 27.0);
            int invert = arm == HumanoidArm.RIGHT ? 1 : -1;
            poseStack.translate(eatJiggle * 0.6F * invert, eatJiggle * -0.5F, eatJiggle * 0.0F);
            poseStack.mulPose(Axis.YP.rotationDegrees(invert * eatJiggle * 90.0F));
            poseStack.mulPose(Axis.XP.rotationDegrees(eatJiggle * 10.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(invert * eatJiggle * 30.0F));
            ci.cancel();
         }

         if (vm.eatAnimation.getValue()) {
            poseStack.translate(vm.eatX.getValue().floatValue(), vm.eatY.getValue().floatValue(), 0.0F);
         }
      }
   }

   @ModifyArg(
      method = {"renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;I)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/item/ItemStackRenderState;submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;III)V"
      )},
      index = 4
   )
   private int night$handsOutline(int outlineColor, @Local(argsOnly = true) ItemStack stack) {
      return computeHandsOutlineColor(outlineColor);
   }

   private static int computeHandsOutlineColor(int fallback) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == null) {
         return fallback;
      } else {
         ShadersModule shaders = Night.MODULE_MANAGER.getModule(ShadersModule.class);
         return shaders.isToggled() && shaders.hands.getValue() ? shaders.getFillColor(mc.player) : fallback;
      }
   }

   @Inject(
      method = {"submitHandsWithItems"},
      at = {@At("RETURN")}
   )
   private void night$flushHandOutline(float partialTick, PoseStack pose, SubmitNodeCollector collector, LocalPlayer player, int light, CallbackInfo ci) {
      HandsRenderState.renderingHands = false;
   }

   @Inject(
      method = {"swingArm"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$swingArm(float attack, PoseStack poseStack, int invert, HumanoidArm arm, CallbackInfo info) {
      SwingModule swing = Night.MODULE_MANAGER.getModule(SwingModule.class);
      if (swing.isToggled()) {
         float xSwingPosition = swing.translateX.getValue() ? -0.4F * Mth.sin(Mth.sqrt(attack) * (float) Math.PI) : 0.0F;
         float ySwingPosition = swing.translateY.getValue() ? 0.2F * Mth.sin(Mth.sqrt(attack) * (float) (Math.PI * 2)) : 0.0F;
         float zSwingPosition = swing.translateZ.getValue() ? -0.2F * Mth.sin(attack * (float) Math.PI) : 0.0F;
         poseStack.translate(invert * xSwingPosition, ySwingPosition, zSwingPosition);
         night$applyItemArmAttackTransform(poseStack, arm, attack, swing);
         info.cancel();
      }
   }

   private static void night$applyItemArmAttackTransform(PoseStack poseStack, HumanoidArm arm, float attackValue, SwingModule swing) {
      int invert = arm == HumanoidArm.RIGHT ? 1 : -1;
      float ySwingRotation = swing.rotationY.getValue() ? Mth.sin(attackValue * attackValue * (float) Math.PI) : 0.0F;
      poseStack.mulPose(Axis.YP.rotationDegrees(invert * (45.0F + ySwingRotation * -20.0F)));
      float xzSwingRotation = Mth.sin(Mth.sqrt(attackValue) * (float) Math.PI);
      poseStack.mulPose(Axis.ZP.rotationDegrees(invert * (swing.rotationZ.getValue() ? xzSwingRotation : 0.0F) * -20.0F));
      poseStack.mulPose(Axis.XP.rotationDegrees((swing.rotationX.getValue() ? xzSwingRotation : 0.0F) * -80.0F));
      poseStack.mulPose(Axis.YP.rotationDegrees(invert * -45.0F));
   }
}
