package night.mixins;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.gui.components.ChatComponent.ChatGraphicsAccess;
import net.minecraft.client.gui.components.ChatComponent.DisplayMode;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.chat.GuiMessage;
import net.minecraft.client.multiplayer.chat.GuiMessageSource;
import net.minecraft.client.multiplayer.chat.GuiMessageTag;
import net.minecraft.client.multiplayer.chat.GuiMessage.Line;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.ARGB;
import night.Night;
import night.managers.ChatManager;
import night.modules.impl.core.CommandsModule;
import night.modules.impl.miscellaneous.BetterChatModule;
import night.utils.text.FormattingUtils;
import org.joml.Matrix3x2f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({ChatComponent.class})
public abstract class ChatHudMixin {
   @Shadow
   @Final
   private List<Line> trimmedMessages;

   @Inject(
      method = {"addMessageToDisplayQueue"},
      at = {@At("TAIL")}
   )
   private void night$trackAnimation(GuiMessage message, CallbackInfo ci) {
      BetterChatModule module = Night.MODULE_MANAGER.getModule(BetterChatModule.class);
      if (module.isToggled() && module.animation.getValue() && !this.trimmedMessages.isEmpty()) {
         module.getAnimationMap().put(this.trimmedMessages.getFirst(), System.currentTimeMillis());
      }
   }

   @Inject(
      method = {"extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/client/gui/Font;IIILnet/minecraft/client/gui/components/ChatComponent$DisplayMode;Z)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$preventChatOverGui(
      GuiGraphicsExtractor graphics, Font font, int ticks, int mouseX, int mouseY, DisplayMode displayMode, boolean isFocused, CallbackInfo ci
   ) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.gui != null && mc.gui.screen() != null && !(mc.gui.screen() instanceof ChatScreen) && !ChatManager.isInsideHudExtractChat) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/client/gui/Font;IIILnet/minecraft/client/gui/components/ChatComponent$DisplayMode;Z)V"},
      at = {@At("TAIL")}
   )
   private void night$cleanupAnimations(CallbackInfo ci) {
      BetterChatModule module = Night.MODULE_MANAGER.getModule(BetterChatModule.class);
      if (module.isToggled() && module.animation.getValue()) {
         module.getAnimationMap().entrySet().removeIf(entry -> System.currentTimeMillis() - entry.getValue() > module.delay.getValue().intValue());
      }
   }

   @Redirect(
      method = {"extractRenderState(Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;IILnet/minecraft/client/gui/components/ChatComponent$DisplayMode;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;updatePose(Ljava/util/function/Consumer;)V"
      )}
   )
   private void night$applyOffset(ChatGraphicsAccess instance, Consumer<Matrix3x2f> updater) {
      BetterChatModule module = Night.MODULE_MANAGER.getModule(BetterChatModule.class);
      int offset = module.isToggled() ? module.offset.getValue().intValue() : 0;
      instance.updatePose(pose -> {
         updater.accept(pose);
         if (offset != 0) {
            pose.translate(offset, 0.0F);
         }
      });
   }

   @Redirect(
      method = {"extractRenderState(Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;IILnet/minecraft/client/gui/components/ChatComponent$DisplayMode;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/OptionInstance;get()Ljava/lang/Object;",
         ordinal = 0
      )}
   )
   private Object night$textOpacity(OptionInstance<?> instance) {
      BetterChatModule module = Night.MODULE_MANAGER.getModule(BetterChatModule.class);
      return module.isToggled() ? module.textAlpha.getValue().doubleValue() / 255.0 : instance.get();
   }

   @Redirect(
      method = {"extractRenderState(Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;IILnet/minecraft/client/gui/components/ChatComponent$DisplayMode;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/OptionInstance;get()Ljava/lang/Object;",
         ordinal = 1
      )}
   )
   private Object night$backgroundOpacity(OptionInstance<?> instance) {
      BetterChatModule module = Night.MODULE_MANAGER.getModule(BetterChatModule.class);
      if (module.isToggled()) {
         String var3 = module.background.getValue();

         return switch (var3) {
            case "Clear" -> 0.0;
            case "Custom" -> module.color.getColor().getAlpha() / 255.0;
            default -> instance.get();
         };
      } else {
         return instance.get();
      }
   }

   @Redirect(
      method = {"lambda$extractRenderState$1(IILnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;IFLnet/minecraft/client/multiplayer/chat/GuiMessage$Line;IF)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/ARGB;black(F)I"
      )}
   )
   private static int night$backgroundColor(float alpha) {
      BetterChatModule module = Night.MODULE_MANAGER.getModule(BetterChatModule.class);
      return module.isToggled() && module.background.getValue().equalsIgnoreCase("Custom")
         ? ARGB.color(Math.round(alpha * 255.0F), module.color.getColor().getRGB() & 16777215)
         : ARGB.black(alpha);
   }

   @ModifyArgs(
      method = {"addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/multiplayer/chat/GuiMessage;<init>(ILnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V"
      )}
   )
   private void addMessage(Args args, Component message, MessageSignature signature, GuiMessageSource source, GuiMessageTag indicator) {
      BetterChatModule module = Night.MODULE_MANAGER.getModule(BetterChatModule.class);
      if (module.isToggled()) {
         Component processed = message;
         Minecraft mc = Minecraft.getInstance();
         String rawText;
         String selfName;
         if (module.highlight.getValue()
            && mc.player != null
            && (selfName = mc.player.getGameProfile().name()) != null
            && !selfName.isEmpty()
            && !night$isSender(rawText = message.getString(), selfName)
            && night$containsWord(rawText.toLowerCase(), selfName.toLowerCase())) {
            if (module.highlightSound.getValue()) {
               mc.player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
            }

            processed = night$highlightMessage(message, selfName, module.highlightColor.getColor());
         }

         if (module.timestamps.getValue()) {
            processed = Component.literal("")
               .append(
                  Component.literal(
                     FormattingUtils.getFormatting(Night.MODULE_MANAGER.getModule(CommandsModule.class).secondaryWatermarkColor.getValue())
                        + module.opening.getValue()
                        + FormattingUtils.getFormatting(Night.MODULE_MANAGER.getModule(CommandsModule.class).primaryWatermarkColor.getValue())
                        + new SimpleDateFormat("HH:mm").format(new Date())
                        + FormattingUtils.getFormatting(Night.MODULE_MANAGER.getModule(CommandsModule.class).secondaryWatermarkColor.getValue())
                        + module.closing.getValue()
                        + ChatFormatting.RESET
                        + " "
                  )
               )
               .append(processed);
         }

         args.set(1, processed);
      }
   }

   private static boolean night$isSender(String rawText, String selfName) {
      if (rawText != null && selfName != null && !selfName.isEmpty()) {
         String lower = rawText.toLowerCase();
         String lowerName = selfName.toLowerCase();
         if (!lower.startsWith("you whisper to") && !lower.startsWith("to ")) {
            int sepIdx = -1;
            int closeAngle;
            if (rawText.startsWith("<") && (closeAngle = rawText.indexOf(62)) != -1) {
               sepIdx = closeAngle;
            }

            if (sepIdx == -1) {
               for (String sep : new String[]{": ", " » ", " > ", " -> ", ":"}) {
                  int idx = rawText.indexOf(sep);
                  if (idx != -1 && (sepIdx == -1 || idx < sepIdx)) {
                     sepIdx = idx;
                  }
               }
            }

            return sepIdx != -1 && night$containsWord(rawText.substring(0, sepIdx).toLowerCase(), lowerName);
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static boolean night$containsWord(String text, String word) {
      if (text != null && word != null) {
         int idx = 0;

         while ((idx = text.indexOf(word, idx)) != -1) {
            boolean startOk = idx == 0 || !night$isWordChar(text.charAt(idx - 1));
            boolean endOk = idx + word.length() == text.length() || !night$isWordChar(text.charAt(idx + word.length()));
            if (startOk && endOk) {
               return true;
            }

            idx += word.length();
         }

         return false;
      } else {
         return false;
      }
   }

   private static boolean night$isWordChar(char c) {
      return Character.isLetterOrDigit(c) || c == '_';
   }

   private static Component night$highlightMessage(Component original, String name, Color color) {
      TextColor highlightColor = TextColor.fromRgb(color.getRGB() & 16777215);
      Style highlightStyle = Style.EMPTY.withColor(highlightColor);
      MutableComponent result = Component.empty();
      original.visit((style, text) -> {
         if (text != null && !text.isEmpty()) {
            String lowerText = text.toLowerCase();
            String lowerName = name.toLowerCase();
            int cursor = 0;

            while (cursor < text.length()) {
               int idx = lowerText.indexOf(lowerName, cursor);
               if (idx == -1) {
                  result.append(Component.literal(text.substring(cursor)).withStyle(style));
                  break;
               }

               boolean startOk = idx == 0 || !night$isWordChar(text.charAt(idx - 1));
               boolean endOk = idx + lowerName.length() == text.length() || !night$isWordChar(text.charAt(idx + lowerName.length()));
               if (startOk && endOk) {
                  if (idx > cursor) {
                     result.append(Component.literal(text.substring(cursor, idx)).withStyle(style));
                  }

                  result.append(Component.literal(text.substring(idx, idx + lowerName.length())).withStyle(highlightStyle));
                  cursor = idx + lowerName.length();
               } else {
                  result.append(Component.literal(text.substring(cursor, idx + 1)).withStyle(style));
                  cursor = idx + 1;
               }
            }

            return Optional.empty();
         } else {
            return Optional.empty();
         }
      }, Style.EMPTY);
      return result;
   }
}
