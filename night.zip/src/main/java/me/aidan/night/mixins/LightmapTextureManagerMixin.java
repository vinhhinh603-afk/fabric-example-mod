package night.mixins;

import java.awt.Color;
import net.minecraft.client.renderer.Lightmap;
import net.minecraft.client.renderer.state.LightmapRenderState;
import night.Night;
import night.modules.api.IAmbienceModule;
import night.modules.api.IFullBrightModule;
import night.modules.impl.visuals.NoRenderModule;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Lightmap.class})
public class LightmapTextureManagerMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void night$render(LightmapRenderState renderState, CallbackInfo info) {
      IFullBrightModule fullBright = (IFullBrightModule)Night.MODULE_MANAGER.getModule("FullBright");
      if (fullBright.isToggled() && fullBright.getModeValue().equalsIgnoreCase("Gamma")) {
         renderState.blockFactor = 1.0F;
         renderState.skyFactor = 1.0F;
         renderState.brightness = 1.0F;
         renderState.nightVisionEffectIntensity = 1.0F;
         renderState.darknessEffectScale = 0.0F;
         renderState.bossOverlayWorldDarkening = 0.0F;
         renderState.needsUpdate = true;
      }

      NoRenderModule noRender;
      if ((noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class)).isToggled() && noRender.blindness.getValue()) {
         renderState.darknessEffectScale = 0.0F;
         renderState.needsUpdate = true;
      }

      IAmbienceModule ambience = Night.MODULE_MANAGER != null ? (IAmbienceModule)Night.MODULE_MANAGER.getModule("Ambience") : null;
      if (ambience != null && ambience.isToggled()) {
         Color color = ambience.getColor();
         float r = color.getRed() / 255.0F;
         float g = color.getGreen() / 255.0F;
         float b = color.getBlue() / 255.0F;
         float alpha = color.getAlpha() / 255.0F;
         if (ambience.isLightmapEnabled()) {
            if (ambience.isSkyEnabled()) {
               Vector3fc origSky = (Vector3fc)(renderState.skyLightColor != null ? renderState.skyLightColor : new Vector3f(1.0F, 1.0F, 1.0F));
               renderState.skyLightColor = new Vector3f(
                  origSky.x() * (1.0F - alpha) + r * alpha, origSky.y() * (1.0F - alpha) + g * alpha, origSky.z() * (1.0F - alpha) + b * alpha
               );
               Vector3fc origAmbient = (Vector3fc)(renderState.ambientColor != null ? renderState.ambientColor : new Vector3f(0.0F, 0.0F, 0.0F));
               renderState.ambientColor = new Vector3f(
                  origAmbient.x() * (1.0F - alpha) + r * alpha, origAmbient.y() * (1.0F - alpha) + g * alpha, origAmbient.z() * (1.0F - alpha) + b * alpha
               );
            }

            if (ambience.isBlocksEnabled()) {
               Vector3fc origBlock = (Vector3fc)(renderState.blockLightTint != null ? renderState.blockLightTint : new Vector3f(1.0F, 1.0F, 1.0F));
               renderState.blockLightTint = new Vector3f(
                  origBlock.x() * (1.0F - alpha) + r * alpha, origBlock.y() * (1.0F - alpha) + g * alpha, origBlock.z() * (1.0F - alpha) + b * alpha
               );
            }

            renderState.needsUpdate = true;
         }
      }
   }
}
