package night.mixins;

import net.minecraft.client.player.RemotePlayer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import night.Night;
import night.modules.impl.visuals.ChamsModule;
import night.modules.impl.visuals.LogoutSpotModule;
import night.modules.impl.visuals.NameTagsModule;
import night.modules.impl.visuals.NoRenderModule;
import night.modules.impl.visuals.PopChamsModule;
import night.modules.impl.visuals.ShadersModule;
import night.utils.mixins.IChamsCapture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityRenderer.class})
public class EntityRendererMixin<T extends Entity, S extends EntityRenderState> {
   @Inject(
      method = {"getNameTag"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void getDisplayName(T entity, CallbackInfoReturnable<Component> info) {
      if (entity instanceof RemotePlayer ghost) {
         PopChamsModule popChams = Night.MODULE_MANAGER.getModule(PopChamsModule.class);
         if (popChams != null && popChams.isToggled() && popChams.isGhost(ghost)) {
            info.setReturnValue(null);
            return;
         }

         LogoutSpotModule logoutSpot = Night.MODULE_MANAGER.getModule(LogoutSpotModule.class);
         if (logoutSpot != null && logoutSpot.isToggled() && logoutSpot.isGhost(ghost)) {
            info.setReturnValue(null);
            return;
         }
      }

      if (entity instanceof Player && Night.MODULE_MANAGER.getModule(NameTagsModule.class).isToggled()) {
         info.setReturnValue(null);
      }
   }

   @Inject(
      method = {"shouldRender"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$limitItemRendering(T entity, Frustum frustum, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
      if (entity instanceof RemotePlayer ghost) {
         PopChamsModule popChams = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(PopChamsModule.class) : null;
         if (popChams != null && popChams.isToggled() && popChams.isGhost(ghost)) {
            cir.setReturnValue(true);
            return;
         }
      }

      NoRenderModule noRender = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(NoRenderModule.class) : null;
      if (noRender != null && noRender.isToggled()) {
         if (noRender.items.getValue() && entity instanceof ItemEntity && !noRender.shouldRenderItem()) {
            cir.setReturnValue(false);
         }

         if (noRender.displays.getValue() && entity instanceof Display) {
            cir.setReturnValue(false);
         }

         if (noRender.armorStand.getValue() && entity instanceof ArmorStand) {
            cir.setReturnValue(false);
         }

         if (noRender.minecart.getValue() && entity instanceof AbstractMinecart) {
            cir.setReturnValue(false);
         }
      }
   }

   @Inject(
      method = {"extractRenderState"},
      at = {@At("TAIL")}
   )
   private void night$chams(T entity, S state, float partialTicks, CallbackInfo info) {
      IChamsCapture capture = (IChamsCapture)state;
      capture.night$setChams(false, 0, false, 0, false);
      capture.night$setChamsYOffset(0.0F);
      PopChamsModule popChams = Night.MODULE_MANAGER.getModule(PopChamsModule.class);
      LogoutSpotModule logoutSpot = Night.MODULE_MANAGER.getModule(LogoutSpotModule.class);
      boolean isPopGhost = entity instanceof RemotePlayer ghost && popChams != null && popChams.isGhost(ghost);
      boolean isLogoutGhost = entity instanceof RemotePlayer ghostx && logoutSpot != null && logoutSpot.isGhost(ghostx);
      boolean isGhost = isPopGhost || isLogoutGhost;
      if (!isGhost) {
         ChamsModule chams = Night.MODULE_MANAGER.getModule(ChamsModule.class);
         if (chams.isToggled()) {
            if (entity instanceof LivingEntity livingEntity && chams.isValidEntity(livingEntity)) {
               chams.applyEntityChams(livingEntity, capture);
            } else if (chams.crystals.getValue() && entity instanceof EndCrystal && chams.inRange(entity)) {
               chams.applyCrystalChams(capture);
            } else if (chams.vehicles.getValue() && chams.inRange(entity) && (entity instanceof AbstractBoat || entity instanceof AbstractMinecart)) {
               chams.applyVehicleChams(capture);
            }
         }

         ShadersModule shaders = Night.MODULE_MANAGER.getModule(ShadersModule.class);
         if (shaders.isToggled() && shaders.isValidEntity(entity)) {
            state.outlineColor = shaders.getFillColor(entity);
         }
      }

      if (popChams != null && popChams.isToggled() && isPopGhost) {
         RemotePlayer ghostxx = (RemotePlayer)entity;
         capture.night$setChams(
            popChams.shouldFill(), popChams.getFillColor(ghostxx).getRGB(), popChams.shouldOutline(), popChams.getOutlineColor(ghostxx).getRGB(), false, true
         );
         capture.night$setChamsYOffset(popChams.getYOffset(ghostxx));
      }

      if (logoutSpot != null && logoutSpot.isToggled() && isLogoutGhost) {
         RemotePlayer ghostxx = (RemotePlayer)entity;
         capture.night$setChams(
            logoutSpot.shouldFill(),
            logoutSpot.getFillColor(ghostxx).getRGB(),
            logoutSpot.shouldOutline(),
            logoutSpot.getOutlineColor(ghostxx).getRGB(),
            false,
            true
         );
      }
   }
}
