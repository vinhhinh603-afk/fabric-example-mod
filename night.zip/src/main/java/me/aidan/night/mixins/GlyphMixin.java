package night.mixins;

import com.mojang.blaze3d.font.GlyphInfo;
import night.Night;
import night.managers.FontManager;
import night.modules.impl.core.FontModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({GlyphInfo.class})
public interface GlyphMixin {
   @Inject(
      method = {"getShadowOffset"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void getShadowOffset(CallbackInfoReturnable<Float> info) {
      if (FontManager.isClientTextRendering()) {
         FontModule module;
         if (Night.MODULE_MANAGER != null
            && (module = Night.MODULE_MANAGER.getModule(FontModule.class)) != null
            && module.isToggled()
            && !module.shadowMode.getValue().equalsIgnoreCase("Default")) {
            info.setReturnValue(Night.FONT_MANAGER.getShadowOffset());
         }
      }
   }
}
