package night.mixins;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.ClientAsset.ResourceTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerSkin;
import night.Night;
import night.modules.impl.core.CapesModule;
import night.utils.IMinecraft;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerInfo.class})
public class PlayerListEntryMixin implements IMinecraft {
   @Shadow
   @Final
   private GameProfile profile;

   @Inject(
      method = {"getSkin"},
      at = {@At("TAIL")},
      cancellable = true
   )
   private void getSkinTextures(CallbackInfoReturnable<PlayerSkin> info) {
      if (this.profile.name().equals(mc.player.getGameProfile().name())
         && this.profile.id().equals(mc.player.getGameProfile().id())
         && Night.MODULE_MANAGER.getModule(CapesModule.class).isToggled()
         && Night.MODULE_MANAGER.getModule(CapesModule.class).getCapeTexture() != null) {
         Identifier identifier = Night.MODULE_MANAGER.getModule(CapesModule.class).getCapeTexture();
         PlayerSkin skin = (PlayerSkin)info.getReturnValue();
         info.setReturnValue(new PlayerSkin(skin.body(), new ResourceTexture(identifier), skin.elytra(), skin.model(), skin.secure()));
      }
   }
}
