package night.mixins;

import net.minecraft.client.renderer.entity.ItemEntityRenderer;
import night.Night;
import night.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemEntityRenderer.class})
public class ItemEntityRendererMixin {
   @Inject(
      method = {"submit"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$limitItems(CallbackInfo info) {
      NoRenderModule noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class);
      if (noRender != null && noRender.isToggled()) {
         if (!noRender.shouldRenderItem()) {
            info.cancel();
         }
      }
   }
}
