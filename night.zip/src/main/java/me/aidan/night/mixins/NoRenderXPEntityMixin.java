package night.mixins;

import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownExperienceBottle;
import night.modules.impl.visuals.NoRenderModule;
import night.utils.graphics.NoRenderEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
   value = {EntityRenderer.class},
   priority = 1100
)
public class NoRenderXPEntityMixin {
   @Inject(
      method = {"shouldRender"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$hideXP(Entity entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> ci) {
      NoRenderModule m = NoRenderEffects.enabled();
      if (m != null && (m.xpOrbs.getValue() && entity instanceof ExperienceOrb || m.xpBottles.getValue() && entity instanceof ThrownExperienceBottle)) {
         ci.setReturnValue(false);
      }
   }
}
