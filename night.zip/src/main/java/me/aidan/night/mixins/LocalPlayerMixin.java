package night.mixins;

import net.minecraft.client.player.LocalPlayer;
import night.Night;
import night.mixins.accessors.EntityAccessor;
import night.modules.impl.player.RotationLockModule;
import night.utils.IMinecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LocalPlayer.class})
public abstract class LocalPlayerMixin implements IMinecraft {
   @Inject(
      method = {"getViewYRot"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$unlockViewYaw(float partialTick, CallbackInfoReturnable<Float> info) {
      if (!((LocalPlayer)this).isPassenger()) {
         RotationLockModule lock = Night.MODULE_MANAGER.getModule(RotationLockModule.class);
         if (lock.isToggled() && lock.custom.getValue() && (lock.mode.getValue().equals("Yaw") || lock.mode.getValue().equals("Both"))) {
            info.setReturnValue(((EntityAccessor)this).getRawYRot());
         }
      }
   }

   @Inject(
      method = {"getViewXRot"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$unlockViewPitch(float partialTick, CallbackInfoReturnable<Float> info) {
      RotationLockModule lock = Night.MODULE_MANAGER.getModule(RotationLockModule.class);
      if (lock.isToggled() && lock.custom.getValue() && (lock.mode.getValue().equals("Pitch") || lock.mode.getValue().equals("Both"))) {
         info.setReturnValue(((EntityAccessor)this).getRawXRot());
      }
   }
}
