package night.mixins;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Entity;
import night.modules.impl.visuals.NoRenderModule;
import night.utils.graphics.NoRenderEffects;
import night.utils.graphics.XPParticleScope;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
   value = {ParticleEngine.class},
   priority = 1100
)
public class NoRenderEffectsMixin {
   @Inject(
      method = {"createParticle"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$filter(ParticleOptions particle, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<Particle> ci) {
      NoRenderModule m = NoRenderEffects.enabled();
      if (m != null) {
         ParticleType<?> type = particle.getType();
         if (m.allParticles.getValue()
            || m.totemPop.getValue() && type == ParticleTypes.TOTEM_OF_UNDYING
            || m.explosions.getValue() && (type == ParticleTypes.EXPLOSION || type == ParticleTypes.EXPLOSION_EMITTER)
            || m.xpParticles.getValue() && XPParticleScope.active()) {
            ci.setReturnValue(null);
         }
      }
   }

   @Inject(
      method = {"createTrackingEmitter(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/particles/ParticleOptions;I)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$emitter(Entity entity, ParticleOptions particle, int lifetime, CallbackInfo ci) {
      NoRenderModule m = NoRenderEffects.enabled();
      if (m != null && (m.allParticles.getValue() || m.totemPop.getValue() && particle.getType() == ParticleTypes.TOTEM_OF_UNDYING)) {
         ci.cancel();
      }
   }
}
