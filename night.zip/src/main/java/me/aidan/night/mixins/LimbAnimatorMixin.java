package night.mixins;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.WalkAnimationState;
import night.Night;
import night.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({WalkAnimationState.class})
public class LimbAnimatorMixin {
   @ModifyReturnValue(
      method = {"position()F"},
      at = {@At("RETURN")}
   )
   private float getPos(float original) {
      return Night.MODULE_MANAGER.getModule(NoRenderModule.class).isToggled() && Night.MODULE_MANAGER.getModule(NoRenderModule.class).limbSwing.getValue()
         ? 0.0F
         : original;
   }

   @ModifyReturnValue(
      method = {"position(F)F"},
      at = {@At("RETURN")}
   )
   private float getPos2(float original) {
      return Night.MODULE_MANAGER.getModule(NoRenderModule.class).isToggled() && Night.MODULE_MANAGER.getModule(NoRenderModule.class).limbSwing.getValue()
         ? 0.0F
         : original;
   }

   @ModifyReturnValue(
      method = {"speed()F"},
      at = {@At("RETURN")}
   )
   private float getSpeed(float original) {
      return Night.MODULE_MANAGER.getModule(NoRenderModule.class).isToggled() && Night.MODULE_MANAGER.getModule(NoRenderModule.class).limbSwing.getValue()
         ? 0.0F
         : original;
   }

   @ModifyReturnValue(
      method = {"speed(F)F"},
      at = {@At("RETURN")}
   )
   private float getSpeed2(float original) {
      return Night.MODULE_MANAGER.getModule(NoRenderModule.class).isToggled() && Night.MODULE_MANAGER.getModule(NoRenderModule.class).limbSwing.getValue()
         ? 0.0F
         : original;
   }
}
