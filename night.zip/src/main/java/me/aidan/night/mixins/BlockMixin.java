package night.mixins;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import night.Night;
import night.modules.impl.movement.NoSlowModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Block.class})
public class BlockMixin {
   @Inject(
      method = {"getFriction"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void getSlipperiness(CallbackInfoReturnable<Float> info) {
      if (this == Blocks.SLIME_BLOCK
         && Night.MODULE_MANAGER.getModule(NoSlowModule.class).isToggled()
         && Night.MODULE_MANAGER.getModule(NoSlowModule.class).slimeBlocks.getValue()) {
         info.setReturnValue(0.6F);
      }
   }
}
