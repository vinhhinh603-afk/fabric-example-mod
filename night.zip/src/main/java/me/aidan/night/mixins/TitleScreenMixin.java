package night.mixins;

import java.awt.Color;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import night.Night;
import night.gui.components.AccountButton;
import night.utils.IMinecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({TitleScreen.class})
public abstract class TitleScreenMixin extends Screen implements IMinecraft {
   @Shadow
   private boolean fading;
   @Shadow
   private long fadeInStart;

   protected TitleScreenMixin(Component title) {
      super(title);
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void init(CallbackInfo ci) {
      this.addRenderableWidget(AccountButton.create(8, 8, 75, 20, this));
   }

   @Inject(
      method = {"extractRenderState"},
      at = {@At("TAIL")}
   )
   private void render$drawTextWithShadow(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta, CallbackInfo info) {
      if (!Night.UPDATE_STATUS.equalsIgnoreCase("none")) {
         String primaryText = "";
         String secondaryText = "";
         Color color = Color.WHITE;
         if (Night.UPDATE_STATUS.equalsIgnoreCase("update-available")) {
            secondaryText = "An update is available for xnhau.";
            primaryText = "Please restart the game to apply changes.";
            color = Color.ORANGE;
         }

         if (Night.UPDATE_STATUS.equalsIgnoreCase("failed-connection")) {
            secondaryText = "Failed to connect to xnhau's servers.";
            primaryText = "Please make sure you have a working internet connection.";
            color = Color.RED;
         }

         if (Night.UPDATE_STATUS.equalsIgnoreCase("failed")) {
            secondaryText = "Failed to update xnhau.";
            primaryText = "Please make sure the auto-updater is working properly.";
            color = Color.RED;
         }

         if (Night.UPDATE_STATUS.equalsIgnoreCase("up-to-date")) {
            primaryText = "xnhau is on the latest version.";
         }

         if (!primaryText.isEmpty()) {
            float f = 1.0F;
            float g;
            if (this.fading && (g = (float)(Util.getMillis() - this.fadeInStart) / 2000.0F) <= 1.0F) {
               g = Mth.clamp(g, 0.0F, 1.0F);
               f = Mth.clampedMap(g, 0.5F, 1.0F, 0.0F, 1.0F);
            }

            int i;
            if (((i = Mth.ceil(f * 255.0F) << 24) & -67108864) != 0) {
               if (!secondaryText.isEmpty()) {
                  context.text(mc.font, secondaryText, this.width / 2 - mc.font.width(secondaryText) / 2, this.height - 30, color.getRGB() | i, true);
               }

               context.text(mc.font, primaryText, this.width / 2 - mc.font.width(primaryText) / 2, this.height - 20, color.getRGB() | i, true);
            }
         }
      }
   }
}
