package night.mixins;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderPassBackend;
import com.mojang.blaze3d.systems.RenderPass.RenderArea;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderPass.class})
public abstract class RenderPassMixin {
   @Shadow
   @Final
   private RenderArea renderArea;
   @Shadow
   @Final
   private RenderPassBackend backend;

   @Shadow
   public abstract void disableScissor();

   @Inject(
      method = {"enableScissor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$clampScissorToBounds(int x, int y, int width, int height, CallbackInfo ci) {
      if (this.renderArea != null) {
         int areaX = this.renderArea.x();
         int areaY = this.renderArea.y();
         int areaWidth = this.renderArea.width();
         int areaHeight = this.renderArea.height();
         int x1 = x;
         int y1 = y;
         int x2 = x + width;
         int y2 = y + height;
         if (x < areaX) {
            x1 = areaX;
         }

         if (y < areaY) {
            y1 = areaY;
         }

         if (x2 > areaX + areaWidth) {
            x2 = areaX + areaWidth;
         }

         if (y2 > areaY + areaHeight) {
            y2 = areaY + areaHeight;
         }

         int clampedWidth = x2 - x1;
         int clampedHeight = y2 - y1;
         if (clampedWidth > 0 && clampedHeight > 0) {
            if (x1 != x || y1 != y || clampedWidth != width || clampedHeight != height) {
               this.backend.enableScissor(x1, y1, clampedWidth, clampedHeight);
               ci.cancel();
            }
         } else {
            this.disableScissor();
            ci.cancel();
         }
      }
   }
}
