package night.mixins;

import java.awt.Color;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.environment.AtmosphericFogEnvironment;
import net.minecraft.util.ARGB;
import night.Night;
import night.modules.impl.visuals.AtmosphereModule;
import night.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AtmosphericFogEnvironment.class})
public class BackgroundRendererMixin {
   @Inject(
      method = {"setupFog"},
      at = {@At("TAIL")}
   )
   private void night$setupFog(FogData fog, Camera camera, ClientLevel level, float renderDistance, DeltaTracker deltaTracker, CallbackInfo info) {
      NoRenderModule noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class);
      AtmosphereModule atmosphere = Night.MODULE_MANAGER.getModule(AtmosphereModule.class);
      if (noRender.isToggled() && noRender.fog.getValue()) {
         fog.environmentalStart = renderDistance * 4.0F;
         fog.environmentalEnd = renderDistance * 4.25F;
      } else if (atmosphere != null && atmosphere.isToggled() && atmosphere.modifyFog.getValue()) {
         fog.environmentalStart = atmosphere.fogStart.getValue().floatValue();
         fog.environmentalEnd = atmosphere.fogEnd.getValue().floatValue();
      }
   }

   @Inject(
      method = {"getBaseColor"},
      at = {@At("TAIL")},
      cancellable = true
   )
   private void night$getBaseColor(ClientLevel level, Camera camera, int renderDistance, float partialTicks, CallbackInfoReturnable<Integer> info) {
      AtmosphereModule atmosphere = Night.MODULE_MANAGER.getModule(AtmosphereModule.class);
      if (atmosphere != null && atmosphere.isToggled() && atmosphere.modifyFog.getValue()) {
         Color color = atmosphere.fogColor.getColor();
         info.setReturnValue(ARGB.color(255, color.getRed(), color.getGreen(), color.getBlue()));
      }
   }
}
