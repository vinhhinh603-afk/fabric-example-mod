package night.mixins;

import io.netty.channel.Channel;
import io.netty.channel.ChannelPipeline;
import net.minecraft.network.Connection;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.PacketBundlePacker;
import net.minecraft.network.PacketBundleUnpacker;
import net.minecraft.network.PacketDecoder;
import net.minecraft.network.PacketEncoder;
import net.minecraft.network.PacketListener;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.protocol.BundlerInfo;
import night.mixins.accessors.ConnectionAccessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Connection.class})
public class ConnectionSafeReconfigureMixin {
   private static final Logger LOGGER = LoggerFactory.getLogger("Night/SafeReconfigure");

   @Inject(
      method = {"setupOutboundProtocol"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void setupOutboundProtocol$safe(ProtocolInfo<?> protocol, CallbackInfo info) {
      Connection self = (Connection)this;
      if (protocol.flow() != self.getSending()) {
         throw new IllegalStateException("Invalid outbound protocol: " + protocol.id());
      } else {
         ConnectionAccessor accessor = (ConnectionAccessor)this;
         Channel channel = accessor.getChannel();
         accessor.setSendLoginDisconnect(protocol.id() == ConnectionProtocol.LOGIN);
         Runnable swap = () -> {
            try {
               ChannelPipeline p = channel.pipeline();
               if (p.get("fabric:splitter") != null) {
                  p.remove("fabric:splitter");
               }

               PacketEncoder enc = new PacketEncoder(protocol);
               if (p.get("encoder") != null) {
                  p.replace("encoder", "encoder", enc);
               } else if (p.get("outbound_config") != null) {
                  p.replace("outbound_config", "encoder", enc);
               } else {
                  p.addAfter("prepender", "encoder", enc);
               }

               BundlerInfo bh = protocol.bundlerInfo();
               if (bh != null) {
                  PacketBundleUnpacker u = new PacketBundleUnpacker(bh);
                  if (p.get("unbundler") != null) {
                     p.replace("unbundler", "unbundler", u);
                  } else {
                     p.addAfter("encoder", "unbundler", u);
                  }
               }
            } catch (Exception var6x) {
               LOGGER.error("[PB] Failed safe outbound transition to {}", protocol.id(), var6x);
            }
         };
         if (channel.eventLoop().inEventLoop()) {
            swap.run();
         } else {
            try {
               channel.eventLoop().submit(swap).sync();
            } catch (InterruptedException var8) {
               Thread.currentThread().interrupt();
            }
         }

         info.cancel();
      }
   }

   @Inject(
      method = {"setupInboundProtocol"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private <T extends PacketListener> void setupInboundProtocol$safe(ProtocolInfo<T> protocol, T listener, CallbackInfo info) {
      Connection self = (Connection)this;
      if (protocol.flow() != self.getReceiving()) {
         throw new IllegalStateException("Invalid inbound protocol: " + protocol.id());
      } else {
         ConnectionAccessor accessor = (ConnectionAccessor)this;
         accessor.setPacketListener(listener);
         Channel channel = accessor.getChannel();
         Runnable swap = () -> {
            try {
               ChannelPipeline p = channel.pipeline();
               if (p.get("fabric:merger") != null) {
                  p.remove("fabric:merger");
               }

               PacketDecoder dec = new PacketDecoder(protocol);
               if (p.get("decoder") != null) {
                  p.replace("decoder", "decoder", dec);
               } else if (p.get("inbound_config") != null) {
                  p.replace("inbound_config", "decoder", dec);
               }

               channel.config().setAutoRead(true);
               BundlerInfo bh = protocol.bundlerInfo();
               if (bh != null) {
                  PacketBundlePacker b = new PacketBundlePacker(bh);
                  if (p.get("bundler") != null) {
                     p.replace("bundler", "bundler", b);
                  } else {
                     p.addAfter("decoder", "bundler", b);
                  }
               }
            } catch (Exception var6x) {
               LOGGER.error("[PB] Failed safe inbound transition to {}", protocol.id(), var6x);
            }
         };
         if (channel.eventLoop().inEventLoop()) {
            swap.run();
         } else {
            try {
               channel.eventLoop().submit(swap).sync();
            } catch (InterruptedException var9) {
               Thread.currentThread().interrupt();
            }
         }

         info.cancel();
      }
   }
}
