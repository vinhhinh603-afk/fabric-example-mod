package night.mixins;

import net.minecraft.client.player.RemotePlayer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.entity.LivingEntity;
import night.Night;
import night.modules.impl.visuals.PopChamsModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LivingEntityRenderer.class})
public abstract class PopChamsPoseMixin {
   @Inject(
      method = {"extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V"},
      at = {@At("TAIL")},
      require = 1
   )
   private void cheatsmc$frozenLimbs(LivingEntity entity, LivingEntityRenderState state, float partialTicks, CallbackInfo ci) {
      if (entity instanceof RemotePlayer && Night.MODULE_MANAGER != null) {
         PopChamsModule pop = Night.MODULE_MANAGER.getModule(PopChamsModule.class);
         if (pop != null && pop.isToggled() && pop.isGhost(entity)) {
            state.walkAnimationPos = entity.walkAnimation.position();
            state.walkAnimationSpeed = Math.min(entity.walkAnimation.speed(), 1.0F);
         }
      }
   }
}
