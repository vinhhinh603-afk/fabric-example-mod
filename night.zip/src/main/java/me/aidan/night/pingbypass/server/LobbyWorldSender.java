package night.pingbypass.server;

import com.google.common.collect.Sets;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.Holder.Reference;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundLoginPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetHeldSlotPacket;
import net.minecraft.network.protocol.game.CommonPlayerSpawnInfo;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.PositionMoveRotation;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.BuiltinDimensionTypes;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LobbyWorldSender {
   private static final Logger LOGGER = LoggerFactory.getLogger(LobbyWorldSender.class);

   private LobbyWorldSender() {
   }

   public static void sendLobbyWorld(Connection toClient, RegistryAccess registryManager) {
      LOGGER.info("Sending lobby world to client...");

      try {
         Registry dimRegistry = registryManager.lookupOrThrow(Registries.DIMENSION_TYPE);
         Reference overworldType = dimRegistry.getOrThrow(BuiltinDimensionTypes.OVERWORLD);
         HashSet dimensionIds = Sets.newHashSet(new ResourceKey[]{Level.OVERWORLD, Level.NETHER, Level.END});
         CommonPlayerSpawnInfo spawnInfo = new CommonPlayerSpawnInfo(
            overworldType, Level.OVERWORLD, 0L, GameType.SPECTATOR, null, false, true, Optional.empty(), 0, 63
         );
         send(toClient, new ClientboundLoginPacket(1337, false, dimensionIds, 1, 16, 16, false, true, false, spawnInfo, false, false));
         send(toClient, new ClientboundPlayerAbilitiesPacket(createLobbyAbilities()));
         send(toClient, new ClientboundSetHeldSlotPacket(0));
         send(toClient, new ClientboundPlayerPositionPacket(1, new PositionMoveRotation(new Vec3(0.0, 240.0, 0.0), Vec3.ZERO, 0.0F, 0.0F), Set.of()));
         send(toClient, new ClientboundGameEventPacket(ClientboundGameEventPacket.LEVEL_CHUNKS_LOAD_START, 0.0F));
         LOGGER.info("Lobby world sent successfully.");
      } catch (Exception var6) {
         LOGGER.error("Failed to send lobby world", var6);
      }
   }

   private static void send(Connection connection, Packet<?> packet) {
      if (connection.isConnected()) {
         connection.send(packet);
      }
   }

   private static Abilities createLobbyAbilities() {
      Abilities abilities = new Abilities();
      abilities.mayfly = true;
      abilities.flying = true;
      abilities.invulnerable = true;
      return abilities;
   }
}
