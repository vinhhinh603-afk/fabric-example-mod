package night.pingbypass.protocol;

import net.minecraft.network.Connection;

@FunctionalInterface
public interface PbPacketHandler<T extends PbPacket> {
   void handle(T var1, Connection var2);
}
