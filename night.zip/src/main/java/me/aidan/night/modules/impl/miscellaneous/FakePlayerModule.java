package night.modules.impl.miscellaneous;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import lombok.Generated;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket;
import net.minecraft.network.protocol.game.ClientboundTeleportEntityPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Action;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Entry;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.CombatRules;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.PositionMoveRotation;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientConnectEvent;
import night.events.impl.ClientDisconnectEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.PlayerDeathEvent;
import night.events.impl.PlayerPopEvent;
import night.events.impl.PlayerUpdateEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.TickEvent;
import night.mixins.accessors.PlayerListS2CPacketAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.CategorySetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.StringSetting;
import night.utils.minecraft.DamageUtils;
import night.utils.minecraft.FakePlayerDamagePolicy;
import night.utils.minecraft.WorldUtils;
import night.utils.rotations.RotationUtils;
import night.utils.system.MathUtils;
import night.utils.system.Timer;

@RegisterModule(
   name = "FakePlayer",
   description = "Spawns in a fake player entity that you can use to test modules on.",
   category = Module.Category.MISCELLANEOUS,
   proxyEnhanced = true
)
public class FakePlayerModule extends Module {
   public StringSetting name = new StringSetting("Name", "The name that will be assigned to the fake player.", "Dummy");
   public NumberSetting health = new NumberSetting("Health", "The amount of health that will be assigned to the fake player.", 20.0F, 1.0F, 20.0F);
   public NumberSetting absorption = new NumberSetting("Absorption", "The amount of absorption that will be assigned to the fake player.", 16, 0, 16);
   public CategorySetting movementCategory = new CategorySetting("Movement", "The category that contains settings related to movement.");
   public ModeSetting movementMode = new ModeSetting(
      "Movement",
      "Mode",
      "The mode that will be used for the fake player's movement.",
      new CategorySetting.Visibility(this.movementCategory),
      "None",
      new String[]{"None", "Random"}
   );
   public NumberSetting velocity = new NumberSetting(
      "Velocity", "Velocity", "The velocity to apply on the fake player.", new CategorySetting.Visibility(this.movementCategory), 0.3F, 0.1F, 0.4F
   );
   public BooleanSetting changeDirection = new BooleanSetting(
      "ChangeDirection",
      "Changes the player's direction when a specified amount of time has passed.",
      new CategorySetting.Visibility(this.movementCategory),
      false
   );
   public NumberSetting timeout = new NumberSetting(
      "Timeout", "The amount of time that it takes for the player to change direction.", new BooleanSetting.Visibility(this.changeDirection, true), 5, 1, 15
   );
   public BooleanSetting simulateDamage = new BooleanSetting("SimulateDamage", "Simulate local damage, regeneration and unlimited totem pops.", true);
   private int simulationTicks;
   private int simulatedPops;
   private int hurtTicks;
   private float previousDamage;
   private RemotePlayer player = null;
   private double[] direction = this.generateDirection();
   private final Timer timer = new Timer();
   private boolean stepping = false;
   private final Timer stepTimer = new Timer();
   private FakePlayerModule.RecordState recordState = FakePlayerModule.RecordState.NONE;
   private final List<FakePlayerModule.RecordFrame> frames = new ArrayList<>();
   private int playIndex = 0;

   public void startRecording() {
      if (this.player == null) {
         Night.CHAT_MANAGER.warn("Spawn a fake player first before recording!");
      } else {
         this.frames.clear();
         this.recordState = FakePlayerModule.RecordState.RECORDING;
         Night.CHAT_MANAGER.tagged("Started recording movements...", "FakePlayer");
      }
   }

   public void stopRecording() {
      this.recordState = FakePlayerModule.RecordState.NONE;
      Night.CHAT_MANAGER.tagged("Record!", "FakePlayer");
   }

   public void startPlaying() {
      if (this.frames.isEmpty()) {
         Night.CHAT_MANAGER.warn("No recorded frames to play! Use '.fakeplayer record' first.");
      } else {
         if (this.player == null) {
            this.setToggled(true);
         }

         this.recordState = FakePlayerModule.RecordState.PLAYING;
         this.playIndex = 0;
         Night.CHAT_MANAGER.tagged("Playing recorded movements in a loop...", "FakePlayer");
      }
   }

   @SubscribeEvent
   public void onDisconnect(ClientConnectEvent event) {
      if (this.isToggled()) {
         this.setToggled(false);
      }
   }

   @SubscribeEvent
   public void onPlayerDeath(PlayerDeathEvent event) {
      if (event.getPlayer() == mc.player) {
         if (this.isToggled()) {
            this.setToggled(false);
         }
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (mc.level != null && mc.player != null) {
         Packet<?> packet2 = event.getPacket();
         if (packet2 instanceof ClientboundExplodePacket explosion && this.canSimulate()) {
            RemotePlayer target = this.player;
            ClientLevel level = mc.level;
            mc.execute(() -> {
               if (this.canSimulate() && this.player == target && mc.level == level) {
                  float damage = DamageUtils.getDamage(target, target.getBoundingBox(), explosion.center(), explosion.radius(), null, false);
                  this.applySimulatedDamage(damage);
               }
            });
         }

         ClientboundEntityEventPacket packet;
         if (packet2 instanceof ClientboundEntityEventPacket
            && (packet = (ClientboundEntityEventPacket)packet2).getEventId() == 3
            && packet.getEntity(mc.level) == mc.player
            && this.isToggled()) {
            this.setToggled(false);
         }
      }
   }

   private boolean canSimulate() {
      return this.isToggled()
         && this.simulateDamage.getValue()
         && !this.isRunningOnProxy()
         && mc.player != null
         && mc.level != null
         && this.player != null
         && this.player.level() == mc.level;
   }

   @SubscribeEvent
   public void onClientDisconnect(ClientDisconnectEvent event) {
      if (this.isToggled()) {
         mc.execute(() -> this.setToggled(false));
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      if (event.getPacket() instanceof ServerboundAttackPacket attack
         && this.isToggled()
         && this.player != null
         && attack.entityId() == this.player.getId()
         && !this.isRunningOnProxy()) {
         event.setCancelled(true);
         RemotePlayer target = this.player;
         mc.execute(
            () -> {
               if (this.canSimulate() && this.player == target) {
                  float strength = mc.player.getAttackStrengthScale(0.5F);
                  float raw = (float)mc.player.getAttributeValue(Attributes.ATTACK_DAMAGE) * (0.2F + strength * strength * 0.8F);
                  float damage = CombatRules.getDamageAfterAbsorb(
                     target,
                     raw,
                     mc.level.damageSources().playerAttack(mc.player),
                     target.getArmorValue(),
                     (float)target.getAttributeValue(Attributes.ARMOR_TOUGHNESS)
                  );
                  if (target.hasEffect(MobEffects.RESISTANCE)) {
                     damage *= Math.max(0.0F, 1.0F - (target.getEffect(MobEffects.RESISTANCE).getAmplifier() + 1) * 0.2F);
                  }

                  int protection = 0;

                  for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                     ItemEnchantments enchantments = target.getItemBySlot(slot).getEnchantments();

                     for (Holder<Enchantment> enchantment : enchantments.keySet()) {
                        if (enchantment.getRegisteredName().equals("minecraft:protection")) {
                           protection += enchantments.getLevel(enchantment);
                        }
                     }
                  }

                  damage = CombatRules.getDamageAfterMagicAbsorb(damage, protection);
                  this.applySimulatedDamage(damage);
               }
            }
         );
      }
   }

   private void applySimulatedDamage(float damage) {
      if (this.canSimulate()) {
         float hit = FakePlayerDamagePolicy.effectiveHit(damage, this.previousDamage, this.hurtTicks);
         if (!(hit <= 0.0F)) {
            if (this.hurtTicks <= 0) {
               this.hurtTicks = 10;
            }

            this.previousDamage = damage;
            FakePlayerDamagePolicy.Result result = FakePlayerDamagePolicy.apply(this.player.getHealth(), this.player.getAbsorptionAmount(), hit);
            this.player.hurtTime = 10;
            this.player.setAbsorptionAmount(result.absorption());
            if (result.pop()) {
               this.player.setHealth(9.0F);
               this.player.removeAllEffects();
               this.player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 900, 1));
               this.player.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
               if (mc.getConnection() != null) {
                  mc.getConnection().handleEntityEvent(new ClientboundEntityEventPacket(this.player, (byte)35));
               }

               Night.EVENT_HANDLER.post(new PlayerPopEvent(this.player, ++this.simulatedPops));
            } else {
               this.player.setHealth(result.health());
            }
         }
      }
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (this.canSimulate()) {
         this.simulationTicks++;
         if (this.hurtTicks > 0) {
            this.hurtTicks--;
         }

         if (!this.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            this.player.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
         }

         if (this.simulationTicks % 80 == 0) {
            this.player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 400, 1));
            this.player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 6000, 0));
            this.player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0));
            this.player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 2400, 3));
            this.player.setAbsorptionAmount(16.0F);
         }

         if (this.simulationTicks % 25 == 0 && this.player.hasEffect(MobEffects.REGENERATION)) {
            this.player.setHealth(Math.min(this.player.getMaxHealth(), this.player.getHealth() + 1.0F));
         }
      }

      if (mc.player != null
         && (mc.player.isDeadOrDying() || mc.player.getHealth() <= 0.0F || !mc.player.isAlive() || mc.gui != null && mc.gui.screen() instanceof DeathScreen)
         && this.isToggled()) {
         this.setToggled(false);
      }
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.recordState == FakePlayerModule.RecordState.RECORDING) {
            this.frames
               .add(
                  new FakePlayerModule.RecordFrame(
                     mc.player.getX(),
                     mc.player.getY(),
                     mc.player.getZ(),
                     mc.player.getYRot(),
                     mc.player.getXRot(),
                     mc.player.getYHeadRot(),
                     mc.player.getPose()
                  )
               );
         } else if (this.recordState == FakePlayerModule.RecordState.PLAYING) {
            if (this.player != null && !this.frames.isEmpty()) {
               this.playIndex++;
               if (this.playIndex >= this.frames.size()) {
                  this.playIndex = 0;
               }

               this.broadcastPosition();
            }
         } else if (this.player != null) {
            if (this.movementMode.getValue().equalsIgnoreCase("Random")) {
               BlockPos position = this.player.blockPosition();
               boolean changeDir = false;
               if (this.changeDirection.getValue() && this.timer.hasTimeElapsed(this.timeout.getValue().longValue() * 1000L)) {
                  changeDir = true;
                  this.timer.reset();
               }

               if (this.hasObstruction(position)) {
                  for (Direction dir : Direction.values()) {
                     BlockPos offsetPosition = position.relative(dir);
                     if ((
                           WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition))
                              || WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition.above()))
                        )
                        && WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition.above().above()))
                        && this.player.getDirection().equals(dir)) {
                        changeDir = true;
                        this.timer.reset();
                     }
                  }
               }

               if (changeDir) {
                  double[] newDirection = this.generateDirection();
                  if (this.direction == newDirection) {
                     newDirection = this.generateDirection();
                  }

                  this.direction = newDirection;
               }

               if (this.stepping && this.stepTimer.hasTimeElapsed(500L)) {
                  this.stepping = false;
                  this.stepTimer.reset();
               }

               this.player.jumpFromGround();
               float[] rotations = RotationUtils.getRotations(
                  this.player, this.player.getX() + this.direction[0], this.player.getY() + this.fixAxisY(this.player), this.player.getZ() + this.direction[1]
               );
               this.player.setYRot(rotations[0]);
               this.player.yHeadRot = rotations[0];
               this.player.setXRot(0.0F);
               this.player
                  .setPos(this.player.getX() + this.direction[0], this.player.getY() + this.fixAxisY(this.player), this.player.getZ() + this.direction[1]);
               this.broadcastPosition();
            }
         }
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (this.recordState == FakePlayerModule.RecordState.PLAYING && this.player != null && !this.frames.isEmpty()) {
         int currentIndex = this.playIndex;
         int nextIndex = (currentIndex + 1) % this.frames.size();
         FakePlayerModule.RecordFrame current = this.frames.get(currentIndex);
         FakePlayerModule.RecordFrame next = this.frames.get(nextIndex);
         float delta = event.getTickDelta();
         if (nextIndex == 0) {
            delta = 0.0F;
         }

         double x = Mth.lerp(delta, current.x(), next.x());
         double y = Mth.lerp(delta, current.y(), next.y());
         double z = Mth.lerp(delta, current.z(), next.z());
         float yRot = Mth.rotLerp(delta, current.yRot(), next.yRot());
         float xRot = Mth.lerp(delta, current.xRot(), next.xRot());
         float yHeadRot = Mth.rotLerp(delta, current.yHeadRot(), next.yHeadRot());
         this.player.setPos(x, y, z);
         this.player.setYRot(yRot);
         this.player.setXRot(xRot);
         this.player.yHeadRot = yHeadRot;
         this.player.yBodyRot = yRot;
         this.player.setOldPosAndRot();
         this.player.yHeadRotO = yHeadRot;
         this.player.yBodyRotO = yRot;
         this.player.setPose(current.pose());
         this.player.refreshDimensions();
      }
   }

   private void broadcastPosition() {
      if (this.isRunningOnProxy() && Night.PROXY_SERVER != null) {
         if (this.player != null) {
            ClientboundTeleportEntityPacket teleportPacket = ClientboundTeleportEntityPacket.teleport(
               this.player.getId(), PositionMoveRotation.of(this.player), Set.of(), this.player.onGround()
            );

            for (Connection conn : Night.PROXY_SERVER.getConnections()) {
               if (conn.isConnected()) {
                  conn.send(teleportPacket);
               }
            }
         }
      }
   }

   @Override
   public void onEnable() {
      if (!this.shouldRunOnProxy()) {
         if (mc.level != null && mc.player != null) {
            this.simulationTicks = this.simulatedPops = this.hurtTicks = 0;
            this.previousDamage = 0.0F;
            this.player = new RemotePlayer(mc.level, new GameProfile(UUID.randomUUID(), this.name.getValue()));
            this.player.copyPosition(mc.player);
            this.player.setId(-673);
            this.player.restoreFrom(mc.player);
            this.player.setHealth(this.health.getValue().floatValue());
            this.player.setAbsorptionAmount(this.absorption.getValue().floatValue());

            for (EquipmentSlot slot : EquipmentSlot.values()) {
               this.player.setItemSlot(slot, mc.player.getItemBySlot(slot).copy());
            }

            this.player.getAttribute(Attributes.ARMOR).setBaseValue(mc.player.getAttributeValue(Attributes.ARMOR));
            this.player.getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(mc.player.getAttributeValue(Attributes.ARMOR_TOUGHNESS));
            mc.level.addEntity(this.player);
            if (this.simulateDamage.getValue()) {
               this.player.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
            }

            this.player.tick();
            this.timer.reset();
            this.broadcastSpawn();
            Night.CHAT_MANAGER.tagged("Spawned fake player " + this.name.getValue(), "FakePlayer");
         } else {
            this.setToggled(false);
         }
      }
   }

   @Override
   public void onDisable() {
      this.recordState = FakePlayerModule.RecordState.NONE;
      if (!this.shouldRunOnProxy()) {
         if (this.player != null) {
            this.broadcastDespawn();
            if (this.player.level() instanceof ClientLevel level) {
               level.removeEntity(this.player.getId(), RemovalReason.DISCARDED);
            }

            this.player = null;
            Night.CHAT_MANAGER.tagged("Removed fake player.", "FakePlayer");
         }
      }
   }

   private void broadcastSpawn() {
      if (this.isRunningOnProxy() && Night.PROXY_SERVER != null) {
         if (this.player != null) {
            List<Entry> entries = List.of(new Entry(this.player.getUUID(), this.player.getGameProfile(), false, 0, GameType.SURVIVAL, null, false, 0, null));
            ClientboundPlayerInfoUpdatePacket infoPacket = new ClientboundPlayerInfoUpdatePacket(EnumSet.of(Action.ADD_PLAYER), Collections.emptyList());
            ((PlayerListS2CPacketAccessor)infoPacket).setActions(EnumSet.of(Action.ADD_PLAYER));
            ((PlayerListS2CPacketAccessor)infoPacket).setEntries(entries);
            ClientboundAddEntityPacket spawnPacket = new ClientboundAddEntityPacket(
               this.player.getId(),
               this.player.getUUID(),
               this.player.getX(),
               this.player.getY(),
               this.player.getZ(),
               this.player.getXRot(),
               this.player.getYRot(),
               this.player.getType(),
               0,
               this.player.getDeltaMovement(),
               this.player.getYHeadRot()
            );

            for (Connection conn : Night.PROXY_SERVER.getConnections()) {
               if (conn.isConnected()) {
                  conn.send(infoPacket);
                  conn.send(spawnPacket);
               }
            }
         }
      }
   }

   private void broadcastDespawn() {
      if (this.isRunningOnProxy() && Night.PROXY_SERVER != null) {
         if (this.player != null) {
            ClientboundRemoveEntitiesPacket removePacket = new ClientboundRemoveEntitiesPacket(new int[]{this.player.getId()});
            ClientboundPlayerInfoRemovePacket infoRemovePacket = new ClientboundPlayerInfoRemovePacket(List.of(this.player.getUUID()));

            for (Connection conn : Night.PROXY_SERVER.getConnections()) {
               if (conn.isConnected()) {
                  conn.send(removePacket);
                  conn.send(infoRemovePacket);
               }
            }
         }
      }
   }

   public boolean hasObstruction(BlockPos position) {
      for (Direction direction : Direction.values()) {
         BlockPos offsetPosition = position.relative(direction);
         if (WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition))) {
            return true;
         }

         if (WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition.above()))) {
            return true;
         }
      }

      return false;
   }

   public float fixAxisY(Player player) {
      if (mc.level.getBlockState(player.blockPosition().below()).getBlock() == Blocks.AIR && !this.stepping) {
         return -1.0F;
      } else if (this.hasObstruction(player.blockPosition())) {
         for (Direction direction : Direction.values()) {
            BlockPos offsetPosition = player.blockPosition().relative(direction);
            if (WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition))
               && !WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition.above()))
               && player.getDirection().equals(direction)
               && !WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition.above().above()))) {
               this.stepping = true;
               this.stepTimer.reset();
               return 1.0F;
            }

            if (WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition.above()))
               && player.getDirection().equals(direction)
               && !WorldUtils.blocksMovement(mc.level.getBlockState(offsetPosition.above().above()))) {
               this.stepping = true;
               this.stepTimer.reset();
               return 2.0F;
            }
         }

         return 0.0F;
      } else {
         return 0.0F;
      }
   }

   public double[] generateDirection() {
      double angle = MathUtils.random(Math.PI * 2, 0.0);
      double[] dir = new double[]{-Math.sin(angle), Math.cos(angle)};
      return new double[]{dir[0] * this.velocity.getValue().floatValue(), dir[1] * this.velocity.getValue().floatValue()};
   }

   @Generated
   public RemotePlayer getPlayer() {
      return this.player;
   }

   @Generated
   public FakePlayerModule.RecordState getRecordState() {
      return this.recordState;
   }

   public record RecordFrame(double x, double y, double z, float yRot, float xRot, float yHeadRot, Pose pose) {
   }

   private static enum RecordState {
      NONE,
      RECORDING,
      PLAYING;
   }
}
