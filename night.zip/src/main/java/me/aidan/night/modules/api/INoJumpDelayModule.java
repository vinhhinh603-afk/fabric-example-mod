package night.modules.api;

public interface INoJumpDelayModule {
   boolean isToggled();

   int getTicksValue();
}
