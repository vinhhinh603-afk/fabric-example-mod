package night.modules.impl.visuals;

import com.mojang.authlib.GameProfile;
import java.awt.Color;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import night.events.SubscribeEvent;
import night.events.impl.PlayerDeathEvent;
import night.events.impl.PlayerPopEvent;
import night.events.impl.TickEvent;
import night.mixins.accessors.LimbAnimatorAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.animations.Easing;
import night.utils.color.ColorUtils;
import night.utils.graphics.NoRenderEffects;

@RegisterModule(
   name = "PopChams",
   description = "Renders chams on a frozen snapshot of the entity's pose the moment they pop a totem.",
   category = Module.Category.VISUALS
)
public class PopChamsModule extends Module {
   public NumberSetting duration = new NumberSetting("Duration", "The duration for the pop chams fade.", 1500, 0, 5000);
   public NumberSetting yOffset = new NumberSetting("YOffset", "The vertical float/rise offset for pop chams.", 0, -5, 5);
   public NumberSetting motion = new NumberSetting("Motion", "Vertical drift over the lifetime; zero uses legacy YOffset.", 0.0F, -5.0F, 5.0F);
   public BooleanSetting animate = new BooleanSetting("Animate", "Keep the captured limb pose as in Mio; off uses neutral limbs.", true);
   public BooleanSetting boost = new BooleanSetting(
      "Boost", "Use a randomized limb pose when Animate is on.", new BooleanSetting.Visibility(this.animate, true), false
   );
   public BooleanSetting death = new BooleanSetting("Death", "Also capture players when they die.", false);
   public ModeSetting mode = new ModeSetting(
      "Mode", "The rendering that will be applied to the pop chams.", "Both", new String[]{"Fill", "Outline", "Line", "Both"}
   );
   public ColorSetting fillColor = new ColorSetting(
      "FillColor", "The color used for the fill rendering.", new ModeSetting.Visibility(this.mode, "Fill", "Both"), ColorUtils.getDefaultFillColor()
   );
   public ColorSetting outlineColor = new ColorSetting(
      "OutlineColor",
      "The color used for the outline rendering.",
      new ModeSetting.Visibility(this.mode, "Outline", "Line", "Both"),
      ColorUtils.getDefaultOutlineColor()
   );
   private static final EquipmentSlot[] COPIED_SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   private final Map<RemotePlayer, Long> ghosts = new ConcurrentHashMap<>();
   private int nextId = -90000;

   @SubscribeEvent
   public void onPlayerPop(PlayerPopEvent event) {
      this.capture(event.getPlayer());
   }

   @SubscribeEvent
   public void onPlayerDeath(PlayerDeathEvent event) {
      if (this.death.getValue()) {
         this.capture(event.getPlayer());
      }
   }

   @Override
   public void onDisable() {
      this.ghosts.keySet().forEach(this::despawn);
      this.ghosts.clear();
   }

   private void despawn(RemotePlayer ghost) {
      if (ghost.level() instanceof ClientLevel level) {
         level.removeEntity(ghost.getId(), RemovalReason.DISCARDED);
      }
   }

   public boolean isGhost(Entity entity) {
      return this.ghosts.containsKey(entity);
   }

   public boolean shouldFill() {
      return this.mode.getValue().equals("Fill") || this.mode.getValue().equals("Both");
   }

   public boolean shouldOutline() {
      return this.mode.getValue().equals("Line") || this.mode.getValue().equals("Outline") || this.mode.getValue().equals("Both");
   }

   public Color getFillColor(RemotePlayer ghost) {
      return this.withFade(this.fillColor.getColor(), ghost);
   }

   public Color getOutlineColor(RemotePlayer ghost) {
      return this.withFade(this.outlineColor.getColor(), ghost);
   }

   public float getYOffset(RemotePlayer ghost) {
      float offset = this.motion.getValue().floatValue();
      if (offset == 0.0F) {
         offset = this.yOffset.getValue().floatValue();
      }

      if (offset == 0.0F) {
         return 0.0F;
      } else {
         Long startTime = this.ghosts.get(ghost);
         if (startTime == null) {
            return 0.0F;
         } else {
            int dur = this.duration.getValue().intValue();
            if (dur <= 0) {
               return 0.0F;
            } else {
               float progress = Easing.toDelta(startTime, dur);
               return offset * progress;
            }
         }
      }
   }

   private Color withFade(Color color, RemotePlayer ghost) {
      Long startTime = this.ghosts.get(ghost);
      if (startTime == null) {
         return color;
      } else {
         int durationMs = this.duration.getValue().intValue();
         float ease = durationMs <= 0 ? 0.0F : 1.0F - Easing.toDelta(startTime, durationMs);
         return ColorUtils.getColor(color, (int)(color.getAlpha() * ease));
      }
   }

   private void capture(Player player) {
      if (!NoRenderEffects.popChams()) {
         if (this.isToggled() && mc.level != null && player != null && player != mc.player && !this.isGhost(player)) {
            ClientLevel capturedLevel = mc.level;
            mc.execute(() -> {
               if (!NoRenderEffects.popChams() && this.isToggled() && mc.level == capturedLevel) {
                  GameProfile profile = new GameProfile(UUID.randomUUID(), "");
                  RemotePlayer ghost = new RemotePlayer(mc.level, profile);
                  ghost.setId(this.nextId--);
                  ghost.setPos(player.getX(), player.getY(), player.getZ());
                  ghost.xo = player.getX();
                  ghost.yo = player.getY();
                  ghost.zo = player.getZ();
                  ghost.xOld = player.getX();
                  ghost.yOld = player.getY();
                  ghost.zOld = player.getZ();
                  ghost.setYRot(player.getYRot());
                  ghost.setXRot(player.getXRot());
                  ghost.yRotO = player.getYRot();
                  ghost.xRotO = player.getXRot();
                  ghost.setYHeadRot(player.getYHeadRot());
                  ghost.yHeadRotO = player.getYHeadRot();
                  ghost.yBodyRot = player.yBodyRot;
                  ghost.yBodyRotO = player.yBodyRot;
                  ghost.setPose(player.getPose());
                  ghost.setShiftKeyDown(player.isShiftKeyDown());
                  ghost.setSwimming(player.isSwimming());
                  ghost.setSprinting(player.isSprinting());
                  ghost.refreshDimensions();
                  ghost.walkAnimation.setSpeed(player.walkAnimation.speed());
                  ((LimbAnimatorAccessor)ghost.walkAnimation).setPos(player.walkAnimation.position() * 2.0F);
                  if (!this.animate.getValue()) {
                     ghost.walkAnimation.setSpeed(0.0F);
                     ((LimbAnimatorAccessor)ghost.walkAnimation).setPos(0.0F);
                  } else if (this.boost.getValue()) {
                     ghost.walkAnimation.setSpeed((float)(0.2 + Math.random() * 0.8));
                     ((LimbAnimatorAccessor)ghost.walkAnimation).setPos(0.0F);
                  }

                  ghost.swinging = player.swinging;
                  ghost.swingTime = player.swingTime;
                  ghost.swingingArm = player.swingingArm;
                  ghost.attackAnim = player.attackAnim;
                  ghost.oAttackAnim = player.attackAnim;
                  if (this.animate.getValue() && this.boost.getValue()) {
                     ghost.swinging = false;
                     ghost.attackAnim = ghost.oAttackAnim = 0.0F;
                  }

                  ghost.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
                  ghost.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);

                  for (EquipmentSlot slot : COPIED_SLOTS) {
                     ghost.setItemSlot(slot, player.getItemBySlot(slot).copy());
                  }

                  mc.level.addEntity(ghost);
                  this.ghosts.put(ghost, System.currentTimeMillis());
               }
            });
         }
      }
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (NoRenderEffects.popChams()) {
         this.ghosts.keySet().forEach(this::despawn);
         this.ghosts.clear();
      } else {
         long now = System.currentTimeMillis();
         this.ghosts.entrySet().removeIf(entry -> {
            if (entry.getKey().level() == mc.level && this.duration.getValue().intValue() > 0 && now - entry.getValue() < this.duration.getValue().intValue()) {
               return false;
            } else {
               this.despawn(entry.getKey());
               return true;
            }
         });
      }
   }
}
