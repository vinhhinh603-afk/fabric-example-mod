package night.modules.impl.miscellaneous;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Plane;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.WorldUtils;

@RegisterModule(
   name = "Scaffold",
   description = "Places blocks under the player to bridge automatically.",
   category = Module.Category.MISCELLANEOUS
)
public class ScaffoldModule extends Module {
   public ModeSetting autoSwitch = new ModeSetting(
      "Switch", "The mode that will be used for automatically switching to blocks.", "Silent", InventoryUtils.SWITCH_MODES
   );
   public NumberSetting range = new NumberSetting("Range", "Range to place blocks.", 4.0, 1.0, 6.0);
   public BooleanSetting keepY = new BooleanSetting("KeepY", "Maintains the player's Y level while moving.", false);
   public BooleanSetting downwards = new BooleanSetting("Downwards", "Places blocks below your feet when sneaking.", true);
   public BooleanSetting tower = new BooleanSetting("Tower", "Quickly towers up when jumping.", true);
   public NumberSetting towerSpeed = new NumberSetting("TowerSpeed", "Vertical tower speed.", new BooleanSetting.Visibility(this.tower, true), 0.42, 0.1, 1.0);
   public BooleanSetting rotate = new BooleanSetting("Rotate", "Rotates towards block placements.", true);
   public BooleanSetting strictDirection = new BooleanSetting("StrictDirection", "Only places using directions facing you.", false);
   public BooleanSetting airPlace = new BooleanSetting("AirPlace", "Places blocks in the air without support.", false);
   public NumberSetting delay = new NumberSetting("Delay", "Delay in ticks between placements.", 0, 0, 10);
   public BooleanSetting render = new BooleanSetting("Render", "Renders placed positions.", true);
   private int groundPosY = Integer.MIN_VALUE;
   private BlockPos lastPlacement = null;
   private Block currentScaffoldBlock = null;
   private int ticks = 0;
   private final Map<BlockPos, Long> pendingAttempts = new HashMap<>();

   @Override
   public void onEnable() {
      this.groundPosY = Integer.MIN_VALUE;
      this.lastPlacement = null;
      this.ticks = 0;
      this.pendingAttempts.clear();
      WorldUtils.clearPredictedPlacements();
   }

   @Override
   public void onDisable() {
      this.groundPosY = Integer.MIN_VALUE;
      this.lastPlacement = null;
      this.currentScaffoldBlock = null;
      this.pendingAttempts.clear();
      WorldUtils.clearPredictedPlacements();
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.ticks < this.delay.getValue().intValue()) {
            this.ticks++;
         } else {
            int maxSlot = !this.autoSwitch.getValue().equalsIgnoreCase("AltSwap") && !this.autoSwitch.getValue().equalsIgnoreCase("AltPickup") ? 8 : 35;
            int slot = this.findValidBlockSlot(0, maxSlot);
            if (slot == -1) {
               Input real = mc.player.input != null ? mc.player.input.keyPresses : Input.EMPTY;
               if (!real.shift()) {
                  mc.player.input.keyPresses = new Input(real.forward(), real.backward(), real.left(), real.right(), real.jump(), true, real.sprint());
               }
            } else {
               if (this.tower.getValue() && mc.options.keyJump.isDown() && !this.isMovingHorizontally()) {
                  mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, this.towerSpeed.getValue().doubleValue(), mc.player.getDeltaMovement().z);
               }

               int posY = (int)Math.floor(mc.player.getY());
               if (this.keepY.getValue() && this.isMovingHorizontally()) {
                  if (mc.player.onGround() || this.groundPosY < mc.level.getMinY()) {
                     this.groundPosY = posY;
                  }

                  posY = this.groundPosY;
               } else if (this.downwards.getValue() && mc.options.keyShift.isDown()) {
                  posY = mc.player.getBlockY() - 1;
               } else {
                  this.groundPosY = posY;
               }

               BlockPos playerBlockPos = new BlockPos(mc.player.getBlockX(), posY, mc.player.getBlockZ());
               BlockPos targetPos = playerBlockPos.below();
               List<BlockPos> placements = this.getScaffoldPlacements(targetPos);
               if (!placements.isEmpty()) {
                  int prevSlot = mc.player.getInventory().getSelectedSlot();
                  if (InventoryUtils.switchSlot(this.autoSwitch.getValue(), slot, prevSlot)) {
                     for (BlockPos pos : placements) {
                        if (mc.level.getBlockState(pos).canBeReplaced() && !this.isOnCooldown(pos)) {
                           Direction dir = WorldUtils.getDirection(pos, this.strictDirection.getValue());
                           if (dir == null) {
                              if (this.airPlace.getValue()) {
                                 WorldUtils.airPlaceBlock(pos, InteractionHand.MAIN_HAND, this.rotate.getValue() ? "Normal" : "None", this.render.getValue());
                                 this.lastPlacement = pos;
                                 this.predictCollision(pos);
                                 this.markAttempted(pos);
                              }
                           } else if (WorldUtils.placeBlock(pos, dir, InteractionHand.MAIN_HAND, this.rotate.getValue(), false, this.render.getValue())) {
                              this.lastPlacement = pos;
                              this.predictCollision(pos);
                              this.markAttempted(pos);
                           }
                        }
                     }

                     InventoryUtils.switchBack(this.autoSwitch.getValue(), slot, prevSlot);
                     this.ticks = 0;
                  }
               }
            }
         }
      }
   }

   private void predictCollision(BlockPos pos) {
      if (this.currentScaffoldBlock != null) {
         WorldUtils.predictPlacement(pos, this.currentScaffoldBlock);
      }
   }

   @SubscribeEvent
   public void night$onBlockUpdate(PacketReceiveEvent event) {
      if (event.getPacket() instanceof ClientboundBlockUpdatePacket packet2) {
         WorldUtils.clearPredictedPlacement(packet2.getPos());
         this.pendingAttempts.remove(packet2.getPos());
      }
   }

   private boolean isOnCooldown(BlockPos pos) {
      Long last = this.pendingAttempts.get(pos);
      if (last == null) {
         return false;
      } else {
         long cooldownMs = Math.max(50L, Night.SERVER_MANAGER.getPing() * 2L);
         if (System.currentTimeMillis() - last < cooldownMs) {
            return true;
         } else {
            this.pendingAttempts.remove(pos);
            return false;
         }
      }
   }

   private void markAttempted(BlockPos pos) {
      this.pendingAttempts.put(pos, System.currentTimeMillis());
   }

   private boolean isMovingHorizontally() {
      return Math.abs(mc.player.getDeltaMovement().x) > 0.05 || Math.abs(mc.player.getDeltaMovement().z) > 0.05;
   }

   private int findValidBlockSlot(int start, int end) {
      for (int i = start; i <= end; i++) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         BlockItem blockItem;
         Block block;
         Item item;
         if (!stack.isEmpty()
            && (item = stack.getItem()) instanceof BlockItem
            && !(block = (blockItem = (BlockItem)item).getBlock()).defaultBlockState().canBeReplaced()
            && block.defaultBlockState().blocksMotion()) {
            this.currentScaffoldBlock = block;
            return i;
         }
      }

      return -1;
   }

   private List<BlockPos> getScaffoldPlacements(BlockPos targetPos) {
      ArrayList<BlockPos> placements = new ArrayList<>();
      if (this.airPlace.getValue()) {
         if (this.isWithinRange(targetPos)) {
            placements.add(targetPos);
         }

         return placements;
      } else {
         this.ensurePlaceableWithSupport(targetPos, placements);
         if (this.lastPlacement != null) {
            int x0 = this.lastPlacement.getX();
            int y0 = this.lastPlacement.getY();
            int z0 = this.lastPlacement.getZ();
            int x1 = targetPos.getX();
            int y1 = targetPos.getY();
            int z1 = targetPos.getZ();
            int dx = x1 - x0;
            int dy = y1 - y0;
            int dz = z1 - z0;
            int sx = Integer.compare(dx, 0);
            int sy = Integer.compare(dy, 0);
            int sz = Integer.compare(dz, 0);
            dx = Math.abs(dx);
            dy = Math.abs(dy);
            dz = Math.abs(dz);
            int ax = dx << 1;
            int ay = dy << 1;
            int az = dz << 1;
            int steps = 0;
            if (dx >= dy && dx >= dz) {
               int yd = ay - dx;
               int zd = az - dx;

               while (true) {
                  BlockPos p = new BlockPos(x0, y0, z0);
                  this.ensurePlaceableWithSupport(p, placements);
                  steps++;
                  if (steps > 8 || x0 == x1 && y0 == y1 && z0 == z1) {
                     break;
                  }

                  if (yd >= 0) {
                     y0 += sy;
                     yd -= ax;
                  }

                  if (zd >= 0) {
                     z0 += sz;
                     zd -= ax;
                  }

                  x0 += sx;
                  yd += ay;
                  zd += az;
               }
            } else if (dy >= dx && dy >= dz) {
               int xd = ax - dy;
               int zd = az - dy;

               while (true) {
                  BlockPos px = new BlockPos(x0, y0, z0);
                  this.ensurePlaceableWithSupport(px, placements);
                  steps++;
                  if (steps > 8 || x0 == x1 && y0 == y1 && z0 == z1) {
                     break;
                  }

                  if (xd >= 0) {
                     x0 += sx;
                     xd -= ay;
                  }

                  if (zd >= 0) {
                     z0 += sz;
                     zd -= ay;
                  }

                  y0 += sy;
                  xd += ax;
                  zd += az;
               }
            } else {
               int xd = ax - dz;
               int yd = ay - dz;

               while (true) {
                  BlockPos pxx = new BlockPos(x0, y0, z0);
                  this.ensurePlaceableWithSupport(pxx, placements);
                  steps++;
                  if (steps > 8 || x0 == x1 && y0 == y1 && z0 == z1) {
                     break;
                  }

                  if (xd >= 0) {
                     x0 += sx;
                     xd -= az;
                  }

                  if (yd >= 0) {
                     y0 += sy;
                     yd -= az;
                  }

                  z0 += sz;
                  xd += ax;
                  yd += ay;
               }
            }
         }

         return placements;
      }
   }

   private void ensurePlaceableWithSupport(BlockPos pos, List<BlockPos> out) {
      if (mc.level.getBlockState(pos).canBeReplaced()) {
         Direction face = WorldUtils.getDirection(pos, this.strictDirection.getValue());
         if (face != null) {
            if (!out.contains(pos) && this.isWithinRange(pos)) {
               out.add(pos);
            }
         } else {
            BlockPos support = this.getSupportingBlock(pos);
            if (support != null) {
               if (!out.contains(support) && this.isWithinRange(support)) {
                  out.add(support);
               }
            } else {
               BlockPos down = pos.below();

               for (int depth = 0; depth++ < 3 && mc.level.getBlockState(down).canBeReplaced(); down = down.below()) {
                  if (WorldUtils.getDirection(down, this.strictDirection.getValue()) != null) {
                     if (!out.contains(down) && this.isWithinRange(down)) {
                        out.add(down);
                     }
                     break;
                  }
               }
            }

            if (!out.contains(pos) && this.isWithinRange(pos)) {
               out.add(pos);
            }
         }
      }
   }

   private BlockPos getSupportingBlock(BlockPos pos) {
      for (Direction dir : Plane.HORIZONTAL) {
         BlockPos side = pos.relative(dir);
         if (WorldUtils.getDirection(side, this.strictDirection.getValue()) != null) {
            return side;
         }
      }

      return null;
   }

   private boolean isWithinRange(BlockPos pos) {
      return mc.player.distanceToSqr(Vec3.atCenterOf(pos)) <= this.range.getValue().doubleValue() * this.range.getValue().doubleValue();
   }
}
