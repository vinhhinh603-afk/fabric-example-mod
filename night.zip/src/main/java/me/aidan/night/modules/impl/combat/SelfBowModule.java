package night.modules.impl.combat;

import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TippedArrowItem;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.pingbypass.server.ProxyServerTickListener;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.InventoryUtils;

@RegisterModule(
   name = "SelfBow",
   description = "Automatically shoots arrows at you in order to give yourself potion effects.",
   category = Module.Category.COMBAT
)
public class SelfBowModule extends Module {
   public BooleanSetting manual = new BooleanSetting("Manual", "Whether or not to do the self bow manually.", false);
   public ModeSetting autoSwitch = new ModeSetting("Switch", "The mode that will be used for switching slots.", "Normal", new String[]{"None", "Normal"});
   public NumberSetting chargeTime = new NumberSetting("ChargeTime", "The amount of ticks that the module will be charging the bow for.", 4, 0, 20);
   public BooleanSetting effectCycle = new BooleanSetting("EffectCycle", "Fires multiple arrows in case of having more than one arrow type.", false);
   private boolean switched = false;
   private boolean todo = false;
   private boolean first = false;
   private int previousSlot = -1;
   private int chargeTicks = 0;
   private int bestArrow = -1;
   private final ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<>();

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (mc.player != null && mc.level != null) {
         int slot = InventoryUtils.findHotbar(Items.BOW);
         if (this.manual.getValue()) {
            boolean flag = mc.player.isUsingItem() && mc.player.getInventory().getSelectedItem().getItem() == Items.BOW;
            if (flag && !this.todo) {
               if (this.effectCycle.getValue()) {
                  this.findArrows();
               }

               this.todo = true;
               this.first = true;
            }

            if (this.todo) {
               if (mc.player.getInventory().getSelectedItem().getItem() != Items.BOW) {
                  this.todo = false;
                  mc.options.keyUse.setDown(false);
                  return;
               }

               mc.options.keyUse.setDown(true);
            }

            if (!this.todo) {
               return;
            }
         } else {
            if (this.autoSwitch.getValue().equals("None") && mc.player.getInventory().getSelectedItem().getItem() != Items.BOW) {
               Night.CHAT_MANAGER.tagged("You are currently not holding a bow.", this.getName());
               this.setToggled(false);
               return;
            }

            if (!this.autoSwitch.getValue().equals("None") && slot == -1) {
               Night.CHAT_MANAGER.tagged("Could not find a bow in your hotbar.", this.getName());
               this.setToggled(false);
               return;
            }

            if (mc.player.getMainHandItem().getItem() != Items.BOW) {
               InventoryUtils.switchSlot(this.autoSwitch.getValue(), slot, this.previousSlot);
               this.switched = true;
            }

            mc.options.keyUse.setDown(true);
         }

         if (this.chargeTicks < this.chargeTime.getValue().intValue() - (this.first ? 1 : 0)) {
            this.chargeTicks++;
         } else {
            int arrow;
            if (this.effectCycle.getValue() && !this.queue.isEmpty() && (arrow = this.queue.poll()) != this.bestArrow) {
               InventoryUtils.swap("Pickup", arrow, this.bestArrow);
            }

            if (mc.getConnection() != null) {
               ProxyServerTickListener.allowSend(
                  () -> mc.getConnection()
                     .send(
                        new PosRot(
                           Night.POSITION_MANAGER.getServerX(),
                           Night.POSITION_MANAGER.getServerY(),
                           Night.POSITION_MANAGER.getServerZ(),
                           mc.player.getYRot(),
                           -90.0F,
                           Night.POSITION_MANAGER.isServerOnGround(),
                           mc.player.horizontalCollision
                        )
                     )
               );
            }

            mc.options.keyUse.setDown(false);
            mc.gameMode.releaseUsingItem(mc.player);
            this.chargeTicks = 0;
            this.first = false;
            if (!this.effectCycle.getValue() || this.queue.isEmpty()) {
               if (this.manual.getValue()) {
                  this.todo = false;
                  mc.options.keyUse.setDown(false);
               } else {
                  this.setToggled(false);
               }
            }
         }
      }
   }

   @Override
   public void onEnable() {
      if (!this.getNull()) {
         if (this.effectCycle.getValue() && !this.manual.getValue()) {
            this.findArrows();
         }

         this.previousSlot = mc.player.getInventory().getSelectedSlot();
      }
   }

   @Override
   public void onDisable() {
      if (mc.player != null && mc.level != null) {
         if (this.switched) {
            InventoryUtils.switchSlot(this.autoSwitch.getValue(), this.previousSlot, this.previousSlot);
         }

         mc.options.keyUse.setDown(false);
      }
   }

   private void findArrows() {
      this.bestArrow = -1;

      for (int i = 9; i < 36; i++) {
         if (!mc.player.getInventory().getItem(i).isEmpty() && mc.player.getInventory().getItem(i).getItem() instanceof TippedArrowItem) {
            if (this.bestArrow == -1) {
               this.bestArrow = i;
            }

            this.queue.add(i);
         }
      }
   }

   @Override
   public String getMetaData() {
      int chargeTicks = mc.player.getInventory().getSelectedItem().getItem() == Items.BOW ? mc.player.getTicksUsingItem() : 0;
      return String.valueOf(chargeTicks);
   }
}
