package night.modules.impl.visuals.stashfinder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

public class StashFinderStore {
   private final Set<Long> evaluated = new HashSet<>();
   private final List<StashFinderStore.StashData> stashes = new ArrayList<>();
   private File file;
   private boolean dirty = false;
   private long lastSaveMs = 0L;
   private static final long SAVE_INTERVAL_MS = 10000L;

   public static String currentWorldKey() {
      Minecraft mc = Minecraft.getInstance();
      Object base = mc.getCurrentServer() != null
         ? "server_" + mc.getCurrentServer().ip
         : (mc.hasSingleplayerServer() && mc.getSingleplayerServer() != null ? "sp_" + mc.getSingleplayerServer().getWorldData().getLevelName() : "unknown");
      String dimension = mc.level != null ? mc.level.dimension().identifier().toString() : "no_dimension";
      return sanitize((String)base) + "__" + sanitize(dimension);
   }

   private static String sanitize(String s) {
      return s.replaceAll("[^a-zA-Z0-9_.-]", "_");
   }

   public static long chunkKey(int chunkX, int chunkZ) {
      return chunkX & 4294967295L | (chunkZ & 4294967295L) << 32;
   }

   public void loadForWorld() {
      this.flush();
      this.evaluated.clear();
      this.stashes.clear();
      File dir = new File(FabricLoader.getInstance().getGameDir().toFile(), "night/stashfinder");
      if (!dir.exists()) {
         dir.mkdirs();
      }

      this.file = new File(dir, currentWorldKey() + ".json");
      if (this.file.exists()) {
         try (FileReader reader = new FileReader(this.file)) {
            Gson gson = new Gson();
            Type type = (new TypeToken<StashFinderStore.PersistentData>() {
               {
                  Objects.requireNonNull(StashFinderStore.this);
               }
            }).getType();
            StashFinderStore.PersistentData data = (StashFinderStore.PersistentData)gson.fromJson(reader, type);
            if (data != null) {
               if (data.evaluated != null) {
                  this.evaluated.addAll(data.evaluated);
               }

               if (data.stashes != null) {
                  this.stashes.addAll(data.stashes);
               }
            }
         } catch (Exception var8) {
         }
      }
   }

   private void save() {
      if (this.file != null) {
         try (FileWriter writer = new FileWriter(this.file)) {
            StashFinderStore.PersistentData data = new StashFinderStore.PersistentData();
            data.evaluated = this.evaluated;
            data.stashes = this.stashes;
            new GsonBuilder().create().toJson(data, writer);
         } catch (Exception var6) {
         }
      }
   }

   public boolean isEvaluated(long chunkKey) {
      return this.evaluated.contains(chunkKey);
   }

   public void markEvaluated(long chunkKey) {
      if (this.evaluated.add(chunkKey)) {
         this.dirty = true;
      }
   }

   public void recordStash(int x, int z, String dimension, Map<String, Integer> counts) {
      this.stashes.add(new StashFinderStore.StashData(x, z, dimension, counts, System.currentTimeMillis()));
      this.dirty = true;
   }

   public List<StashFinderStore.StashData> getStashes() {
      return Collections.unmodifiableList(this.stashes);
   }

   public void flushIfStale() {
      if (this.dirty && System.currentTimeMillis() - this.lastSaveMs >= 10000L) {
         this.flush();
      }
   }

   public void flush() {
      if (this.dirty) {
         this.save();
         this.dirty = false;
         this.lastSaveMs = System.currentTimeMillis();
      }
   }

   public void clearAll() {
      this.evaluated.clear();
      this.stashes.clear();
      this.dirty = true;
      this.flush();
   }

   private static class PersistentData {
      Set<Long> evaluated = new HashSet<>();
      List<StashFinderStore.StashData> stashes = new ArrayList<>();
   }

   public record StashData(int x, int z, String dimension, Map<String, Integer> counts, long timestamp) {
   }
}
