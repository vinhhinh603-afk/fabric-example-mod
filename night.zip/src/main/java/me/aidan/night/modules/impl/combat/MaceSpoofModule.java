package night.modules.impl.combat;

import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Items;
import night.events.SubscribeEvent;
import night.events.impl.AttackEntityEvent;
import night.events.impl.PacketSendEvent;
import night.mixins.accessors.PlayerMoveC2SPacketAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.InventoryUtils;

@RegisterModule(
   name = "MaceSpoof",
   description = "Spoof fall height for mace damage.",
   category = Module.Category.COMBAT
)
public class MaceSpoofModule extends Module {
   public ModeSetting mode = new ModeSetting("Mode", "Mode of spoofing.", "Vanilla", new String[]{"Vanilla", "NCP", "Swap"});
   public BooleanSetting noCrystal = new BooleanSetting("NoCrystal", "Don't apply on crystal attack.", new ModeSetting.Visibility(this.mode, "Swap"), true);
   public BooleanSetting inventorySwap = new BooleanSetting(
      "InventorySwap", "Use inventory swap (vs hotbar swap).", new ModeSetting.Visibility(this.mode, "Swap"), false
   );
   public BooleanSetting onlyGround = new BooleanSetting(
      "OnlyGround", "Only spoof when on ground or flying.", new ModeSetting.Visibility(this.mode, "Vanilla"), true
   );
   public NumberSetting height = new NumberSetting("Height", "Fake fall height.", new ModeSetting.Visibility(this.mode, "Vanilla"), 25.0, 1.0, 2000.0);
   private boolean attacking = false;

   @SubscribeEvent
   public void onAttackEntity(AttackEntityEvent event) {
      if (!this.attacking) {
         if (mc.player != null && mc.level != null && mc.getConnection() != null) {
            if (this.mode.getValue().equalsIgnoreCase("Vanilla")) {
               if (!mc.player.getMainHandItem().is(Items.MACE)) {
                  return;
               }

               Entity target = event.getTarget();
               if (target == null || target instanceof EndCrystal) {
                  return;
               }

               if (this.onlyGround.getValue() && !mc.player.onGround() && !mc.player.getAbilities().flying) {
                  return;
               }

               if (mc.player.isInLava() || mc.player.isUnderWater() || mc.player.isInWater()) {
                  return;
               }

               for (int i = 0; i < 4; i++) {
                  this.sendFakeY(0.0);
               }

               this.sendFakeY(this.height.getValue().doubleValue());
               this.sendFakeY(0.0);
            } else if (this.mode.getValue().equalsIgnoreCase("Swap")) {
               Entity targetx = event.getTarget();
               if (this.noCrystal.getValue() && targetx instanceof EndCrystal) {
                  return;
               }

               int maceSlot = this.getMaceSlot();
               if (maceSlot == -1) {
                  return;
               }

               try {
                  this.attacking = true;
                  this.doSpoof(targetx, maceSlot);
               } finally {
                  this.attacking = false;
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      if (mc.player != null && mc.level != null) {
         Packet<?> packet;
         if (this.mode.getValue().equalsIgnoreCase("NCP") && (packet = event.getPacket()) instanceof ServerboundMovePlayerPacket) {
            ServerboundMovePlayerPacket movePacket = (ServerboundMovePlayerPacket)packet;
            ((PlayerMoveC2SPacketAccessor)movePacket).setOnGround(false);
         }
      }
   }

   private void doSpoof(Entity target, int maceSlot) {
      int oldSlot = mc.player.getInventory().getSelectedSlot();
      if (this.inventorySwap.getValue()) {
         InventoryUtils.click(maceSlot, oldSlot, ContainerInput.SWAP);
         mc.gameMode.attack(mc.player, target);
         mc.player.resetAttackStrengthTicker();
         InventoryUtils.click(maceSlot, oldSlot, ContainerInput.SWAP);
      } else {
         InventoryUtils.switchSlot("Silent", maceSlot, oldSlot);
         mc.gameMode.attack(mc.player, target);
         mc.player.resetAttackStrengthTicker();
         InventoryUtils.switchBack("Silent", maceSlot, oldSlot);
      }
   }

   private int getMaceSlot() {
      if (mc.player == null) {
         return -1;
      } else {
         if (this.inventorySwap.getValue()) {
            for (int i = 9; i <= 35; i++) {
               if (mc.player.getInventory().getItem(i).is(Items.MACE)) {
                  return i;
               }
            }
         } else {
            for (int ix = 0; ix < 9; ix++) {
               if (mc.player.getInventory().getItem(ix).is(Items.MACE)) {
                  return ix;
               }
            }
         }

         return -1;
      }
   }

   private void sendFakeY(double offset) {
      mc.getConnection().send(new Pos(mc.player.getX(), mc.player.getY() + offset, mc.player.getZ(), false, mc.player.horizontalCollision));
   }

   @Override
   public String getMetaData() {
      return this.mode.getValue();
   }
}
