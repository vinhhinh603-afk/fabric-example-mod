package night.modules.impl.movement;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerInputPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.UpdateMovementEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.utils.minecraft.NetworkUtils;

@RegisterModule(
   name = "NoSlow",
   description = "Removes the slowness effect that you receive when doing certain actions.",
   category = Module.Category.MOVEMENT
)
public class NoSlowModule extends Module {
   public BooleanSetting items = new BooleanSetting("Items", "Removes the slowness effect from eating or using items.", true);
   public ModeSetting itemMode = new ModeSetting("Mode", "Item slowdown bypass mode.", "Normal", new String[]{"Normal", "Strict", "GrimV2", "GrimV3"});
   public BooleanSetting crawl = new BooleanSetting("Crawl", "Removes the slowness effect from crawling.", false);
   public BooleanSetting sneak = new BooleanSetting("Sneak", "Removes the slowness effect from sneaking.", false);
   public BooleanSetting soulSand = new BooleanSetting("SoulSand", "Removes the slowness effect from walking on soul sand.", false);
   public BooleanSetting slimeBlocks = new BooleanSetting("SlimeBlocks", "Removes the slowness effect from walking on slime blocks.", false);
   public BooleanSetting honeyBlocks = new BooleanSetting("HoneyBlocks", "Removes the slowness effect from walking on honey blocks.", false);

   @SubscribeEvent
   public void onUpdateMovementPost(UpdateMovementEvent.Post event) {
      if (mc.player != null && mc.level != null) {
         if (this.items.getValue() && mc.player.isUsingItem() && !mc.player.isPassenger() && !mc.player.isFallFlying()) {
            float yaw = Night.ROTATION_MANAGER.getRotation() != null ? Night.ROTATION_MANAGER.getRotation().getYaw() : mc.player.getYRot();
            float pitch = Night.ROTATION_MANAGER.getRotation() != null ? Night.ROTATION_MANAGER.getRotation().getPitch() : mc.player.getXRot();
            if (this.itemMode.getValue().equals("GrimV2")) {
               if (!mc.player.isShiftKeyDown() && (mc.player.getUseItem().has(DataComponents.FOOD) || this.canUseItem(mc.player.getUseItem()))) {
                  InteractionHand distraction = mc.player.getUsedItemHand() == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
                  NetworkUtils.sendSequencedPacket(id -> new ServerboundUseItemPacket(distraction, id, yaw, pitch));
               }
            } else if (this.itemMode.getValue().equals("Strict") && !NetworkUtils.isLegacyProtocol()) {
               if (mc.player.getUsedItemHand() == InteractionHand.OFF_HAND) {
                  int slot = mc.player.getInventory().getSelectedSlot();
                  mc.getConnection().send(new ServerboundSetCarriedItemPacket((slot + 1) % 9));
                  mc.getConnection().send(new ServerboundSetCarriedItemPacket(slot));
               } else {
                  NetworkUtils.sendSequencedPacket(id -> new ServerboundUseItemPacket(InteractionHand.OFF_HAND, id, yaw, pitch));
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.itemMode.getValue().equals("Strict")) {
            if (event.getPacket() instanceof PosRot
               || event.getPacket() instanceof Pos
               || event.getPacket() instanceof Rot
               || event.getPacket() instanceof StatusOnly) {
               mc.player.connection.send(new ServerboundSetCarriedItemPacket(mc.player.getInventory().getSelectedSlot()));
            }

            if (event.getPacket() instanceof ServerboundContainerClickPacket) {
               if (mc.player.isUsingItem()) {
                  mc.player.stopUsingItem();
               }

               if (mc.player.isSprinting()) {
                  mc.player.connection.send(new ServerboundPlayerCommandPacket(mc.player, Action.STOP_SPRINTING));
               }

               if (mc.player.isShiftKeyDown()) {
                  mc.player.connection.send(new ServerboundPlayerInputPacket(new Input(false, false, false, false, false, false, false)));
               }
            }
         }
      }
   }

   @Override
   public void onDisable() {
      Night.WORLD_MANAGER.setTimerMultiplier(1.0F);
   }

   public boolean canUseItem(ItemStack stack) {
      return stack != null && !stack.isEmpty()
         ? stack.has(DataComponents.CONSUMABLE)
            || stack.has(DataComponents.FOOD)
            || stack.is(Items.BOW)
            || stack.is(Items.CROSSBOW)
            || stack.is(Items.SHIELD)
            || stack.is(Items.TRIDENT)
            || stack.is(Items.SPYGLASS)
            || stack.is(Items.GOAT_HORN)
         : false;
   }

   public boolean canBypassGrimUseTime() {
      return mc.player == null ? false : mc.player.getTicksUsingItem() > 1 && mc.player.getTicksUsingItem() % 2 != 0;
   }

   public boolean shouldSlow() {
      if (mc.player != null && this.items.getValue()) {
         return this.itemMode.getValue().equals("GrimV3") ? !this.canBypassGrimUseTime() : false;
      } else {
         return true;
      }
   }
}
