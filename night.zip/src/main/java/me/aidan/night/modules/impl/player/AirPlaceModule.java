package night.modules.impl.player;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.visuals.BlockHighlightModule;
import night.settings.impl.BooleanSetting;
import night.utils.graphics.Renderer3D;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.WorldUtils;

@RegisterModule(
   name = "AirPlace",
   description = "Lets you place blocks in the air in servers that allow it.",
   category = Module.Category.PLAYER
)
public class AirPlaceModule extends Module {
   public BooleanSetting grim = new BooleanSetting(
      "Grim",
      "Swaps the block into your offhand for just the instant of each placement -- GrimAC's whole scaffolding check group (AirLiquidPlace, RotationPlace, PositionPlace...) only runs for MAIN_HAND placements, verified against its own decompiled source.",
      false
   );
   private HitResult hitResult;

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (!this.getNull()) {
         this.hitResult = mc.getCameraEntity().pick(mc.player.blockInteractionRange(), 0.0F, false);
         if (this.hitResult instanceof BlockHitResult blockHitResult && mc.player.getMainHandItem().getItem() instanceof BlockItem) {
            if (mc.options.keyUse.isDown() && mc.level.getBlockState(blockHitResult.getBlockPos()).isAir()) {
               if (this.grim.getValue()) {
                  int selected = mc.player.getInventory().getSelectedSlot();
                  InventoryUtils.swapEquipment(selected, 45);
                  WorldUtils.airPlaceBlock(blockHitResult.getBlockPos(), InteractionHand.OFF_HAND, "None", true);
                  InventoryUtils.swapEquipment(selected, 45);
               } else {
                  WorldUtils.airPlaceBlock(blockHitResult.getBlockPos(), InteractionHand.MAIN_HAND, "None", true);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (!this.getNull()) {
         BlockHighlightModule blockHighlightModule = Night.MODULE_MANAGER.getModule(BlockHighlightModule.class);
         if (this.hitResult instanceof BlockHitResult blockHitResult && mc.player.getMainHandItem().getItem() instanceof BlockItem) {
            if (mc.level.getBlockState(blockHitResult.getBlockPos()).isAir()) {
               AABB box = new AABB(blockHitResult.getBlockPos());
               Renderer3D.renderBox(event.getMatrices(), box, blockHighlightModule.fillColor.getColor());
               Renderer3D.renderBoxOutline(event.getMatrices(), box, blockHighlightModule.outlineColor.getColor());
            }
         }
      }
   }
}
