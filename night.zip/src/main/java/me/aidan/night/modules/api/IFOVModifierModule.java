package night.modules.api;

public interface IFOVModifierModule {
   boolean isToggled();

   float getFovValue();
}
