package night.modules.impl.combat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import night.utils.IMinecraft;

public class CrystalPlacementHelper implements IMinecraft {
   public static CrystalPlacementHelper.PlacementResult getVisiblePlacement(BlockPos position) {
      if (mc.player != null && mc.level != null) {
         Vec3 eye = mc.player.getEyePosition();
         Direction[] faces = new Direction[]{Direction.UP, Direction.SOUTH, Direction.NORTH, Direction.EAST, Direction.WEST, Direction.DOWN};
         CrystalPlacementHelper.PlacementResult bestResult = null;
         double bestDistSq = Double.MAX_VALUE;
         double[][] directions = new double[][]{{0.0, 0.5}, {1.0, 0.5}, {0.5, 0.0}, {0.5, 1.0}, {0.0, 0.0}, {1.0, 0.0}, {0.0, 1.0}, {1.0, 1.0}};
         int maxIter = 10;

         for (Direction face : faces) {
            BlockPos adjacent = position.relative(face);
            if (face == Direction.UP || mc.level.getBlockState(adjacent).canBeReplaced() || !mc.level.getBlockState(adjacent).isSolidRender()) {
               CrystalPlacementHelper.PlacementResult centerHit = testFacePoint(position, face, eye, 0.5, 0.5);
               if (centerHit != null) {
                  double distSq = eye.distanceToSqr(centerHit.hitVec);
                  if (distSq < bestDistSq) {
                     bestDistSq = distSq;
                     bestResult = centerHit;
                  }
               } else {
                  for (double[] dir : directions) {
                     for (int iter = 1; iter <= maxIter; iter++) {
                        double t = 1.0 - 1.0 / (1 << iter);
                        double ox = 0.5 + (dir[0] - 0.5) * t;
                        double oy = 0.5 + (dir[1] - 0.5) * t;
                        CrystalPlacementHelper.PlacementResult hit = testFacePoint(position, face, eye, ox, oy);
                        if (hit != null) {
                           double distSq = eye.distanceToSqr(hit.hitVec);
                           if (distSq < bestDistSq) {
                              bestDistSq = distSq;
                              bestResult = hit;
                           }
                           break;
                        }
                     }
                  }
               }
            }
         }

         if (bestResult != null) {
            return bestResult;
         } else {
            Direction closestExposed = null;
            double minDistance = Double.MAX_VALUE;

            for (Direction facex : faces) {
               BlockPos adjacent = position.relative(facex);
               BlockState state = mc.level.getBlockState(adjacent);
               double dist;
               if (state.canBeReplaced() && (dist = eye.distanceToSqr(getSurfacePoint(position, facex, 0.5, 0.5))) < minDistance) {
                  minDistance = dist;
                  closestExposed = facex;
               }
            }

            return closestExposed != null
               ? new CrystalPlacementHelper.PlacementResult(closestExposed, getSurfacePoint(position, closestExposed, 0.5, 0.5), false)
               : new CrystalPlacementHelper.PlacementResult(Direction.UP, Vec3.atCenterOf(position).add(0.0, 0.5, 0.0), false);
         }
      } else {
         return new CrystalPlacementHelper.PlacementResult(Direction.UP, Vec3.atCenterOf(position).add(0.0, 0.5, 0.0), false);
      }
   }

   private static CrystalPlacementHelper.PlacementResult testFacePoint(BlockPos position, Direction face, Vec3 eye, double ox, double oy) {
      Vec3 point = getPointOnFace(position, face, ox, oy);
      BlockHitResult result = mc.level.clip(new ClipContext(eye, point, Block.COLLIDER, Fluid.NONE, mc.player));
      if (result == null) {
         return null;
      } else if (result.getType() == Type.MISS) {
         return new CrystalPlacementHelper.PlacementResult(face, getSurfacePoint(position, face, ox, oy), true);
      } else {
         return result.getType() == Type.BLOCK && result.getBlockPos().equals(position)
            ? new CrystalPlacementHelper.PlacementResult(result.getDirection(), result.getLocation(), true)
            : null;
      }
   }

   public static boolean isPlacementVisible(BlockPos position) {
      if (mc.player != null && mc.level != null) {
         CrystalPlacementHelper.PlacementResult result = getVisiblePlacement(position);
         return result != null && result.visible;
      } else {
         return false;
      }
   }

   public static Vec3 getPointOnFace(BlockPos pos, Direction face, double off1, double off2) {
      double x = pos.getX();
      double y = pos.getY();
      double z = pos.getZ();
      switch (face) {
         case UP:
            return new Vec3(x + off1, y + 0.999, z + off2);
         case DOWN:
            return new Vec3(x + off1, y + 0.001, z + off2);
         case SOUTH:
            return new Vec3(x + off1, y + off2, z + 0.999);
         case NORTH:
            return new Vec3(x + off1, y + off2, z + 0.001);
         case EAST:
            return new Vec3(x + 0.999, y + off1, z + off2);
         case WEST:
            return new Vec3(x + 0.001, y + off1, z + off2);
         default:
            return new Vec3(x + 0.5, y + 0.5, z + 0.5);
      }
   }

   public static Vec3 getSurfacePoint(BlockPos pos, Direction face, double off1, double off2) {
      double x = pos.getX();
      double y = pos.getY();
      double z = pos.getZ();
      switch (face) {
         case UP:
            return new Vec3(x + off1, y + 1.0, z + off2);
         case DOWN:
            return new Vec3(x + off1, y + 0.0, z + off2);
         case SOUTH:
            return new Vec3(x + off1, y + off2, z + 1.0);
         case NORTH:
            return new Vec3(x + off1, y + off2, z + 0.0);
         case EAST:
            return new Vec3(x + 1.0, y + off1, z + off2);
         case WEST:
            return new Vec3(x + 0.0, y + off1, z + off2);
         default:
            return new Vec3(x + 0.5, y + 0.5, z + 0.5);
      }
   }

   public static class PlacementResult {
      public Direction direction;
      public Vec3 hitVec;
      public boolean visible;

      public PlacementResult(Direction direction, Vec3 hitVec) {
         this(direction, hitVec, true);
      }

      public PlacementResult(Direction direction, Vec3 hitVec, boolean visible) {
         this.direction = direction;
         this.hitVec = hitVec;
         this.visible = visible;
      }
   }
}
