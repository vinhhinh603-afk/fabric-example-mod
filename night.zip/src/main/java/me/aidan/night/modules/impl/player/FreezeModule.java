package night.modules.impl.player;

import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import night.events.SubscribeEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.PlayerMoveEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;

@RegisterModule(
   name = "Freeze",
   description = "Freezes your player in place and stops sending position packets to the server.",
   category = Module.Category.VISUALS
)
public class FreezeModule extends Module {
   public BooleanSetting movement = new BooleanSetting("Movement", "Stops your player from moving.", true);
   public BooleanSetting packets = new BooleanSetting("Packets", "Stops position packets from being sent to the server.", true);
   public BooleanSetting keepLook = new BooleanSetting(
      "KeepLook", "Still tells the server where you are looking, so thrown pearls and other items go where you aim.", true
   );

   @SubscribeEvent
   public void onMove(PlayerMoveEvent var1) {
      if (this.movement.getValue()) {
         var1.setX(0.0);
         var1.setY(0.0);
         var1.setZ(0.0);
         var1.cancel();
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent var1) {
      if (this.packets.getValue()) {
         if (var1.getPacket() instanceof ServerboundMovePlayerPacket) {
            ServerboundMovePlayerPacket var2 = (ServerboundMovePlayerPacket)var1.getPacket();
            if (!(var2 instanceof Rot)) {
               var1.cancel();
               if (this.keepLook.getValue() && var2.hasRotation() && mc.getConnection() != null) {
                  mc.getConnection().send(new Rot(var2.getYRot(0.0F), var2.getXRot(0.0F), var2.isOnGround(), var2.horizontalCollision()));
               }
            }
         }
      }
   }
}
