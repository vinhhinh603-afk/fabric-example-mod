package night.modules.impl.movement;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerMoveEvent;
import night.events.impl.TickEvent;
import night.managers.BoostManager;
import night.mixins.accessors.Vec3dAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.api.ISpeedModule;
import night.modules.api.ISprintModule;
import night.modules.impl.miscellaneous.FakePlayerModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.MovementUtils;
import org.joml.Vector2d;

@RegisterModule(
   name = "Speed",
   description = "Makes it so that you move faster than normal.",
   category = Module.Category.MOVEMENT
)
public class SpeedModule extends Module implements ISpeedModule {
   public ModeSetting mode = new ModeSetting(
      "Mode", "The method that will be used to increase your speed.", "Strafe", new String[]{"Vanilla", "Strafe", "StrafeStrict", "Grim"}
   );
   public NumberSetting vanillaSpeed = new NumberSetting(
      "VanillaSpeed", "Speed", "The speed that will be applied to your movement.", new ModeSetting.Visibility(this.mode, "Vanilla"), 10.0, 0.0, 20.0
   );
   public BooleanSetting vanillaOnGround = new BooleanSetting(
      "VanillaOnGround", "OnGround", "Only applies the speed when you are on ground.", new ModeSetting.Visibility(this.mode, "Vanilla"), false
   );
   public BooleanSetting useTimer = new BooleanSetting(
      "UseTimer", "Adds a timer multiplier when strafing.", new ModeSetting.Visibility(this.mode, "Strafe", "StrafeStrict"), false
   );
   public BooleanSetting timerBypass = new BooleanSetting(
      "Bypass", "Allows you to use timer on certain servers.", new BooleanSetting.Visibility(this.useTimer, true), true
   );
   public NumberSetting bypassThreshold = new NumberSetting(
      "Threshold", "The threshold value for the timer bypass.", new BooleanSetting.Visibility(this.timerBypass, true), 25, 15, 30
   );
   public NumberSetting timerMultiplier = new NumberSetting(
      "TimerMultiplier",
      "Multiplier",
      "The timer multiplier that will be applied to the timer.",
      new BooleanSetting.Visibility(this.useTimer, true),
      1.08F,
      1.0F,
      1.2F
   );
   public BooleanSetting speedInLiquid = new BooleanSetting(
      "SpeedInLiquid", "Increases your speed while in water or lava.", new ModeSetting.Visibility(this.mode, "Strafe", "StrafeStrict"), false
   );
   public BooleanSetting boost = new BooleanSetting(
      "Boost", "Uses explosion knockback to boost your speed.", new ModeSetting.Visibility(this.mode, "Strafe", "StrafeStrict"), false
   );
   public NumberSetting boostMultiplier = new NumberSetting(
      "BoostMultiplier", "Multiplier", "Scales the explosion knockback boost.", new BooleanSetting.Visibility(this.boost, true), 1.0, 0.01, 5.0
   );
   public NumberSetting boostCap = new NumberSetting(
      "BoostCap", "Cap", "Maximum boost value that can be applied.", new BooleanSetting.Visibility(this.boost, true), 5.0, 0.0, 10.0
   );
   public BooleanSetting autoJump = new BooleanSetting(
      "AutoJump", "Automatically jumps for you when on ground.", new ModeSetting.Visibility(this.mode, "Grim"), false
   );
   private double distance;
   private double speed;
   private double forward;
   private int stage;
   private int ticks;
   private boolean pressed = false;

   @Override
   public void onEnable() {
      this.stage = 1;
      this.ticks = 0;
      this.pressed = false;
   }

   @Override
   public void onDisable() {
      Night.WORLD_MANAGER.setTimerMultiplier(1.0F);
      if (this.pressed) {
         mc.options.keyJump.setDown(false);
         this.pressed = false;
      }
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.mode.getValue().equalsIgnoreCase("Strafe") || this.mode.getValue().equalsIgnoreCase("StrafeStrict")) {
            this.distance = Math.sqrt(Mth.square(mc.player.getX() - mc.player.xo) + Mth.square(mc.player.getZ() - mc.player.zo));
            Night.WORLD_MANAGER.setTimerMultiplier(this.isDrivingTimer() ? this.timerMultiplier.getValue().floatValue() : 1.0F);
         }

         if (this.mode.getValue().equalsIgnoreCase("Grim")) {
            boolean isCrawling = mc.player.isVisuallyCrawling()
               || mc.player.getPose() == Pose.SWIMMING
               || mc.player.getEyeHeight() < 1.0F
               || this.hasCeiling(mc.player.getX(), mc.player.getY(), mc.player.getZ());
            boolean canJump = true;
            if (isCrawling) {
               boolean currentCeiling = this.hasCeiling(mc.player.getX(), mc.player.getY(), mc.player.getZ());
               boolean aheadCeiling = this.hasCeilingAhead();
               if (!currentCeiling || !aheadCeiling) {
                  canJump = false;
               }
            }

            if ((!canJump || !this.autoJump.getValue() || !MovementUtils.isMoving()) && this.pressed) {
               mc.options.keyJump.setDown(false);
               this.pressed = false;
            }

            if (this.autoJump.getValue() && MovementUtils.isMoving() && mc.player.onGround() && canJump) {
               mc.options.keyJump.setDown(true);
               this.pressed = true;
               ISprintModule sprint = (ISprintModule)Night.MODULE_MANAGER.getModule("Sprint");
               boolean grimAlreadyCorrect = sprint != null && sprint.isGrimCompensating();
               if (mc.player.isSprinting() && !grimAlreadyCorrect) {
                  float yRotRad = mc.player.getYRot() * (float) (Math.PI / 180.0);
                  double vanillaX = -Math.sin(yRotRad) * 0.2;
                  double vanillaZ = Math.cos(yRotRad) * 0.2;
                  Vector2d boost = MovementUtils.forward(0.2);
                  mc.player
                     .setDeltaMovement(
                        mc.player.getDeltaMovement().x - vanillaX + boost.x,
                        mc.player.getDeltaMovement().y,
                        mc.player.getDeltaMovement().z - vanillaZ + boost.y
                     );
               }
            } else if (this.pressed) {
               mc.options.keyJump.setDown(false);
               this.pressed = false;
            }

            int collisions = 0;

            for (Entity entity : mc.level.entitiesForRendering()) {
               if (entity != null
                  && entity != mc.player
                  && entity instanceof LivingEntity
                  && !EntityUtils.isGhost(entity)
                  && (
                     !Night.MODULE_MANAGER.getModule(FakePlayerModule.class).isToggled()
                        || Night.MODULE_MANAGER.getModule(FakePlayerModule.class).getPlayer() != entity
                  )
                  && !(entity instanceof ArmorStand)
                  && Mth.sqrt((float)mc.player.distanceToSqr(entity)) <= 1.5) {
                  collisions++;
               }
            }

            if (collisions > 0) {
               Vector2d vector2d = MovementUtils.forward(0.08 * collisions);
               mc.player
                  .setDeltaMovement(mc.player.getDeltaMovement().x + vector2d.x, mc.player.getDeltaMovement().y, mc.player.getDeltaMovement().z + vector2d.y);
            }
         }
      }
   }

   @SubscribeEvent
   public void onPlayerMove(PlayerMoveEvent event) {
      if (this.mode.getValue().equalsIgnoreCase("Strafe") || this.mode.getValue().equalsIgnoreCase("StrafeStrict")) {
         if (Night.MODULE_MANAGER.getModule(HoleSnapModule.class).isToggled() && Night.MODULE_MANAGER.getModule(HoleSnapModule.class).hole != null) {
            return;
         }

         ElytraFlyModule elytra = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
         if (elytra.isToggled() && elytra.mode.getValue().equalsIgnoreCase("Control") && mc.player.isFallFlying()) {
            return;
         }

         if (mc.player.fallDistance >= 5.0
            || mc.player.isShiftKeyDown()
            || mc.player.onClimbable()
            || mc.level.getBlockState(mc.player.blockPosition()).getBlock() == Blocks.COBWEB
            || mc.player.getAbilities().flying
            || (mc.player.isInWater() || mc.player.isInLava()) && !this.speedInLiquid.getValue()) {
            return;
         }

         this.speed = MovementUtils.getPotionSpeed(MovementUtils.DEFAULT_SPEED)
            * (mc.player.input.getMoveVector().y <= 0.0F && this.forward > 0.0 ? 0.66 : 1.0);
         if (this.stage == 1 && MovementUtils.isMoving() && mc.player.verticalCollision) {
            ((Vec3dAccessor)mc.player.getDeltaMovement()).setY(MovementUtils.getPotionJump(0.39999995F));
            event.setMovement(new Vec3(event.getMovement().x, mc.player.getDeltaMovement().y, event.getMovement().z));
            this.speed *= 2.149;
            if (this.boost.getValue()) {
               this.speed = this.speed + this.getAppliedBoost();
            }

            this.stage = 2;
         } else if (this.stage == 2) {
            this.speed = this.distance - 0.66 * (this.distance - MovementUtils.getPotionSpeed(MovementUtils.DEFAULT_SPEED));
            if (this.boost.getValue()) {
               this.speed = this.speed + this.getAppliedBoost();
            }

            this.stage = 3;
         } else {
            if (!mc.level.getEntityCollisions(mc.player, mc.player.getBoundingBox().move(0.0, mc.player.getDeltaMovement().y, 0.0)).isEmpty()
               || mc.player.verticalCollision) {
               this.stage = 1;
            }

            this.speed = this.distance - this.distance / 159.0;
         }

         this.speed = Math.max(this.speed, MovementUtils.getPotionSpeed(MovementUtils.DEFAULT_SPEED));
         boolean pureForward = mc.player.input.keyPresses.forward()
            && !mc.player.input.keyPresses.backward()
            && !mc.player.input.keyPresses.left()
            && !mc.player.input.keyPresses.right();
         double ncp = MovementUtils.getPotionSpeed(!this.mode.getValue().equalsIgnoreCase("StrafeStrict") && pureForward ? 0.576 : 0.465);
         double bypass = MovementUtils.getPotionSpeed(!this.mode.getValue().equalsIgnoreCase("StrafeStrict") && pureForward ? 0.57 : 0.44);
         this.speed = Math.min(this.speed, this.ticks > 25 ? ncp : bypass);
         if (this.ticks++ > 50) {
            this.ticks = 0;
         }

         Vector2d velocity = MovementUtils.forward(this.speed);
         event.setMovement(new Vec3(velocity.x, event.getMovement().y, event.getMovement().z));
         event.setMovement(new Vec3(event.getMovement().x, event.getMovement().y, velocity.y));
         this.forward = mc.player.input.getMoveVector().y;
         event.setCancelled(true);
      }
   }

   private double getAppliedBoost() {
      if (BoostManager.INSTANCE == null) {
         return 0.0;
      } else {
         double raw = BoostManager.INSTANCE.getBoostSpeed(false);
         if (raw == 0.0) {
            return 0.0;
         } else {
            double scaled = raw * this.boostMultiplier.getValue().doubleValue();
            return Math.min(scaled, this.boostCap.getValue().doubleValue());
         }
      }
   }

   @Override
   public String getMetaData() {
      return this.mode.getValue();
   }

   @Override
   public String getModeValue() {
      return this.mode.getValue();
   }

   @Override
   public float getVanillaSpeedValue() {
      return this.vanillaSpeed.getValue().floatValue();
   }

   public boolean isDrivingTimer() {
      if (mc.player == null) {
         return false;
      } else if (!this.mode.getValue().equalsIgnoreCase("Strafe") && !this.mode.getValue().equalsIgnoreCase("StrafeStrict")) {
         return false;
      } else if (!this.useTimer.getValue()) {
         return false;
      } else {
         boolean flag = MovementUtils.isMoving() && !mc.player.isShiftKeyDown() && !mc.player.isInWater() && mc.player.fallDistance < 5.0;
         return flag && (this.ticks > this.bypassThreshold.getValue().intValue() || !this.timerBypass.getValue());
      }
   }

   private boolean hasCeiling(double x, double y, double z) {
      if (mc.level == null) {
         return false;
      } else {
         BlockPos headBlock1 = BlockPos.containing(x, y + 1.0, z);
         BlockState state1 = mc.level.getBlockState(headBlock1);
         if (state1.isAir() || !state1.isSolid() && !state1.blocksMotion() && state1.canBeReplaced()) {
            BlockPos headBlock2 = BlockPos.containing(x, y + 1.2, z);
            if (headBlock2.equals(headBlock1)) {
               return false;
            } else {
               BlockState state2 = mc.level.getBlockState(headBlock2);
               return !state2.isAir() && (state2.isSolid() || state2.blocksMotion() || !state2.canBeReplaced());
            }
         } else {
            return true;
         }
      }
   }

   private boolean hasCeilingAhead() {
      if (mc.player != null && mc.level != null) {
         double vx = mc.player.getDeltaMovement().x;
         double vz = mc.player.getDeltaMovement().z;
         double speed = Math.hypot(vx, vz);
         if (speed > 0.01) {
            double step = Math.min(speed, 0.35);
            double checkX = mc.player.getX() + vx / speed * step;
            double checkZ = mc.player.getZ() + vz / speed * step;
            if (!this.hasCeiling(checkX, mc.player.getY(), checkZ)) {
               return false;
            }
         }

         if (MovementUtils.isMoving()) {
            Vector2d fwd = MovementUtils.forward(0.3);
            double checkX = mc.player.getX() + fwd.x;
            double checkZ = mc.player.getZ() + fwd.y;
            if (!this.hasCeiling(checkX, mc.player.getY(), checkZ)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }
}
