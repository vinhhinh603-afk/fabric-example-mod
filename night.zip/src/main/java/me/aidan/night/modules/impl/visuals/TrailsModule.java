package night.modules.impl.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.entity.projectile.hurtingprojectile.DragonFireball;
import net.minecraft.world.entity.projectile.hurtingprojectile.Fireball;
import net.minecraft.world.entity.projectile.hurtingprojectile.LargeFireball;
import net.minecraft.world.entity.projectile.hurtingprojectile.SmallFireball;
import net.minecraft.world.entity.projectile.hurtingprojectile.WitherSkull;
import net.minecraft.world.entity.projectile.throwableitemprojectile.Snowball;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEgg;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl;
import net.minecraft.world.phys.Vec3;
import night.events.SubscribeEvent;
import night.events.impl.ClientConnectEvent;
import night.events.impl.ClientDisconnectEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.ServerConnectEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.CategorySetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.NumberSetting;
import night.utils.color.ColorUtils;
import night.utils.graphics.Renderer3D;
import night.utils.minecraft.EntityUtils;

@RegisterModule(
   name = "Trails",
   description = "Renders smooth trails behind projectiles and throwables.",
   category = Module.Category.VISUALS
)
public class TrailsModule extends Module {
   public CategorySetting targets = new CategorySetting("Targets", "The projectiles to render trails for.");
   public BooleanSetting pearls = new BooleanSetting("Pearls", "Renders trails behind ender pearls.", new CategorySetting.Visibility(this.targets), true);
   public BooleanSetting arrows = new BooleanSetting("Arrows", "Renders trails behind arrows.", new CategorySetting.Visibility(this.targets), true);
   public BooleanSetting witherSkull = new BooleanSetting(
      "WitherSkull", "Renders trails behind wither skulls.", new CategorySetting.Visibility(this.targets), true
   );
   public BooleanSetting egg = new BooleanSetting("Egg", "Renders trails behind eggs.", new CategorySetting.Visibility(this.targets), true);
   public BooleanSetting snowball = new BooleanSetting("Snowball", "Renders trails behind snowballs.", new CategorySetting.Visibility(this.targets), true);
   public BooleanSetting fireCharge = new BooleanSetting(
      "FireCharge", "Renders trails behind fire charges.", new CategorySetting.Visibility(this.targets), true
   );
   public NumberSetting fade = new NumberSetting("Fade", "The duration in milliseconds before a trail segment fades away.", 1000, 100, 5000);
   public ColorSetting color = new ColorSetting("Color", "The color used for the trails.", ColorUtils.getDefaultOutlineColor());
   private final Map<UUID, List<TrailsModule.TrailPoint>> trails = new ConcurrentHashMap<>();

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.level != null && mc.player != null) {
         long now = System.currentTimeMillis();

         for (Entity entity : mc.level.entitiesForRendering()) {
            if (this.isValidTarget(entity) && entity.isAlive()) {
               UUID uuid = entity.getUUID();
               Vec3 pos = entity.position().add(0.0, entity.getBbHeight() * 0.5, 0.0);
               List points;
               List list = points = this.trails.computeIfAbsent(uuid, k -> new ArrayList<>());
               synchronized (list) {
                  if (points.isEmpty()) {
                     Projectile proj;
                     Entity entity2;
                     if (entity instanceof Projectile && (entity2 = (proj = (Projectile)entity).getOwner()) instanceof LivingEntity) {
                        LivingEntity living = (LivingEntity)entity2;
                        points.add(new TrailsModule.TrailPoint(living.getEyePosition().subtract(0.0, 0.1, 0.0), now));
                     } else if (entity.distanceTo(mc.player) <= 3.5 && mc.player.isAlive()) {
                        points.add(new TrailsModule.TrailPoint(mc.player.getEyePosition().subtract(0.0, 0.1, 0.0), now));
                     }
                  }

                  if (points.isEmpty() || ((TrailsModule.TrailPoint)points.get(points.size() - 1)).pos().distanceToSqr(pos) > 1.0E-4) {
                     points.add(new TrailsModule.TrailPoint(pos, now));
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (mc.level != null && mc.player != null && !this.trails.isEmpty()) {
         long now = System.currentTimeMillis();
         long maxAge = this.fade.getValue().longValue();
         PoseStack matrices = event.getMatrices();
         Color baseColor = this.color.getColor();
         HashMap<UUID, Entity> liveEntities = new HashMap<>();

         for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity.isAlive()) {
               liveEntities.put(entity.getUUID(), entity);
            }
         }

         Iterator<Entry<UUID, List<TrailsModule.TrailPoint>>> iterator = this.trails.entrySet().iterator();

         while (iterator.hasNext()) {
            Entry<UUID, List<TrailsModule.TrailPoint>> entry = iterator.next();
            UUID uuid = entry.getKey();
            List<TrailsModule.TrailPoint> points = entry.getValue();
            Entity liveEntity = liveEntities.get(uuid);
            synchronized (points) {
               points.removeIf(p -> now - p.time() > maxAge);
               if (points.isEmpty() && liveEntity == null) {
                  iterator.remove();
               } else if (points.size() >= 1 || liveEntity != null) {
                  for (int i = 0; i < points.size() - 1; i++) {
                     TrailsModule.TrailPoint p1 = points.get(i);
                     TrailsModule.TrailPoint p2 = points.get(i + 1);
                     float alphaRatio1 = maxAge > 0L ? Mth.clamp(1.0F - (float)(now - p1.time()) / (float)maxAge, 0.0F, 1.0F) : 1.0F;
                     float alphaRatio2 = maxAge > 0L ? Mth.clamp(1.0F - (float)(now - p2.time()) / (float)maxAge, 0.0F, 1.0F) : 1.0F;
                     Color c1 = ColorUtils.getColor(baseColor, Math.round(baseColor.getAlpha() * alphaRatio1));
                     Color c2 = ColorUtils.getColor(baseColor, Math.round(baseColor.getAlpha() * alphaRatio2));
                     Renderer3D.renderLine(matrices, p1.pos(), p2.pos(), c1, c2);
                  }

                  if (liveEntity != null && !points.isEmpty()) {
                     TrailsModule.TrailPoint lastPoint = points.get(points.size() - 1);
                     Vec3 lerpedHead = EntityUtils.getRenderPos(liveEntity, event.getTickDelta()).add(0.0, liveEntity.getBbHeight() * 0.5, 0.0);
                     float alphaLast = maxAge > 0L ? Mth.clamp(1.0F - (float)(now - lastPoint.time()) / (float)maxAge, 0.0F, 1.0F) : 1.0F;
                     Color cLast = ColorUtils.getColor(baseColor, Math.round(baseColor.getAlpha() * alphaLast));
                     Color cHead = ColorUtils.getColor(baseColor, baseColor.getAlpha());
                     Renderer3D.renderLine(matrices, lastPoint.pos(), lerpedHead, cLast, cHead);
                  }
               }
            }
         }
      }
   }

   private boolean isValidTarget(Entity entity) {
      if (!this.pearls.getValue() || !(entity instanceof ThrownEnderpearl) && entity.getType() != EntityTypes.ENDER_PEARL) {
         if (!this.arrows.getValue()
            || !(entity instanceof AbstractArrow) && entity.getType() != EntityTypes.ARROW && entity.getType() != EntityTypes.SPECTRAL_ARROW) {
            if (!this.witherSkull.getValue() || !(entity instanceof WitherSkull) && entity.getType() != EntityTypes.WITHER_SKULL) {
               if (!this.egg.getValue() || !(entity instanceof ThrownEgg) && entity.getType() != EntityTypes.EGG) {
                  return !this.snowball.getValue() || !(entity instanceof Snowball) && entity.getType() != EntityTypes.SNOWBALL
                     ? this.fireCharge.getValue()
                        && (
                           entity instanceof SmallFireball
                              || entity instanceof LargeFireball
                              || entity instanceof Fireball
                              || entity instanceof DragonFireball
                              || entity.getType() == EntityTypes.SMALL_FIREBALL
                              || entity.getType() == EntityTypes.FIREBALL
                              || entity.getType() == EntityTypes.DRAGON_FIREBALL
                        )
                     : true;
               } else {
                  return true;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   @Override
   public void onDisable() {
      this.trails.clear();
   }

   @SubscribeEvent
   public void onDisconnect(ClientDisconnectEvent event) {
      this.trails.clear();
   }

   @SubscribeEvent
   public void onConnect(ClientConnectEvent event) {
      this.trails.clear();
   }

   @SubscribeEvent
   public void onServerConnect(ServerConnectEvent event) {
      this.trails.clear();
   }

   public record TrailPoint(Vec3 pos, long time) {
   }
}
