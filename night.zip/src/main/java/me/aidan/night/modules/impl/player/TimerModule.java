package night.modules.impl.player;

import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.NumberSetting;

@RegisterModule(
   name = "Timer",
   description = "Makes your game run at a faster tick speed.",
   category = Module.Category.PLAYER
)
public class TimerModule extends Module {
   public NumberSetting multiplier = new NumberSetting("Multiplier", "The multiplier that will be added to the game's speed.", 1.0F, 0.0F, 20.0F);

   @SubscribeEvent(
      priority = Integer.MIN_VALUE
   )
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null) {
         Night.WORLD_MANAGER.setTimerMultiplier(this.multiplier.getValue().floatValue());
      }
   }

   @Override
   public void onEnable() {
      Night.WORLD_MANAGER.setTimerMultiplier(this.multiplier.getValue().floatValue());
   }

   @Override
   public void onDisable() {
      Night.WORLD_MANAGER.setTimerMultiplier(1.0F);
   }

   @Override
   public String getMetaData() {
      return String.valueOf(this.multiplier.getValue().floatValue());
   }
}
