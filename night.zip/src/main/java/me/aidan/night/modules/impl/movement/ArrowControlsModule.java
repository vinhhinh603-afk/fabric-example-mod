package night.modules.impl.movement;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import net.minecraft.client.gui.screens.inventory.BookEditScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.JigsawBlockEditScreen;
import net.minecraft.client.gui.screens.inventory.SignEditScreen;
import net.minecraft.client.gui.screens.inventory.StructureBlockEditScreen;
import net.minecraft.util.Mth;
import net.minecraft.world.item.CreativeModeTab.Type;
import night.events.SubscribeEvent;
import night.events.impl.RenderWorldEvent;
import night.mixins.accessors.CreativeInventoryScreenAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.NumberSetting;

@RegisterModule(
   name = "ArrowControls",
   description = "Allows you to control the camera using your arrow keys.",
   category = Module.Category.MOVEMENT
)
public class ArrowControlsModule extends Module {
   public NumberSetting speed = new NumberSetting("Speed", "The speed at which the camera will be moving at.", 1.0F, 0.1F, 10.0F);
   public BooleanSetting inventory = new BooleanSetting("Inventory", "Allows you to control the camera when a screen is opened.", true);
   private long lastTime;

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (mc.player != null && mc.level != null) {
         if (mc.gui.screen() == null
            || this.inventory.getValue()
               && !(mc.gui.screen() instanceof ChatScreen)
               && !(mc.gui.screen() instanceof BookEditScreen)
               && !(mc.gui.screen() instanceof SignEditScreen)
               && !(mc.gui.screen() instanceof JigsawBlockEditScreen)
               && !(mc.gui.screen() instanceof StructureBlockEditScreen)
               && !(mc.gui.screen() instanceof AnvilScreen)
               && (!(mc.gui.screen() instanceof CreativeModeInventoryScreen) || CreativeInventoryScreenAccessor.getSelectedTab().getType() != Type.SEARCH)) {
            float yaw = 0.0F;
            float pitch = 0.0F;
            float amount = (float)(System.currentTimeMillis() - this.lastTime) / 10.0F * this.speed.getValue().floatValue();
            this.lastTime = System.currentTimeMillis();
            if (InputConstants.isKeyDown(mc.getWindow(), 263)) {
               yaw -= amount;
            }

            if (InputConstants.isKeyDown(mc.getWindow(), 262)) {
               yaw += amount;
            }

            if (InputConstants.isKeyDown(mc.getWindow(), 265)) {
               pitch -= amount;
            }

            if (InputConstants.isKeyDown(mc.getWindow(), 264)) {
               pitch += amount;
            }

            mc.player.setYRot(mc.player.getYRot() + yaw);
            mc.player.setXRot(Mth.clamp(mc.player.getXRot() + pitch, -90.0F, 90.0F));
         }
      }
   }

   @Override
   public String getMetaData() {
      return String.valueOf(this.speed.getValue().floatValue());
   }
}
