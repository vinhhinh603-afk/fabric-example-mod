package night.modules.api;

public interface IFullBrightModule {
   boolean isToggled();

   String getModeValue();
}
