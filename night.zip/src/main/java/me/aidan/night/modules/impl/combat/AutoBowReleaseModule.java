package night.modules.impl.combat;

import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.NetworkUtils;

@RegisterModule(
   name = "AutoBowRelease",
   description = "Automatically releases your bow after a certain amount of time has passed.",
   category = Module.Category.COMBAT
)
public class AutoBowReleaseModule extends Module {
   public NumberSetting ticks = new NumberSetting("Ticks", "The number of ticks that have to be waited for before releasing the bow.", 3, 0, 20);

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (!Night.MODULE_MANAGER.getModule(SelfBowModule.class).isToggled()) {
         if ((mc.player.getOffhandItem().getItem() == Items.BOW || mc.player.getMainHandItem().getItem() == Items.BOW)
            && mc.player.isUsingItem()
            && mc.player.getTicksUsingItem() >= this.ticks.getValue().intValue()) {
            mc.getConnection().send(new ServerboundPlayerActionPacket(Action.RELEASE_USE_ITEM, BlockPos.ZERO, mc.player.getDirection()));
            NetworkUtils.sendSequencedPacket(
               id -> new ServerboundUseItemPacket(
                  mc.player.getOffhandItem().getItem() == Items.BOW ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND,
                  id,
                  mc.player.getYRot(),
                  mc.player.getXRot()
               )
            );
            mc.player.stopUsingItem();
         }
      }
   }

   @Override
   public String getMetaData() {
      return String.valueOf(this.ticks.getValue().intValue());
   }
}
