package night.modules.impl.combat;

import com.mojang.blaze3d.vertex.PoseStack;
import java.awt.Color;
import java.util.Comparator;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.graphics.Renderer3D;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.rotations.RotationUtils;

@RegisterModule(
   name = "SpearKill",
   description = "Lunges at players and attacks with a spear/trident.",
   category = Module.Category.COMBAT
)
public class SpearKillModule extends Module {
   public NumberSetting range = new NumberSetting("Range", "Range to search for players.", 12.0F, 1.0F, 100.0F);
   public NumberSetting wallRange = new NumberSetting("WallRange", "Range to search through walls.", 4.0F, 0.0F, 100.0F);
   public NumberSetting hitRange = new NumberSetting("HitRange", "Range to send spear attacks.", 4.2F, 1.0F, 100.0F);
   public NumberSetting delay = new NumberSetting("Delay", "Minimum delay in milliseconds between attacks.", 100, 0, 1000);
   public BooleanSetting attackDelay = new BooleanSetting("AttackDelay", "Uses vanilla attack cooldown before attacking.", true);
   public NumberSetting attackSpeed = new NumberSetting(
      "AttackSpeed", "Attacks per second when AttackDelay is off.", new BooleanSetting.Visibility(this.attackDelay, false), 8.0F, 1.0F, 20.0F
   );
   public ModeSetting autoSwap = new ModeSetting("AutoSwap", "Swaps to a spear before attacking.", "Normal", new String[]{"Off", "Normal", "Silent"});
   public BooleanSetting rotate = new BooleanSetting("Rotate", "Rotates to the target before lunging and attacking.", true);
   public BooleanSetting lunge = new BooleanSetting("Lunge", "Pushes you toward the target.", true);
   public NumberSetting lungeSpeed = new NumberSetting(
      "LungeSpeed", "Horizontal lunge speed.", new BooleanSetting.Visibility(this.lunge, true), 1.25F, 0.1F, 5.0F
   );
   public NumberSetting lungeY = new NumberSetting(
      "LungeY", "Upward velocity added while lunging.", new BooleanSetting.Visibility(this.lunge, true), 0.08F, 0.0F, 1.0F
   );
   public NumberSetting stopDistance = new NumberSetting(
      "StopDistance", "Stops lunging inside this distance.", new BooleanSetting.Visibility(this.lunge, true), 2.4F, 0.0F, 6.0F
   );
   public NumberSetting lungeDelay = new NumberSetting(
      "LungeDelay", "Delay in milliseconds between lunges.", new BooleanSetting.Visibility(this.lunge, true), 150, 0, 1000
   );
   public BooleanSetting swing = new BooleanSetting("Swing", "Swings the hand after attacking.", true);
   public BooleanSetting render = new BooleanSetting("Render", "Renders the current SpearKill target.", true);
   public BooleanSetting renderLine = new BooleanSetting(
      "RenderLine", "Renders a line to the current target.", new BooleanSetting.Visibility(this.render, true), true
   );
   public ColorSetting fillColor = new ColorSetting(
      "FillColor",
      "Fill color for the target render.",
      new BooleanSetting.Visibility(this.render, true),
      new ColorSetting.Color(new Color(255, 210, 90, 45), false, false)
   );
   public ColorSetting lineColor = new ColorSetting(
      "LineColor",
      "Outline and line color for the target render.",
      new BooleanSetting.Visibility(this.render, true),
      new ColorSetting.Color(new Color(255, 210, 90, 180), false, false)
   );
   private long lastAttackMs = 0L;
   private long lastLungeMs = 0L;
   private Player target;

   @Override
   public String getMetaData() {
      return this.target != null ? this.target.getName().getString() : "Spear";
   }

   @Override
   public void onDisable() {
      this.target = null;
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null && !mc.player.isSpectator()) {
         this.target = this.findTarget();
         if (this.target != null) {
            int spearSlot = this.getSpearSlot();
            if (spearSlot != -1 || this.isHoldingSpear()) {
               boolean silentSwapped = false;
               int prevSlot = mc.player.getInventory().getSelectedSlot();
               if (!this.isHoldingSpear()) {
                  if (this.autoSwap.getValue().equalsIgnoreCase("Off")) {
                     return;
                  }

                  if (this.autoSwap.getValue().equalsIgnoreCase("Normal")) {
                     InventoryUtils.switchSlot("Normal", spearSlot, prevSlot);
                  } else if (this.autoSwap.getValue().equalsIgnoreCase("Silent")) {
                     InventoryUtils.switchSlot("Silent", spearSlot, prevSlot);
                     silentSwapped = true;
                  }
               }

               if (this.rotate.getValue()) {
                  float[] rot = RotationUtils.getRotations(this.target.getX(), this.target.getY() + this.target.getEyeHeight() / 2.0, this.target.getZ());
                  Night.ROTATION_MANAGER.legacyRotate(rot[0], rot[1], this, Night.ROTATION_MANAGER.getLegacyModulePriority(this));
               }

               double dist = mc.player.distanceTo(this.target);
               if (this.lunge.getValue()
                  && dist > this.stopDistance.getValue().doubleValue()
                  && System.currentTimeMillis() - this.lastLungeMs >= this.lungeDelay.getValue().longValue()) {
                  this.doLunge(this.target);
                  this.lastLungeMs = System.currentTimeMillis();
               }

               if (dist <= this.hitRange.getValue().doubleValue() && this.canAttack()) {
                  this.doAttack(this.target);
                  this.lastAttackMs = System.currentTimeMillis();
               }

               if (silentSwapped) {
                  InventoryUtils.switchBack("Silent", spearSlot, prevSlot);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (this.render.getValue() && this.target != null && this.target.isAlive() && !this.target.isRemoved()) {
         PoseStack matrices = event.getMatrices();
         Vec3 renderPos = EntityUtils.getRenderPos(this.target, event.getTickDelta());
         AABB box = this.target.getBoundingBox().move(renderPos.x - this.target.getX(), renderPos.y - this.target.getY(), renderPos.z - this.target.getZ());
         Renderer3D.renderBox(matrices, box, this.fillColor.getColor());
         Renderer3D.renderBoxOutline(matrices, box, this.lineColor.getColor());
         if (this.renderLine.getValue()) {
            Vec3 eyePos = EntityUtils.getRenderPos(mc.player, event.getTickDelta()).add(0.0, mc.player.getEyeHeight(mc.player.getPose()), 0.0);
            Renderer3D.renderLine(matrices, eyePos, box.getCenter(), this.lineColor.getColor());
         }
      }
   }

   private Player findTarget() {
      return mc.level.players().stream().filter(this::isValidTarget).min(Comparator.comparingDouble(p -> mc.player.distanceToSqr(p))).orElse(null);
   }

   private boolean isValidTarget(Player player) {
      if (player == mc.player || !player.isAlive() || player.isRemoved() || player.isSpectator()) {
         return false;
      } else if (EntityUtils.isGhost(player)) {
         return false;
      } else if (Night.FRIEND_MANAGER.contains(player.getName().getString())) {
         return false;
      } else {
         double dist = mc.player.distanceTo(player);
         return dist > this.range.getValue().doubleValue() ? false : mc.player.hasLineOfSight(player) || dist <= this.wallRange.getValue().doubleValue();
      }
   }

   private boolean canAttack() {
      if (System.currentTimeMillis() - this.lastAttackMs < this.delay.getValue().longValue()) {
         return false;
      } else {
         return this.attackDelay.getValue()
            ? mc.player.getAttackStrengthScale(0.5F) >= 1.0F
            : System.currentTimeMillis() - this.lastAttackMs >= (long)(1000.0F / Math.max(this.attackSpeed.getValue().floatValue(), 0.1F));
      }
   }

   private void doLunge(Player player) {
      Vec3 delta = player.position().subtract(mc.player.position());
      Vec3 horizontal = new Vec3(delta.x, 0.0, delta.z);
      if (!(horizontal.length() < 1.0E-4)) {
         Vec3 dir = horizontal.normalize();
         double vy = Math.max(mc.player.getDeltaMovement().y, this.lungeY.getValue().doubleValue());
         mc.player.setDeltaMovement(dir.x * this.lungeSpeed.getValue().doubleValue(), vy, dir.z * this.lungeSpeed.getValue().doubleValue());
      }
   }

   private void doAttack(Player player) {
      mc.gameMode.attack(mc.player, player);
      mc.player.resetAttackStrengthTicker();
      if (this.swing.getValue()) {
         mc.player.swing(InteractionHand.MAIN_HAND);
      } else {
         mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
      }
   }

   private boolean isHoldingSpear() {
      if (mc.player == null) {
         return false;
      } else {
         ItemStack held = mc.player.getMainHandItem();
         return held.is(Items.TRIDENT) || held.getItem() instanceof TridentItem;
      }
   }

   private int getSpearSlot() {
      if (mc.player == null) {
         return -1;
      } else {
         for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (stack.is(Items.TRIDENT) || stack.getItem() instanceof TridentItem) {
               return i;
            }
         }

         return -1;
      }
   }
}
