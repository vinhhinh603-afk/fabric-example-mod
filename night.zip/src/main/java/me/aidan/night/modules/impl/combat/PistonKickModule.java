package night.modules.impl.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.Plane;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.MushroomBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.ScaffoldingBlock;
import net.minecraft.world.level.block.SignBlock;
import net.minecraft.world.level.block.TallFlowerBlock;
import net.minecraft.world.level.block.TorchBlock;
import net.minecraft.world.level.block.TripWireBlock;
import net.minecraft.world.level.block.TripWireHookBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.WebBlock;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.DamageUtils;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.PistonHelper;
import night.utils.minecraft.WorldUtils;
import night.utils.miscellaneous.RenderPosition;
import night.utils.rotations.RotationUtils;

@RegisterModule(
   name = "PistonKick",
   description = "Pushes players out of holes or solid blocks using pistons.",
   category = Module.Category.COMBAT
)
public final class PistonKickModule extends Module {
   public static PistonKickModule INSTANCE;
   public NumberSetting delay = new NumberSetting("Delay", "Delay between pushes (ticks)", 1, 0, 10);
   public NumberSetting pushDelay = new NumberSetting("PushDelay", "Duration to hold piston extended before retracting (ms)", 150, 50, 500);
   public ModeSetting power = new ModeSetting("Power", "How the piston is powered.", "Redstone", new String[]{"Redstone", "Lever"});
   public BooleanSetting airPlace = new BooleanSetting("AirPlace", "Allow placing when not on ground.", false);
   public BooleanSetting oneTwelve = new BooleanSetting("1.12", "Place piston and power in the same tick.", true);
   public NumberSetting targetRange = new NumberSetting("TargetRange", "Target range.", 5.0F, 1.0F, 6.0F);
   public BooleanSetting inAirTarget = new BooleanSetting("InAirTarget", "Target players in the air.", true);
   public ModeSetting rotate = new ModeSetting("Rotate", "Silently rotate when placing.", "Silent", new String[]{"None", "Normal", "Silent"});
   public BooleanSetting breakCrystal = new BooleanSetting("BreakCrystal", "Break end crystals blocking piston path.", false);
   public NumberSetting placeRange = new NumberSetting("PlaceRange", "Block place range.", 5.0F, 1.0F, 6.0F);
   public NumberSetting breakRange = new NumberSetting(
      "BreakRange", "Crystal break range.", new BooleanSetting.Visibility(this.breakCrystal, true), 4.5F, 1.0F, 6.0F
   );
   public NumberSetting maxLocalDamage = new NumberSetting(
      "MaxLocalDamage", "Max self-damage allowed to break a crystal.", new BooleanSetting.Visibility(this.breakCrystal, true), 8.0F, 0.0F, 20.0F
   );
   public BooleanSetting safety = new BooleanSetting(
      "Safety", "Never break a crystal that would kill you.", new BooleanSetting.Visibility(this.breakCrystal, true), true
   );
   public ModeSetting swapAction = new ModeSetting("Swap", "How to swap to required items.", "Silent", InventoryUtils.SWITCH_MODES);
   public BooleanSetting consecutive = new BooleanSetting("Consecutive", "Keep targeting the same player consecutively.", true);
   public BooleanSetting merge = new BooleanSetting("Merge", "Burst piston and power packets together.", false);
   public BooleanSetting pauseOnEat = new BooleanSetting("PauseOnEat", "Pause while eating or using items.", false);
   public BooleanSetting strictDirection = new BooleanSetting(
      "StrictDirection", "Use raytrace to verify line-of-sight before placing piston/redstone (required on servers that check raytrace).", false
   );
   public BooleanSetting render = new BooleanSetting("Render", "Render placed blocks using RendersModule.", true);
   private BlockPos targetPhasedPos;
   private BlockPos pistonPos;
   private BlockPos redstonePos;
   private BlockPos supportPos;
   private final List<BlockPos> supportPositions = new ArrayList<>();
   private Direction pushDir;
   private Player currentTarget;
   private long lastActionMs = 0L;
   private long extendedSinceMs = 0L;
   private long leverTurnedOnMs = 0L;

   public PistonKickModule() {
      INSTANCE = this;
   }

   public static PistonKickModule getInstance() {
      return INSTANCE;
   }

   @Override
   public void onEnable() {
      this.resetState();
   }

   @Override
   public void onDisable() {
      this.resetState();
   }

   private void resetState() {
      this.targetPhasedPos = null;
      this.pistonPos = null;
      this.redstonePos = null;
      this.supportPos = null;
      this.supportPositions.clear();
      this.pushDir = null;
      this.currentTarget = null;
      this.extendedSinceMs = 0L;
      this.leverTurnedOnMs = 0L;
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null) {
         if (!this.pauseOnEat.getValue() || !EntityUtils.isEating()) {
            long nowMs = System.currentTimeMillis();
            if (nowMs - this.lastActionMs >= this.delay.getValue().longValue() * 50L) {
               int pistonSlot = this.findPiston();
               int powerSlot = this.findPower();
               if (pistonSlot != -1 && powerSlot != -1) {
                  if (this.currentTarget != null) {
                     if (this.currentTarget.isAlive()
                        && !this.currentTarget.isSpectator()
                        && !(mc.player.distanceToSqr(this.currentTarget) > this.targetRange.getValue().floatValue() * this.targetRange.getValue().floatValue())
                        )
                      {
                        List<BlockPos> phasedList = this.getPhasedSolidBlocks(this.currentTarget);
                        if (phasedList.isEmpty()) {
                           this.resetState();
                        } else if (this.targetPhasedPos == null || !phasedList.contains(this.targetPhasedPos)) {
                           this.targetPhasedPos = phasedList.get(0);
                        }
                     } else {
                        this.resetState();
                     }
                  }

                  if (this.currentTarget == null) {
                     for (Player enemy : this.getEnemies()) {
                        List<BlockPos> phasedList;
                        if ((this.inAirTarget.getValue() || enemy.onGround()) && !(phasedList = this.getPhasedSolidBlocks(enemy)).isEmpty()) {
                           this.currentTarget = enemy;
                           this.targetPhasedPos = phasedList.get(0);
                           break;
                        }
                     }
                  }

                  if (this.currentTarget != null && this.targetPhasedPos != null) {
                     if (this.breakCrystal.getValue()) {
                        this.breakNearbyCrystals(this.currentTarget);
                     }

                     if (this.pistonPos != null && this.pushDir != null) {
                        boolean pistonPlaced = this.isPistonPlacedAndFacing(this.pistonPos, this.pushDir);
                        boolean pistonExtended = this.isPistonExtended(this.pistonPos);
                        boolean isPowered = this.isPistonPowered(this.pistonPos);
                        boolean isLeverMode = this.power.getValue().equalsIgnoreCase("Lever");
                        if (pistonExtended) {
                           if (this.extendedSinceMs == 0L) {
                              this.extendedSinceMs = nowMs;
                           }

                           if (nowMs - this.extendedSinceMs < Math.max(50L, this.pushDelay.getValue().longValue())
                              || this.leverTurnedOnMs > 0L && nowMs - this.leverTurnedOnMs < 50L) {
                              this.lastActionMs = nowMs;
                              return;
                           }

                           if (isLeverMode && this.redstonePos != null && this.isLever(this.redstonePos) && this.isLeverPowered(this.redstonePos)) {
                              this.clickLever(this.redstonePos);
                              this.leverTurnedOnMs = 0L;
                              this.lastActionMs = nowMs;
                              return;
                           }

                           if (isLeverMode && this.redstonePos != null && !this.isLeverPowered(this.redstonePos) && pistonExtended) {
                              this.lastActionMs = nowMs;
                              return;
                           }

                           List<BlockPos> remaining = this.getPhasedSolidBlocks(this.currentTarget);
                           if (remaining.isEmpty()) {
                              this.resetState();
                              return;
                           }

                           this.pistonPos = null;
                           this.redstonePos = null;
                           this.supportPos = null;
                           this.pushDir = null;
                           this.extendedSinceMs = 0L;
                           this.leverTurnedOnMs = 0L;
                           this.lastActionMs = nowMs;
                        } else {
                           this.extendedSinceMs = 0L;
                        }

                        if (pistonPlaced && isPowered && !pistonExtended) {
                           this.lastActionMs = nowMs;
                           return;
                        }

                        boolean air = this.airPlace.getValue();
                        if (!pistonPlaced && !PistonHelper.canPlace(this.pistonPos, null, air, true)) {
                           boolean hasSupport = !isLeverMode
                                 && this.redstonePos != null
                                 && this.redstonePos.equals(this.pistonPos.below())
                                 && (PistonHelper.canPlace(this.redstonePos, null, air, true) || this.isPowerSource(this.redstonePos))
                              || !this.supportPositions.isEmpty()
                                 && this.supportPositions.stream().anyMatch(p -> PistonHelper.canPlace(p, null, air, true) || this.isSolidBlock(p))
                              || this.supportPos != null && (PistonHelper.canPlace(this.supportPos, null, air, true) || this.isSolidBlock(this.supportPos));
                           if (!hasSupport) {
                              this.resetState();
                           }
                        }
                     }

                     if (this.pistonPos != null && this.pushDir != null || this.searchPlacement(this.currentTarget)) {
                        if (this.pistonPos != null && this.pushDir != null) {
                           boolean air = this.airPlace.getValue();
                           boolean isLeverModex = this.power.getValue().equalsIgnoreCase("Lever");

                           for (BlockPos sPos : this.supportPositions) {
                              int supportSlot2;
                              if (!this.isSolidBlock(sPos) && PistonHelper.canPlace(sPos, null, air, true) && (supportSlot2 = this.findSupportBlock()) != -1) {
                                 this.placeBlock(supportSlot2, sPos, null);
                                 this.lastActionMs = nowMs;
                                 if (!this.oneTwelve.getValue() && !this.merge.getValue()) {
                                    return;
                                 }
                              }
                           }

                           int supportSlot;
                           if (this.supportPos != null
                              && !this.isSolidBlock(this.supportPos)
                              && !this.supportPositions.contains(this.supportPos)
                              && PistonHelper.canPlace(this.supportPos, null, air, true)
                              && (supportSlot = this.findSupportBlock()) != -1) {
                              this.placeBlock(supportSlot, this.supportPos, null);
                              this.lastActionMs = nowMs;
                              if (!this.oneTwelve.getValue() && !this.merge.getValue()) {
                                 return;
                              }
                           }

                           boolean isSupportRedstone = !isLeverModex && this.redstonePos != null && this.redstonePos.equals(this.pistonPos.below());
                           if (isSupportRedstone && !this.isPowerSource(this.redstonePos) && PistonHelper.canPlace(this.redstonePos, null, air, true)) {
                              this.placeBlock(powerSlot, this.redstonePos, null);
                              this.lastActionMs = nowMs;
                              if (!this.oneTwelve.getValue() && !this.merge.getValue()) {
                                 return;
                              }
                           }

                           boolean needPiston = !this.isPistonPlacedAndFacing(this.pistonPos, this.pushDir);
                           if (needPiston && PistonHelper.canPlace(this.pistonPos, null, air, true)) {
                              this.placeBlock(pistonSlot, this.pistonPos, this.pushDir);
                              this.lastActionMs = nowMs;
                              if (!this.oneTwelve.getValue() && !this.merge.getValue()) {
                                 return;
                              }
                           }

                           if (this.redstonePos != null && !this.isPistonPowered(this.pistonPos) && !this.isPowerSource(this.redstonePos)) {
                              boolean canPlacePower = !isLeverModex || this.isPistonPlacedAndFacing(this.pistonPos, this.pushDir) || air;
                              if (canPlacePower && PistonHelper.canPlace(this.redstonePos, null, air, true)) {
                                 this.placeBlock(powerSlot, this.redstonePos, null);
                                 this.lastActionMs = nowMs;
                                 if (isLeverModex) {
                                    this.clickLever(this.redstonePos);
                                    this.leverTurnedOnMs = nowMs;
                                 }
                              }
                           } else if (isLeverModex
                              && this.redstonePos != null
                              && this.isLever(this.redstonePos)
                              && !this.isLeverPowered(this.redstonePos)
                              && !this.isPistonExtended(this.pistonPos)
                              && this.extendedSinceMs == 0L) {
                              this.clickLever(this.redstonePos);
                              this.leverTurnedOnMs = nowMs;
                              this.lastActionMs = nowMs;
                           }
                        }
                     }
                  } else {
                     this.resetState();
                  }
               } else {
                  this.resetState();
               }
            }
         }
      }
   }

   private boolean searchPlacement(Player target) {
      List<BlockPos> phasedBlocks = this.getPhasedSolidBlocks(target);
      if (phasedBlocks.isEmpty()) {
         return false;
      } else {
         if (phasedBlocks.size() >= 2) {
            Direction playerFacing = mc.player.getDirection();
            Axis verticalAxis = playerFacing.getAxis();
            phasedBlocks.sort((b1, b2) -> {
               boolean b1IsVertical = verticalAxis == Axis.Z && b1.getZ() != b2.getZ() || verticalAxis == Axis.X && b1.getX() != b2.getX();
               return b1IsVertical ? -1 : 1;
            });
         }

         for (BlockPos phasedPos : phasedBlocks) {
            if (this.searchPlacementForBlock(target, phasedPos)) {
               this.targetPhasedPos = phasedPos;
               return true;
            }
         }

         return false;
      }
   }

   private boolean searchPlacementForBlock(Player target, BlockPos phasedPos) {
      ArrayList<Direction> dirs = new ArrayList<>();
      Direction playerFacing = mc.player.getDirection();
      dirs.add(playerFacing);

      for (Direction d : Plane.HORIZONTAL) {
         if (d != playerFacing) {
            dirs.add(d);
         }
      }

      BlockPos headPos = phasedPos.above();
      boolean air = this.airPlace.getValue();
      boolean isLeverMode = this.power.getValue().equalsIgnoreCase("Lever");

      for (Direction pDir : dirs) {
         if (this.isDestinationOpen(phasedPos, pDir)) {
            BlockPos pPos = headPos.relative(pDir.getOpposite());
            if ((mc.level.getBlockState(headPos).isAir() || mc.level.getBlockState(headPos).canBeReplaced()) && this.inRange(pPos)) {
               boolean isPistonReady = this.isPistonPlacedAndFacing(pPos, pDir);
               boolean isPPosAir = mc.level.getBlockState(pPos).isAir() || mc.level.getBlockState(pPos).canBeReplaced();
               if (isPistonReady || isPPosAir) {
                  boolean canPistonDirect = isPistonReady || PistonHelper.canPlace(pPos, null, air, true);
                  if (canPistonDirect) {
                     if (this.isPistonPowered(pPos)) {
                        this.supportPos = null;
                        this.pistonPos = pPos;
                        this.redstonePos = null;
                        this.pushDir = pDir;
                        return true;
                     }

                     if (isLeverMode) {
                        BlockPos pistonSupport = pPos.below();
                        boolean needPistonSupport = !air && !this.isSolidBlock(pistonSupport);
                        ArrayList<PistonKickModule.LeverCandidate> candidates = new ArrayList<>();
                        BlockPos backPos = pPos.relative(pDir.getOpposite());
                        BlockPos backSupport = backPos.below();
                        ArrayList<BlockPos> backSupports = new ArrayList<>();
                        if (needPistonSupport) {
                           backSupports.add(pistonSupport);
                        }

                        if (!air && !this.isSolidBlock(backSupport)) {
                           backSupports.add(backSupport);
                        }

                        candidates.add(new PistonKickModule.LeverCandidate(backPos, backSupports));
                        BlockPos leftPos = pPos.relative(pDir.getCounterClockWise());
                        BlockPos leftSupport = leftPos.below();
                        ArrayList<BlockPos> leftSupports = new ArrayList<>();
                        if (needPistonSupport) {
                           leftSupports.add(pistonSupport);
                        }

                        if (!air && !this.isSolidBlock(leftSupport)) {
                           leftSupports.add(leftSupport);
                        }

                        candidates.add(new PistonKickModule.LeverCandidate(leftPos, leftSupports));
                        if (this.isSolidBlock(leftPos)) {
                           BlockPos leftAbovePos = leftPos.above();
                           ArrayList<BlockPos> leftAboveSupports = new ArrayList<>();
                           if (needPistonSupport) {
                              leftAboveSupports.add(pistonSupport);
                           }

                           candidates.add(new PistonKickModule.LeverCandidate(leftAbovePos, leftAboveSupports));
                        }

                        BlockPos rightPos = pPos.relative(pDir.getClockWise());
                        BlockPos rightSupport = rightPos.below();
                        ArrayList<BlockPos> rightSupports = new ArrayList<>();
                        if (needPistonSupport) {
                           rightSupports.add(pistonSupport);
                        }

                        if (!air && !this.isSolidBlock(rightSupport)) {
                           rightSupports.add(rightSupport);
                        }

                        candidates.add(new PistonKickModule.LeverCandidate(rightPos, rightSupports));
                        if (this.isSolidBlock(rightPos)) {
                           BlockPos rightAbovePos = rightPos.above();
                           ArrayList<BlockPos> rightAboveSupports = new ArrayList<>();
                           if (needPistonSupport) {
                              rightAboveSupports.add(pistonSupport);
                           }

                           candidates.add(new PistonKickModule.LeverCandidate(rightAbovePos, rightAboveSupports));
                        }

                        if (this.isSolidBlock(backPos)) {
                           BlockPos back2Pos = pPos.relative(pDir.getOpposite(), 2);
                           ArrayList<BlockPos> back2Supports = new ArrayList<>();
                           if (needPistonSupport) {
                              back2Supports.add(pistonSupport);
                           }

                           candidates.add(new PistonKickModule.LeverCandidate(back2Pos, back2Supports));
                           BlockPos backAbovePos = backPos.above();
                           ArrayList<BlockPos> backAboveSupports = new ArrayList<>();
                           if (needPistonSupport) {
                              backAboveSupports.add(pistonSupport);
                           }

                           candidates.add(new PistonKickModule.LeverCandidate(backAbovePos, backAboveSupports));
                        }

                        BlockPos backBelowPos = pPos.relative(pDir.getOpposite()).below();
                        ArrayList<BlockPos> backBelowSupports = new ArrayList<>();
                        if (needPistonSupport) {
                           backBelowSupports.add(pistonSupport);
                        }

                        candidates.add(new PistonKickModule.LeverCandidate(backBelowPos, backBelowSupports));

                        for (PistonKickModule.LeverCandidate candidate : candidates) {
                           BlockPos candidateRPos = candidate.leverPos;
                           if (!candidateRPos.equals(pPos.relative(pDir))
                              && !candidateRPos.equals(headPos)
                              && !candidateRPos.equals(headPos.below())
                              && !candidateRPos.equals(phasedPos.relative(pDir))
                              && !candidateRPos.equals(headPos.relative(pDir))
                              && this.inRange(candidateRPos)) {
                              boolean leverPlaceable = this.isLever(candidateRPos)
                                 || mc.level.getBlockState(candidateRPos).isAir()
                                 || mc.level.getBlockState(candidateRPos).canBeReplaced();
                              if (leverPlaceable) {
                                 boolean supportsValid = true;

                                 for (BlockPos s : candidate.neededSupports) {
                                    if (s.equals(headPos)
                                       || s.equals(headPos.below())
                                       || s.equals(phasedPos.relative(pDir))
                                       || s.equals(headPos.relative(pDir))) {
                                       supportsValid = false;
                                       break;
                                    }

                                    if (!this.inRange(s)) {
                                       supportsValid = false;
                                       break;
                                    }

                                    if (!this.isSolidBlock(s) && !PistonHelper.canPlace(s, null, air, true)) {
                                       supportsValid = false;
                                       break;
                                    }
                                 }

                                 if (supportsValid) {
                                    this.supportPositions.clear();
                                    this.supportPositions.addAll(candidate.neededSupports);
                                    this.supportPos = candidate.neededSupports.isEmpty() ? null : candidate.neededSupports.get(0);
                                    this.pistonPos = pPos;
                                    this.redstonePos = candidateRPos;
                                    this.pushDir = pDir;
                                    return true;
                                 }
                              }
                           }
                        }
                     } else {
                        BlockPos rPos = this.findBestPowerPos(pPos, headPos, phasedPos.relative(pDir), pDir);
                        if (rPos != null) {
                           this.supportPos = null;
                           this.pistonPos = pPos;
                           this.redstonePos = rPos;
                           this.pushDir = pDir;
                           return true;
                        }

                        for (Direction rDir : new Direction[]{
                           Direction.UP, pDir.getOpposite(), pDir.getClockWise(), pDir.getCounterClockWise(), Direction.DOWN
                        }) {
                           BlockPos candidateRPos = pPos.relative(rDir);
                           if (!candidateRPos.equals(pPos.relative(pDir))
                              && !candidateRPos.equals(headPos)
                              && !candidateRPos.equals(headPos.below())
                              && !candidateRPos.equals(phasedPos.relative(pDir))
                              && !candidateRPos.equals(headPos.relative(pDir))
                              && this.inRange(candidateRPos)
                              && (mc.level.getBlockState(candidateRPos).isAir() || mc.level.getBlockState(candidateRPos).canBeReplaced())
                              && (air || PistonHelper.canPlace(candidateRPos, null, false, true))) {
                              this.supportPos = null;
                              this.pistonPos = pPos;
                              this.redstonePos = candidateRPos;
                              this.pushDir = pDir;
                              return true;
                           }
                        }
                     }
                  }

                  BlockPos underPiston;
                  if (!air && isPPosAir && this.inRange(underPiston = pPos.below())) {
                     if (!isLeverMode) {
                        if (PistonHelper.canPlace(underPiston, null, false, true) || this.isPowerSource(underPiston)) {
                           this.supportPositions.clear();
                           this.supportPos = null;
                           this.pistonPos = pPos;
                           this.redstonePos = underPiston;
                           this.pushDir = pDir;
                           return true;
                        }
                     } else if (PistonHelper.canPlace(underPiston, null, false, true) || this.isSolidBlock(underPiston)) {
                        ArrayList<PistonKickModule.LeverCandidate> bCandidates = new ArrayList<>();
                        BlockPos backPosx = pPos.relative(pDir.getOpposite());
                        BlockPos backSupportx = backPosx.below();
                        ArrayList<BlockPos> backSupportsx = new ArrayList<>();
                        if (!this.isSolidBlock(underPiston)) {
                           backSupportsx.add(underPiston);
                        }

                        if (!this.isSolidBlock(backSupportx)) {
                           backSupportsx.add(backSupportx);
                        }

                        bCandidates.add(new PistonKickModule.LeverCandidate(backPosx, backSupportsx));
                        BlockPos leftPosx = pPos.relative(pDir.getCounterClockWise());
                        BlockPos leftSupportx = leftPosx.below();
                        ArrayList<BlockPos> leftSupportsx = new ArrayList<>();
                        if (!this.isSolidBlock(underPiston)) {
                           leftSupportsx.add(underPiston);
                        }

                        if (!this.isSolidBlock(leftSupportx)) {
                           leftSupportsx.add(leftSupportx);
                        }

                        bCandidates.add(new PistonKickModule.LeverCandidate(leftPosx, leftSupportsx));
                        BlockPos rightPosx = pPos.relative(pDir.getClockWise());
                        BlockPos rightSupportx = rightPosx.below();
                        ArrayList<BlockPos> rightSupportsx = new ArrayList<>();
                        if (!this.isSolidBlock(underPiston)) {
                           rightSupportsx.add(underPiston);
                        }

                        if (!this.isSolidBlock(rightSupportx)) {
                           rightSupportsx.add(rightSupportx);
                        }

                        bCandidates.add(new PistonKickModule.LeverCandidate(rightPosx, rightSupportsx));

                        for (PistonKickModule.LeverCandidate candidatex : bCandidates) {
                           BlockPos candidateRPos = candidatex.leverPos;
                           if (!candidateRPos.equals(pPos.relative(pDir))
                              && !candidateRPos.equals(headPos)
                              && !candidateRPos.equals(headPos.below())
                              && !candidateRPos.equals(phasedPos.relative(pDir))
                              && !candidateRPos.equals(headPos.relative(pDir))
                              && this.inRange(candidateRPos)) {
                              boolean leverPlaceable = this.isLever(candidateRPos)
                                 || mc.level.getBlockState(candidateRPos).isAir()
                                 || mc.level.getBlockState(candidateRPos).canBeReplaced();
                              if (leverPlaceable) {
                                 boolean supportsValid = true;

                                 for (BlockPos s : candidatex.neededSupports) {
                                    if (!s.equals(headPos)
                                       && !s.equals(headPos.below())
                                       && !s.equals(phasedPos.relative(pDir))
                                       && !s.equals(headPos.relative(pDir))) {
                                       if (this.inRange(s) && (this.isSolidBlock(s) || PistonHelper.canPlace(s, null, false, true))) {
                                          continue;
                                       }

                                       supportsValid = false;
                                       break;
                                    }

                                    supportsValid = false;
                                    break;
                                 }

                                 if (supportsValid) {
                                    this.supportPositions.clear();
                                    this.supportPositions.addAll(candidatex.neededSupports);
                                    this.supportPos = candidatex.neededSupports.isEmpty() ? null : candidatex.neededSupports.get(0);
                                    this.pistonPos = pPos;
                                    this.redstonePos = candidateRPos;
                                    this.pushDir = pDir;
                                    return true;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private BlockPos findBestPowerPos(BlockPos pPos, BlockPos headPos, BlockPos destFeet, Direction pDir) {
      BlockPos best = null;
      double bestDist = Double.MAX_VALUE;
      boolean air = this.airPlace.getValue();

      for (Direction d : new Direction[]{Direction.DOWN, pDir.getOpposite(), pDir.getClockWise(), pDir.getCounterClockWise(), Direction.UP}) {
         BlockPos pos = pPos.relative(d);
         if (!pos.equals(headPos) && !pos.equals(headPos.below()) && !pos.equals(destFeet) && !pos.equals(destFeet.above()) && !pos.equals(pPos.relative(pDir))
            )
          {
            if (this.isPowerSource(pos)) {
               return pos;
            }

            double dist;
            if (PistonHelper.canPlace(pos, null, air, true) && this.inRange(pos) && (dist = mc.player.distanceToSqr(Vec3.atCenterOf(pos))) < bestDist) {
               bestDist = dist;
               best = pos;
            }
         }
      }

      return best;
   }

   private void placeBlock(int slot, BlockPos pos, Direction pistonPushDir) {
      if (slot != -1 && mc.player != null) {
         Direction side = this.strictDirection.getValue() ? WorldUtils.getDirection(pos, true) : PistonHelper.getPlaceSide(pos, d -> true);
         if (side == null) {
            if (!this.airPlace.getValue()) {
               return;
            }

            if (this.power.getValue().equalsIgnoreCase("Lever")
               && this.pistonPos != null
               && this.pushDir != null
               && pos.equals(this.pistonPos.relative(this.pushDir.getOpposite()))) {
               side = this.pushDir;
            } else {
               side = PistonHelper.getClickSide(pos);
               if (side == null) {
                  side = Direction.UP;
               }
            }
         }

         int prevSlot = mc.player.getInventory().getSelectedSlot();
         this.doSwap(slot, prevSlot);
         if (this.shouldRotate()) {
            this.doRotate(pos, side);
            if (pistonPushDir != null) {
               this.snapPistonFacing(pistonPushDir);
            }
         }

         PistonHelper.placeBlock(pos, side, false);
         this.restoreSlot(slot, prevSlot);
         if (this.render.getValue()) {
            Night.RENDER_MANAGER.getRenderPositions().removeIf(p -> p.getPos().equals(pos));
            Night.RENDER_MANAGER.getRenderPositions().add(new RenderPosition(pos));
         }
      }
   }

   private void snapPistonFacing(Direction pushDir) {
      float yaw = switch (pushDir) {
         case SOUTH -> 180.0F;
         case NORTH -> 0.0F;
         case EAST -> 90.0F;
         case WEST -> -90.0F;
         default -> 0.0F;
      };
      Night.ROTATION_MANAGER.silentRotate(yaw, 0.0F);
   }

   private boolean isPistonPlacedAndFacing(BlockPos pos, Direction pushDir) {
      if (mc.level == null) {
         return false;
      } else {
         BlockState state = mc.level.getBlockState(pos);
         return state.getBlock() instanceof PistonBaseBlock ? state.getValue(PistonBaseBlock.FACING) == pushDir : false;
      }
   }

   private boolean isPistonExtended(BlockPos pos) {
      if (mc.level == null) {
         return false;
      } else {
         BlockState state = mc.level.getBlockState(pos);
         return state.getBlock() instanceof PistonBaseBlock ? (Boolean)state.getValue(PistonBaseBlock.EXTENDED) : false;
      }
   }

   private boolean isPistonPowered(BlockPos pPos) {
      if (mc.level == null) {
         return false;
      } else if (this.power.getValue().equalsIgnoreCase("Lever")) {
         for (Direction d : Direction.values()) {
            BlockPos check = pPos.relative(d);
            if (this.isLever(check) && this.isLeverPowered(check)) {
               return true;
            }
         }

         return mc.level.hasNeighborSignal(pPos);
      } else {
         for (Direction dx : Direction.values()) {
            if (this.isRedstone(pPos.relative(dx))) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean isPowerSource(BlockPos pos) {
      if (mc.level != null && pos != null) {
         Block b = mc.level.getBlockState(pos).getBlock();
         return this.power.getValue().equalsIgnoreCase("Lever") ? b == Blocks.LEVER : b == Blocks.REDSTONE_BLOCK || b == Blocks.REDSTONE_TORCH;
      } else {
         return false;
      }
   }

   private boolean isRedstone(BlockPos pos) {
      if (mc.level == null) {
         return false;
      } else {
         Block b = mc.level.getBlockState(pos).getBlock();
         return b == Blocks.REDSTONE_BLOCK || b == Blocks.REDSTONE_TORCH;
      }
   }

   private boolean isLever(BlockPos pos) {
      return mc.level != null && pos != null ? mc.level.getBlockState(pos).getBlock() == Blocks.LEVER : false;
   }

   private boolean isLeverPowered(BlockPos pos) {
      if (mc.level != null && pos != null) {
         BlockState state = mc.level.getBlockState(pos);
         return state.getBlock() == Blocks.LEVER ? (Boolean)state.getValue(LeverBlock.POWERED) : false;
      } else {
         return false;
      }
   }

   private void clickLever(BlockPos pos) {
      if (mc.player != null && mc.level != null) {
         Direction clickFace = PistonHelper.getClickSide(pos);
         if (clickFace == null) {
            clickFace = Direction.UP;
         }

         PistonHelper.clickBlock(pos, clickFace, this.shouldRotate());
      }
   }

   private boolean isDestinationOpen(BlockPos phasedPos, Direction pDir) {
      if (mc.level == null) {
         return false;
      } else {
         BlockPos destFeet = phasedPos.relative(pDir);
         BlockPos destHead = destFeet.above();
         BlockState feet = mc.level.getBlockState(destFeet);
         BlockState head = mc.level.getBlockState(destHead);
         return feet.isAir() || feet.canBeReplaced() && !feet.blocksMotion() && !this.isImmovable(feet)
            ? head.isAir() || head.canBeReplaced() && !head.blocksMotion() && !this.isImmovable(head)
            : false;
      }
   }

   private boolean isImmovable(BlockState state) {
      Block b = state.getBlock();
      return b == Blocks.OBSIDIAN
         || b == Blocks.BEDROCK
         || b == Blocks.CRYING_OBSIDIAN
         || b == Blocks.RESPAWN_ANCHOR
         || b == Blocks.ENDER_CHEST
         || state.isSolid();
   }

   public List<BlockPos> getPhasedSolidBlocks(Player target) {
      ArrayList<BlockPos> solidPhased = new ArrayList<>();
      if (target != null && mc.level != null) {
         for (BlockPos pos : EntityUtils.getPhasedBlocks(target)) {
            BlockState state = mc.level.getBlockState(pos);
            if (this.isHardPhasedBlock(state)) {
               solidPhased.add(pos);
            }
         }

         if (solidPhased.isEmpty()) {
            BlockPos feetPos = BlockPos.containing(target.getX(), target.getY() + 0.1, target.getZ());
            if (this.isHardPhasedBlock(mc.level.getBlockState(feetPos))) {
               solidPhased.add(feetPos);
            } else {
               BlockPos blockPos = target.blockPosition();
               if (this.isHardPhasedBlock(mc.level.getBlockState(blockPos))) {
                  solidPhased.add(blockPos);
               } else {
                  BlockPos torsoPos = feetPos.above();
                  if (this.isHardPhasedBlock(mc.level.getBlockState(torsoPos))) {
                     solidPhased.add(torsoPos);
                  }
               }
            }
         }

         return solidPhased;
      } else {
         return solidPhased;
      }
   }

   public BlockPos getPhasedSolidBlock(Player target) {
      List<BlockPos> list = this.getPhasedSolidBlocks(target);
      return list.isEmpty() ? null : list.get(0);
   }

   private boolean isDecoyOrPassableBlock(BlockState state) {
      if (state != null && !state.isAir() && !state.canBeReplaced()) {
         Block b = state.getBlock();
         return b instanceof WebBlock
            || b instanceof ButtonBlock
            || b instanceof MushroomBlock
            || b instanceof LadderBlock
            || b instanceof ScaffoldingBlock
            || b instanceof FlowerBlock
            || b instanceof FlowerPotBlock
            || b instanceof TallFlowerBlock
            || b instanceof VineBlock
            || b instanceof TorchBlock
            || b instanceof LeverBlock
            || b instanceof PressurePlateBlock
            || b instanceof SignBlock
            || b instanceof BannerBlock
            || b instanceof CarpetBlock
            || b instanceof TripWireBlock
            || b instanceof TripWireHookBlock
            || b instanceof BaseRailBlock
            || b == Blocks.COBWEB
            || b == Blocks.LADDER
            || b == Blocks.SCAFFOLDING
            || b == Blocks.VINE
            || b == Blocks.BROWN_MUSHROOM
            || b == Blocks.RED_MUSHROOM
            || b == Blocks.TORCH
            || b == Blocks.SOUL_TORCH
            || b == Blocks.REDSTONE_TORCH;
      } else {
         return true;
      }
   }

   private boolean isHardPhasedBlock(BlockState state) {
      if (this.isDecoyOrPassableBlock(state)) {
         return false;
      } else {
         Block b = state.getBlock();
         return b != Blocks.OBSIDIAN
               && b != Blocks.BEDROCK
               && b != Blocks.ENDER_CHEST
               && b != Blocks.RESPAWN_ANCHOR
               && b != Blocks.CRYING_OBSIDIAN
               && b != Blocks.ANVIL
               && b != Blocks.CHIPPED_ANVIL
               && b != Blocks.DAMAGED_ANVIL
               && b != Blocks.REINFORCED_DEEPSLATE
               && b != Blocks.NETHERITE_BLOCK
               && b != Blocks.ANCIENT_DEBRIS
            ? state.isSolid() && state.blocksMotion()
            : true;
      }
   }

   private boolean inRange(BlockPos pos) {
      double r = this.placeRange.getValue().floatValue();
      return mc.player.distanceToSqr(Vec3.atCenterOf(pos)) <= r * r;
   }

   private void breakNearbyCrystals(Player target) {
      double r = this.breakRange.getValue().floatValue();
      AABB box = target.getBoundingBox().inflate(r);
      mc.level
         .getEntitiesOfClass(EndCrystal.class, box, e -> e.isAlive() && mc.player.distanceToSqr(e) <= r * r)
         .stream()
         .min(Comparator.comparingDouble(e -> mc.player.distanceToSqr(e)))
         .ifPresent(crystal -> {
            float selfDmg = DamageUtils.getCrystalDamage(mc.player, null, crystal, false);
            if (!(selfDmg > this.maxLocalDamage.getValue().floatValue())) {
               if (!this.safety.getValue() || !(selfDmg >= mc.player.getHealth() + mc.player.getAbsorptionAmount())) {
                  mc.getConnection().send(new ServerboundAttackPacket(crystal.getId()));
                  mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               }
            }
         });
   }

   private boolean shouldRotate() {
      return !this.rotate.getValue().equalsIgnoreCase("None");
   }

   private void doRotate(BlockPos pos, Direction side) {
      Vec3 hitVec = Vec3.atCenterOf(pos).add(side.getStepX() * 0.5, side.getStepY() * 0.5, side.getStepZ() * 0.5);
      float[] rots = RotationUtils.getRotations(hitVec);
      Night.ROTATION_MANAGER.silentRotate(rots[0], rots[1]);
   }

   private void doSwap(int slot, int previousSlot) {
      InventoryUtils.switchSlot(this.swapAction.getValue(), slot, previousSlot);
   }

   private void restoreSlot(int slot, int previousSlot) {
      InventoryUtils.switchBack(this.swapAction.getValue(), slot, previousSlot);
   }

   private int findPower() {
      if (this.power.getValue().equalsIgnoreCase("Lever")) {
         return this.findBlock(Blocks.LEVER);
      } else {
         int slot = this.findBlock(Blocks.REDSTONE_BLOCK);
         return slot != -1 ? slot : this.findBlock(Blocks.REDSTONE_TORCH);
      }
   }

   private int findSupportBlock() {
      int slot = this.findBlock(Blocks.OBSIDIAN);
      if (slot != -1) {
         return slot;
      } else {
         slot = this.findBlock(Blocks.CRYING_OBSIDIAN);
         if (slot != -1) {
            return slot;
         } else {
            slot = this.findBlock(Blocks.ENDER_CHEST);
            if (slot != -1) {
               return slot;
            } else {
               slot = this.findBlock(Blocks.NETHERITE_BLOCK);
               if (slot != -1) {
                  return slot;
               } else {
                  slot = this.findBlock(Blocks.COBBLESTONE);
                  return slot != -1 ? slot : this.findPower();
               }
            }
         }
      }
   }

   private boolean isSolidBlock(BlockPos pos) {
      if (mc.level != null && pos != null) {
         BlockState state = mc.level.getBlockState(pos);
         return !state.isAir() && !state.canBeReplaced() && state.isSolid();
      } else {
         return false;
      }
   }

   private int findPiston() {
      int slot = this.findBlock(Blocks.PISTON);
      return slot != -1 ? slot : this.findBlock(Blocks.STICKY_PISTON);
   }

   private int findBlock(Block block) {
      if (this.swapAction.getValue().equalsIgnoreCase("None")) {
         ItemStack held = mc.player.getMainHandItem();
         BlockItem bi;
         Item item;
         return !held.isEmpty() && (item = held.getItem()) instanceof BlockItem && (bi = (BlockItem)item).getBlock() == block
            ? mc.player.getInventory().getSelectedSlot()
            : -1;
      } else {
         int end = !this.swapAction.getValue().equalsIgnoreCase("AltSwap") && !this.swapAction.getValue().equalsIgnoreCase("AltPickup")
            ? InventoryUtils.HOTBAR_END
            : InventoryUtils.INVENTORY_END;

         for (int i = 0; i <= end; i++) {
            ItemStack s = mc.player.getInventory().getItem(i);
            BlockItem bi;
            Item item;
            if (!s.isEmpty() && (item = s.getItem()) instanceof BlockItem && (bi = (BlockItem)item).getBlock() == block) {
               return i;
            }
         }

         return -1;
      }
   }

   private List<Player> getEnemies() {
      double r = this.targetRange.getValue().floatValue();
      return mc.level
         .players()
         .stream()
         .filter(p -> p != mc.player)
         .filter(p -> !EntityUtils.isGhost(p))
         .filter(p -> !p.isSpectator() && p.isAlive())
         .filter(p -> !Night.FRIEND_MANAGER.contains(p.getName().getString()))
         .filter(p -> mc.player.distanceToSqr(p) <= r * r)
         .sorted(Comparator.comparingDouble(p -> mc.player.distanceToSqr(p)))
         .collect(Collectors.toList());
   }

   private record LeverCandidate(BlockPos leverPos, List<BlockPos> neededSupports) {
   }
}
