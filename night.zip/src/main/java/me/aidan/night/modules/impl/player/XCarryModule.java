package night.modules.impl.player;

import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import night.events.SubscribeEvent;
import night.events.impl.PacketSendEvent;
import night.modules.Module;
import night.modules.RegisterModule;

@RegisterModule(
   name = "XCarry",
   description = "Allows you to carry items in your crafting slots.",
   category = Module.Category.PLAYER
)
public class XCarryModule extends Module {
   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      if (mc.player != null) {
         if (event.getPacket() instanceof ServerboundContainerClosePacket) {
            event.setCancelled(true);
         }
      }
   }

   @Override
   public void onDisable() {
      if (mc.player != null) {
         mc.getConnection().send(new ServerboundContainerClosePacket(mc.player.inventoryMenu.containerId));
      }
   }
}
