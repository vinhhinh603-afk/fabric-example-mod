package night.modules.impl.miscellaneous;

import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.BreakBlockEvent;
import night.events.impl.ChatInputEvent;
import night.events.impl.ConsumeItemEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.StringSetting;
import night.utils.system.MathUtils;
import night.utils.system.Timer;

@RegisterModule(
   name = "Announcer",
   description = "Announces your actions in chat.",
   category = Module.Category.MISCELLANEOUS
)
public class AnnouncerModule extends Module {
   public StringSetting watermark = new StringSetting("Watermark", "The client name that will be used in the announcer.", "xnhau");
   public ModeSetting language = new ModeSetting(
      "Language",
      "The language that will be used for the announcer.",
      "English",
      new String[]{
         "English",
         "German",
         "French",
         "Japanese",
         "Finnish",
         "Russian",
         "Spanish",
         "Swedish",
         "Turkish",
         "Dutch",
         "Greek",
         "Chinese",
         "Italian",
         "Norwegian",
         "Romanian",
         "Czech",
         "Portuguese",
         "Slovenian",
         "Polish",
         "Korean",
         "Lithuanian",
         "Indonesian",
         "Hungarian",
         "Random"
      }
   );
   public NumberSetting delay = new NumberSetting("Delay", "The delay for the announcer.", 5, 0, 30);
   public BooleanSetting clientside = new BooleanSetting("Clientside", "Sends the messages only on your side.", false);
   public BooleanSetting greenText = new BooleanSetting("GreenText", "Makes your message green.", false);
   public BooleanSetting distance = new BooleanSetting("Distance", "Announces your distance travelled in chat.", true);
   public BooleanSetting blocksMined = new BooleanSetting("BlocksMined", "Announces blocks mined in chat.", true);
   public BooleanSetting blocksPlaced = new BooleanSetting("BlocksPlaced", "Announces blocks placed in chat.", true);
   public BooleanSetting eating = new BooleanSetting("Eating", "Announces when you eat in chat.", true);
   private final ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
   private final Timer messageTimer = new Timer();
   private final Timer distanceTimer = new Timer();
   private Vec3 lastPos;
   private int mined;
   private int placed;
   private int eaten;

   @Override
   public void onEnable() {
      this.queue.clear();
      this.messageTimer.reset();
      this.distanceTimer.reset();
      this.lastPos = null;
      this.mined = 0;
      this.placed = 0;
      this.eaten = 0;
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (!this.getNull()) {
         if (this.messageTimer.hasTimeElapsed(this.delay.getValue().intValue() * 1000) && !this.queue.isEmpty()) {
            String message = this.queue.poll();
            if (this.clientside.getValue()) {
               Night.CHAT_MANAGER.message(message);
            } else {
               mc.player.connection.sendChat((this.greenText.getValue() ? "> " : "") + message);
            }

            this.messageTimer.reset();
         }

         if (this.lastPos == null) {
            this.lastPos = new Vec3(mc.player.xo, mc.player.yo, mc.player.zo);
         }

         double traveled = Math.abs(this.lastPos.x - mc.player.xo) + Math.abs(this.lastPos.y - mc.player.yo) + Math.abs(this.lastPos.z - mc.player.zo);
         if (this.distance.getValue() && traveled > 1.0 && this.distanceTimer.hasTimeElapsed(10000) && this.queue.size() <= 5) {
            this.queue.add(this.getDistanceMessage(MathUtils.round(traveled, 1) + ""));
            this.lastPos = new Vec3(mc.player.xo, mc.player.yo, mc.player.zo);
            this.distanceTimer.reset();
         }
      }
   }

   @SubscribeEvent
   public void onBreakBlock(BreakBlockEvent event) {
      if (!this.getNull()) {
         this.mined++;
         if (this.blocksMined.getValue() && this.mined >= MathUtils.random(6.0, 1.0) && this.queue.size() <= 5) {
            this.queue.add(this.getMineMessage(this.mined + ""));
            this.mined = 0;
         }
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      if (!this.getNull()) {
         Packet<?> packet2 = event.getPacket();
         ServerboundUseItemOnPacket packet;
         if (packet2 instanceof ServerboundUseItemOnPacket
            && mc.player.getItemInHand((packet = (ServerboundUseItemOnPacket)packet2).getHand()).getItem() instanceof BlockItem) {
            this.placed++;
            if (this.blocksPlaced.getValue() && this.placed >= MathUtils.random(6.0, 1.0) && this.queue.size() <= 5) {
               this.queue.add(this.getPlaceMessage(this.placed + ""));
               this.placed = 0;
            }
         }
      }
   }

   @SubscribeEvent
   public void onConsumeItem(ConsumeItemEvent event) {
      if (!this.getNull() && event.getStack().get(DataComponents.FOOD) != null) {
         this.eaten++;
         if (this.eating.getValue() && this.eaten >= MathUtils.random(6.0, 1.0) && this.queue.size() <= 5) {
            this.queue.add(this.getEatMessage(this.eaten + " " + event.getStack().getHoverName().getString()));
            this.eaten = 0;
         }
      }
   }

   @SubscribeEvent
   public void onChatInput(ChatInputEvent event) {
      if (!this.getNull()) {
         this.messageTimer.reset();
      }
   }

   private String getDistanceMessage(String replacement) {
      String[] messages = new String[]{
         "I just flew " + replacement + " meters thanks to " + this.watermark.getValue() + "!",
         "Ich bin gerade " + replacement + " Meter weit geflogen, dank " + this.watermark.getValue() + "!",
         "Je viens de voler " + replacement + " mètres grâce à " + this.watermark.getValue() + "!",
         this.watermark.getValue() + "のおかげで" + replacement + "メートル飛んだよ！",
         "Lensin juuri " + replacement + " metriä " + this.watermark.getValue() + " ansiosta!",
         "Я только что пролетел " + replacement + " метров благодаря " + this.watermark.getValue() + "!",
         "Acabo de volar " + replacement + " metros gracias a " + this.watermark.getValue() + "!",
         "Jag flög just " + replacement + " meter tack vare " + this.watermark.getValue() + "!",
         this.watermark.getValue() + " sayesinde " + replacement + " metre uçtum!",
         "Ik heb net " + replacement + " meter gevlogen dankzij " + this.watermark.getValue() + "!",
         "Μόλις πέταξα " + replacement + " μέτρα χάρη στην " + this.watermark.getValue() + "!",
         "我刚刚飞了" + replacement + "米，多亏了" + this.watermark.getValue() + "!",
         "Ho appena volato per " + replacement + " metri grazie ad " + this.watermark.getValue() + "!",
         "Jeg fløy nettopp " + replacement + " meter takket være " + this.watermark.getValue() + "!",
         "Tocmai am zburat " + replacement + " de metri datorită lui " + this.watermark.getValue() + "!",
         "Díky " + this.watermark.getValue() + " jsem právě uletěl " + replacement + " metrů!",
         "Acabei de voar " + replacement + " metros graças ao " + this.watermark.getValue() + "!",
         "Z " + this.watermark.getValue() + " sem pravkar preletel " + replacement + " metrov!",
         "Właśnie przeleciałem " + replacement + " metrów dzięki " + this.watermark.getValue() + "!",
         this.watermark.getValue() + " 덕분에 방금 " + replacement + "를 비행했습니다!",
         this.watermark.getValue() + " dėka ką tik nuskridau " + replacement + " metrus!",
         "Saya baru saja terbang sejauh " + replacement + " meter berkat " + this.watermark.getValue() + "!",
         replacement + " métert repültem az " + this.watermark.getValue() + " köszönhetően!"
      };
      return messages[this.getLanguageIndex()];
   }

   private String getMineMessage(String replacement) {
      String[] messages = new String[]{
         "I just mined " + replacement + " blocks thanks to " + this.watermark.getValue() + "!",
         "Ich habe gerade " + replacement + " Blöcke abgebaut, dank " + this.watermark.getValue() + "!",
         "Je viens d'extraire " + replacement + " blocs grâce à " + this.watermark.getValue() + "!",
         this.watermark.getValue() + "のおかげで" + replacement + "ブロック採掘したところです！",
         "Louhin juuri " + replacement + " lohkoa " + this.watermark.getValue() + " ansiosta!",
         "Я только что добыл " + replacement + " блоков благодаря " + this.watermark.getValue() + "!",
         "¡Acabo de minar " + replacement + " bloques gracias a " + this.watermark.getValue() + "!",
         "Jag har precis tagit fram " + replacement + " block tack vare " + this.watermark.getValue() + "!",
         this.watermark.getValue() + " sayesinde az önce " + replacement + " blok kazdım!",
         "Ik heb net " + replacement + " blokken gedolven dankzij " + this.watermark.getValue() + "!",
         "Μόλις εξόρυξα " + replacement + " μπλοκ χάρη στην " + this.watermark.getValue() + "!",
         "我刚刚开采了" + replacement + "个区块，感谢" + this.watermark.getValue() + "!",
         "Ho appena estratto " + replacement + " blocchi grazie ad " + this.watermark.getValue() + "!",
         "Jeg har nettopp utvunnet " + replacement + " blokker takket være " + this.watermark.getValue() + "!",
         "Tocmai am minat " + replacement + " de blocuri datorită lui " + this.watermark.getValue() + "!",
         "Právě jsem vytěžil " + replacement + " bloků díky " + this.watermark.getValue() + "!",
         "Acabei de extrair " + replacement + " blocos graças ao " + this.watermark.getValue() + "!",
         "Zahvaljujoč " + this.watermark.getValue() + " sem pravkar izkopal " + replacement + " blokov!",
         "Właśnie wydobyłem " + replacement + " bloków dzięki " + this.watermark.getValue() + "!",
         "방금 " + this.watermark.getValue() + " 덕분에 " + replacement + " 블록을 채굴했습니다!",
         this.watermark.getValue() + " dėka ką tik iškasiau " + replacement + " blokus!",
         "Saya baru saja menambang " + replacement + " blok berkat " + this.watermark.getValue() + "!",
         "Most bányásztam " + replacement + " blokkot az " + this.watermark.getValue() + " köszönhetően!"
      };
      return messages[this.getLanguageIndex()];
   }

   private String getPlaceMessage(String replacement) {
      String[] messages = new String[]{
         "I just placed " + replacement + " blocks thanks to " + this.watermark.getValue() + "!",
         "Ich habe gerade " + replacement + " Blöcke dank " + this.watermark.getValue() + " platziert!",
         "Je viens de placer " + replacement + " blocs grâce à " + this.watermark.getValue() + "!",
         this.watermark.getValue() + "のおかげで" + replacement + "個のブロックを置いたところだ!",
         "Sijoitin juuri " + replacement + " lohkoa " + this.watermark.getValue() + " ansiosta!",
         "Я только что разместил " + replacement + " блоков благодаря " + this.watermark.getValue() + "!",
         "¡Acabo de colocar " + replacement + " bloques gracias a " + this.watermark.getValue() + "!",
         "Jag har precis placerat " + replacement + " block tack vare " + this.watermark.getValue() + "!",
         "Az önce " + this.watermark.getValue() + " sayesinde " + replacement + " blok yerleştirdim!",
         "Ik heb net " + replacement + " blokken geplaatst dankzij " + this.watermark.getValue() + "!",
         "Μόλις τοποθέτησα " + replacement + " μπλοκ χάρη στο " + this.watermark.getValue() + "!",
         "多亏了 " + this.watermark.getValue() + "，我刚刚放了 " + replacement + " 块!",
         "Ho appena piazzato " + replacement + " blocchi grazie a " + this.watermark.getValue() + "!",
         "Jeg har nettopp plassert " + replacement + " blokker takket være " + this.watermark.getValue() + "!",
         "Tocmai am plasat " + replacement + " blocuri datorită lui " + this.watermark.getValue() + "!",
         "Právě jsem umístil " + replacement + " bloků díky " + this.watermark.getValue() + "!",
         "Acabei de colocar " + replacement + " blocos graças ao " + this.watermark.getValue() + "!",
         "Pravkar sem postavil " + replacement + " blokov zahvaljujoč " + this.watermark.getValue() + "!",
         "Właśnie umieściłem " + replacement + " bloków dzięki " + this.watermark.getValue() + "!",
         this.watermark.getValue() + " 덕분에 방금 XXX 블록을 배치했습니다!",
         "Ką tik įdėjau " + replacement + " blokų dėka " + this.watermark.getValue() + "!",
         "Saya baru saja menempatkan blok " + replacement + " berkat " + this.watermark.getValue() + "!",
         "Most helyeztem el " + replacement + " blokkot a " + this.watermark.getValue() + "-nek köszönhetően!"
      };
      return messages[this.getLanguageIndex()];
   }

   private String getEatMessage(String replacement) {
      String[] messages = new String[]{
         "I just ate " + replacement + " thanks to " + this.watermark.getValue() + "!",
         "Ich habe gerade " + replacement + " gegessen, dank " + this.watermark.getValue() + "!",
         "Je viens de manger " + replacement + " grâce à " + this.watermark.getValue() + " !",
         this.watermark.getValue() + "のおかげで" + replacement + "を食べたよ!",
         "Söin juuri " + replacement + " kiitos " + this.watermark.getValue() + "!",
         "Я только что съел " + replacement + " благодаря " + this.watermark.getValue() + "!",
         "¡Acabo de comer " + replacement + " gracias a " + this.watermark.getValue() + "!",
         "Jag åt just " + replacement + " tack vare " + this.watermark.getValue() + "!",
         "Az önce " + this.watermark.getValue() + " sayesinde " + replacement + " yedim!",
         "Ik heb net " + replacement + " gegeten dankzij " + this.watermark.getValue() + "!",
         "Μόλις έφαγα " + replacement + " χάρη στο " + this.watermark.getValue() + "!",
         "我刚吃了 " + replacement + "，多亏了 " + this.watermark.getValue() + "!",
         "Ho appena mangiato " + replacement + " grazie a " + this.watermark.getValue() + "!",
         "Jeg spiste nettopp " + replacement + " takket være " + this.watermark.getValue() + "!",
         "Právě jsem snědl " + replacement + " díky " + this.watermark.getValue() + "!",
         "Acabei de comer " + replacement + " graças a " + this.watermark.getValue() + "!",
         "Pravkar sem pojedel " + replacement + " zaradi " + this.watermark.getValue() + "!",
         "Właśnie zjadłem " + replacement + " dzięki " + this.watermark.getValue() + "!",
         "방금 " + this.watermark.getValue() + " 덕분에 " + replacement + "를 먹었어요!",
         "Ką tik suvalgiau " + replacement + " dėl " + this.watermark.getValue() + "!",
         "Saya baru saja makan " + replacement + " berkat " + this.watermark.getValue() + "!",
         "Most ettem " + replacement + "-t, hála " + this.watermark.getValue() + "-nek!"
      };
      return messages[this.getLanguageIndex()];
   }

   private int getLanguageIndex() {
      String var1 = this.language.getValue();

      return switch (var1) {
         case "German" -> 1;
         case "French" -> 2;
         case "Japanese" -> 3;
         case "Finnish" -> 4;
         case "Russian" -> 5;
         case "Spanish" -> 6;
         case "Swedish" -> 7;
         case "Turkish" -> 8;
         case "Dutch" -> 9;
         case "Greek" -> 10;
         case "Chinese" -> 11;
         case "Italian" -> 12;
         case "Norwegian" -> 13;
         case "Romanian" -> 14;
         case "Czech" -> 15;
         case "Portuguese" -> 16;
         case "Slovenian" -> 17;
         case "Polish" -> 18;
         case "Korean" -> 19;
         case "Lithuanian" -> 20;
         case "Indonesian" -> 21;
         case "Hungarian" -> 22;
         case "Random" -> (int)MathUtils.random(22.0, 0.0);
         default -> 0;
      };
   }
}
