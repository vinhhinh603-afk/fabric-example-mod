package night.modules.impl.combat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundBlockDestructionPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PlayerJumpEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.IMinecraft;
import night.utils.minecraft.HoleUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.NetworkUtils;
import night.utils.minecraft.WorldUtils;
import night.utils.miscellaneous.RenderPosition;
import night.utils.rotations.RotationUtils;

public class FeetTrapModule extends Module {
   public ModeSetting autoSwitch = new ModeSetting(
      "Switch", "The mode that will be used for automatically switching to necessary items.", "Silent", InventoryUtils.SWITCH_MODES
   );
   public NumberSetting limit = new NumberSetting("Limit", "The number of blocks that can be placed per tick.", 4, 1, 20);
   public NumberSetting delay = new NumberSetting("Delay", "The amount of ticks waited between each group of placements.", 0, 0, 20);
   public NumberSetting range = new NumberSetting("Range", "The maximum range at which the blocks will be placed at.", 5.0, 0.0, 12.0);
   public BooleanSetting extension = new BooleanSetting("Extension", "Extends the trap if there are entities obstructing block placement.", false);
   public BooleanSetting floor = new BooleanSetting("Floor", "Places blocks under your feet as well.", true);
   public BooleanSetting corners = new BooleanSetting("Corners", "Also covers the four diagonals at feet level.", false);
   public BooleanSetting jumpDisable = new BooleanSetting("JumpDisable", "Toggles off the module whenever you leave the ground.", false);
   public ModeSetting rotate = new ModeSetting("Rotate", "The rotation mode when placing blocks.", "Grim", new String[]{"None", "Normal", "Grim"});
   public BooleanSetting strictDirection = new BooleanSetting("StrictDirection", "Only places using directions that face you.", true);
   public BooleanSetting airPlace = new BooleanSetting(
      "AirPlace", "Places blocks in the air using the block below as support, facing UP, when no direct neighbor is available.", false
   );
   public BooleanSetting grim = new BooleanSetting(
      "Grim",
      "AirPlace only: places from the offhand via a swap-and-swapback trick instead of the mainhand.",
      new BooleanSetting.Visibility(this.airPlace, true),
      false
   );
   public BooleanSetting multiTask = new BooleanSetting("MultiTask", "Allows placing while an item is already in use (eating, blocking, drawing a bow).", false);
   public BooleanSetting swing = new BooleanSetting("Swing", "Sends a swing packet whenever placing a block.", true);
   public BooleanSetting antiBreak = new BooleanSetting(
      "AntiBreak", "Pre-places extra blocks around a spot an enemy is actively digging through toward your trap.", false
   );
   public BooleanSetting selfDisable = new BooleanSetting("SelfDisable", "Toggles off the module once it is finished with placing.", false);
   public BooleanSetting render = new BooleanSetting("Render", "Whether or not to render the place position.", true);
   public BooleanSetting attack = new BooleanSetting("Attack", "Attacks any crystal that lands on one of your trap positions.", false);
   public BooleanSetting attackRotate = new BooleanSetting(
      "AttackRotate", "Rotate", "Rotates toward the crystal before attacking it.", new BooleanSetting.Visibility(this.attack, true), true
   );
   public NumberSetting attackRange = new NumberSetting(
      "AttackRange", "Range", "The maximum range at which crystals will be attacked.", new BooleanSetting.Visibility(this.attack, true), 3.0F, 1.0F, 6.0F
   );
   public NumberSetting attackAge = new NumberSetting(
      "AttackAge", "Age", "The minimum age (in ticks) a crystal must reach before being attacked.", new BooleanSetting.Visibility(this.attack, true), 5, 0, 20
   );
   public BooleanSetting attackMultiTask = new BooleanSetting(
      "AttackMultiTask", "Multitask", "Allows attacking while an item is already in use.", new BooleanSetting.Visibility(this.attack, true), true
   );
   public BooleanSetting attackSwing = new BooleanSetting(
      "AttackSwing", "Swing", "Sends a swing packet whenever attacking a crystal.", new BooleanSetting.Visibility(this.attack, true), true
   );
   private int ticks = 0;
   private int targetCount = 0;
   private Set<BlockPos> targetPositions = new LinkedHashSet<>();
   private final Map<Integer, FeetTrapModule.BreakState> breakStates = new HashMap<>();

   private float getMiningSpeed(BlockState state, Player player) {
      ItemStack stack = new ItemStack(Items.NETHERITE_PICKAXE);
      float speed = stack.getDestroySpeed(state);
      if (speed > 1.0F) {
         int level = 5;
         speed += level * level + 1;
      }

      if (!player.onGround()) {
         speed /= 5.0F;
      }

      return speed;
   }

   @Override
   public String getMetaData() {
      return String.valueOf(this.targetCount);
   }

   @Override
   public void onDisable() {
      this.ticks = 0;
      this.targetCount = 0;
      this.targetPositions.clear();
      this.breakStates.clear();
   }

   @SubscribeEvent
   public void onPlayerJump(PlayerJumpEvent event) {
      if (this.jumpDisable.getValue()) {
         this.setToggled(false);
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (this.antiBreak.getValue() && mc.level != null) {
         if (event.getPacket() instanceof ClientboundBlockDestructionPacket packet2) {
            if (mc.level.getEntity(packet2.getId()) instanceof Player) {
               this.breakStates.computeIfAbsent(packet2.getId(), x$0 -> new FeetTrapModule.BreakState(this, x$0)).startBreak(packet2.getPos(), 0.7F);
            }
         }
      }
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.jumpDisable.getValue() && !mc.player.onGround()) {
            this.setToggled(false);
         } else if (this.ticks < this.delay.getValue().intValue()) {
            this.ticks++;
         } else {
            BlockItem blockItem;
            Item item;
            if (!this.autoSwitch.getValue().equalsIgnoreCase("None")
               || (item = mc.player.getMainHandItem().getItem()) instanceof BlockItem && this.isBlastProof((blockItem = (BlockItem)item).getBlock())) {
               int slot = this.findBlastProofBlock();
               int previousSlot = mc.player.getInventory().getSelectedSlot();
               if (slot == -1) {
                  Night.CHAT_MANAGER.tagged("No blast-proof blocks could be found in your hotbar.", this.getName());
                  this.setToggled(false);
               } else {
                  this.targetPositions = this.getTargets();
                  if (this.antiBreak.getValue()) {
                     this.applyAntiBreak();
                  }

                  List<BlockPos> positions = this.targetPositions
                     .stream()
                     .filter(position -> mc.player.distanceToSqr(Vec3.atCenterOf(position)) <= Mth.square(this.range.getValue().doubleValue()))
                     .filter(WorldUtils::isPlaceable)
                     .toList();
                  this.targetCount = positions.size();
                  if (this.attack.getValue()) {
                     this.attackTrapCrystals();
                  }

                  if (positions.isEmpty()) {
                     if (this.selfDisable.getValue()) {
                        this.setToggled(false);
                     }
                  } else if (this.multiTask.getValue() || !mc.player.isUsingItem()) {
                     Night.ROTATION_MANAGER.beginBatchRotation();

                     try {
                        InventoryUtils.switchSlot(this.autoSwitch.getValue(), slot, previousSlot);
                        int placed = 0;
                        ArrayList<BlockPos> placedPositions = new ArrayList<>();

                        for (BlockPos position2 : positions) {
                           if (placed >= this.limit.getValue().intValue()) {
                              break;
                           }

                           Direction direction = WorldUtils.getDirection(position2, placedPositions, this.strictDirection.getValue());
                           if (direction == null) {
                              if (this.airPlace.getValue()) {
                                 this.placeAir(position2);
                                 placedPositions.add(position2);
                                 placed++;
                              }
                           } else if (WorldUtils.placeBlock(
                              position2, direction, InteractionHand.MAIN_HAND, this.rotate.getValue(), true, this.render.getValue()
                           )) {
                              placedPositions.add(position2);
                              placed++;
                           }
                        }

                        InventoryUtils.switchBack(this.autoSwitch.getValue(), slot, previousSlot);
                     } finally {
                        Night.ROTATION_MANAGER.endBatchRotation();
                     }

                     this.ticks = 0;
                  }
               }
            } else {
               Night.CHAT_MANAGER.tagged("You are currently not holding any blast-proof blocks.", this.getName());
               this.setToggled(false);
            }
         }
      }
   }

   private void placeAir(BlockPos position) {
      if (!this.grim.getValue()) {
         WorldUtils.airPlaceBlock(position, InteractionHand.MAIN_HAND, this.rotate.getValue(), this.render.getValue());
      } else {
         Vec3 hitVec = Vec3.atCenterOf(position).add(0.0, 0.5, 0.0);
         if (!this.rotate.getValue().equalsIgnoreCase("None")) {
            float[] rotations = RotationUtils.getRotations(hitVec);
            if (Night.ROTATION_MANAGER.isBatchingRotations()) {
               Night.ROTATION_MANAGER.batchRotate(rotations[0], rotations[1]);
            } else {
               Night.ROTATION_MANAGER.silentRotate(rotations[0], rotations[1]);
            }
         }

         RenderPosition renderPosition;
         if (this.render.getValue() && !Night.RENDER_MANAGER.renderPositions.contains(renderPosition = new RenderPosition(position))) {
            Night.RENDER_MANAGER.renderPositions.add(renderPosition);
         }

         BlockHitResult hitResult = new BlockHitResult(hitVec, Direction.UP, position, false);
         mc.getConnection().send(new ServerboundPlayerActionPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
         NetworkUtils.sendSequencedPacket(sequence -> new ServerboundUseItemOnPacket(InteractionHand.OFF_HAND, hitResult, sequence));
         if (this.swing.getValue()) {
            mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.OFF_HAND));
         }

         mc.getConnection().send(new ServerboundPlayerActionPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
      }
   }

   private void attackTrapCrystals() {
      Night.ROTATION_MANAGER.beginBatchRotation();

      for (EndCrystal crystal : mc.level
         .getEntitiesOfClass(EndCrystal.class, new AABB(mc.player.blockPosition()).inflate(this.range.getValue().doubleValue() + 3.0))) {
         if (crystal.isAlive() && !crystal.isRemoved() && crystal.tickCount >= this.attackAge.getValue().intValue()) {
            AABB crystalBox = crystal.getBoundingBox();
            boolean threatens = false;

            for (BlockPos pos : this.targetPositions) {
               if (mc.level.getBlockState(pos).canBeReplaced() && new AABB(pos).intersects(crystalBox)) {
                  threatens = true;
                  break;
               }
            }

            if (threatens
               && !(crystalBox.distanceToSqr(mc.player.getEyePosition()) > Mth.square(this.attackRange.getValue().doubleValue()))
               && (this.attackMultiTask.getValue() || !mc.player.isUsingItem())) {
               if (this.attackRotate.getValue()) {
                  float[] rotations = RotationUtils.getRotations(crystal.getBoundingBox().getCenter());
                  Night.ROTATION_MANAGER.silentRotate(rotations[0], rotations[1]);
                  boolean insideBox = crystalBox.contains(mc.player.getEyePosition());
                  if (!insideBox && !WorldUtils.canSee(crystal.getBoundingBox().getCenter())) {
                     continue;
                  }
               }

               mc.getConnection().send(new ServerboundAttackPacket(crystal.getId()));
               if (this.attackSwing.getValue()) {
                  mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               }
            }
         }
      }

      Night.ROTATION_MANAGER.endBatchRotation();
   }

   private void applyAntiBreak() {
      for (FeetTrapModule.BreakState state : this.breakStates.values()) {
         state.onTick();
      }

      if (this.antiBreak.getValue() && !this.targetPositions.isEmpty()) {
         ArrayList<BlockPos> extraTargets = new ArrayList<>();

         for (BlockPos pos : this.targetPositions) {
            boolean breaking = false;

            for (FeetTrapModule.BreakState state : this.breakStates.values()) {
               if (state.isBreaking(pos)) {
                  breaking = true;
                  break;
               }
            }

            if (breaking) {
               for (Direction dir : Direction.values()) {
                  BlockPos around;
                  if (dir != Direction.DOWN
                     && !this.targetPositions.contains(around = pos.relative(dir))
                     && !extraTargets.contains(around)
                     && mc.level.getBlockState(around).canBeReplaced()
                     && !this.isEntityBlocking(around)) {
                     extraTargets.add(around);
                  }
               }
            }
         }

         this.targetPositions.addAll(extraTargets);
      }
   }

   private boolean isEntityBlocking(BlockPos pos) {
      AABB blockBox = new AABB(pos);

      for (Entity entity : mc.level.entitiesForRendering()) {
         if (!(entity.distanceToSqr(mc.player) > 10.0)
            && !(entity instanceof EndCrystal)
            && !(entity instanceof ItemEntity)
            && !(entity instanceof Arrow)
            && entity.getBoundingBox().intersects(blockBox)) {
            return true;
         }
      }

      return false;
   }

   private Set<BlockPos> getTargets() {
      LinkedHashSet<BlockPos> positions = new LinkedHashSet<>(HoleUtils.getFeetPositions(mc.player, this.extension.getValue(), this.floor.getValue(), false));
      if (!this.corners.getValue()) {
         return positions;
      } else {
         AABB box = mc.player.getBoundingBox();
         int y = Mth.floor(mc.player.getY());

         for (int x = Mth.floor(box.minX); x < Math.ceil(box.maxX); x++) {
            for (int z = Mth.floor(box.minZ); z < Math.ceil(box.maxZ); z++) {
               BlockPos base = new BlockPos(x, y, z);

               for (BlockPos corner : new BlockPos[]{base.north().east(), base.north().west(), base.south().east(), base.south().west()}) {
                  if (!this.isEntityBlocking(corner)) {
                     positions.add(corner);
                  }
               }
            }
         }

         return positions;
      }
   }

   private int findBlastProofBlock() {
      float bestHardness = -1.0F;
      int bestSlot = -1;

      for (int i = 0; i <= 8; i++) {
         Item item2 = mc.player.getInventory().getItem(i).getItem();
         BlockItem item;
         Block block;
         if (item2 instanceof BlockItem && this.isBlastProof(block = (item = (BlockItem)item2).getBlock())) {
            float hardness = block.defaultDestroyTime();
            if (hardness == -1.0F) {
               return i;
            }

            if (hardness > bestHardness) {
               bestHardness = hardness;
               bestSlot = i;
            }
         }
      }

      return bestSlot;
   }

   private boolean isBlastProof(Block block) {
      return block == Blocks.OBSIDIAN
         || block == Blocks.ENDER_CHEST
         || block == Blocks.CRYING_OBSIDIAN
         || block == Blocks.NETHERITE_BLOCK
         || block == Blocks.RESPAWN_ANCHOR
         || block == Blocks.ANCIENT_DEBRIS
         || block == Blocks.ENCHANTING_TABLE
         || block == Blocks.ANVIL
         || block == Blocks.CHIPPED_ANVIL
         || block == Blocks.DAMAGED_ANVIL;
   }

   private class BreakState {
      final int entityId;
      final FeetTrapModule.BreakTask current;
      final FeetTrapModule.BreakTask doubleMine;
      final FeetTrapModule this$0;

      BreakState(FeetTrapModule feetTrapModule, int entityId) {
         Objects.requireNonNull(FeetTrapModule.this);
         super();
         Objects.requireNonNull(feetTrapModule);
         this.this$0 = feetTrapModule;
         this.current = new FeetTrapModule.BreakTask();
         this.doubleMine = new FeetTrapModule.BreakTask();
         this.entityId = entityId;
      }

      void startBreak(BlockPos pos, float speed) {
         if (this.current.active && !this.current.pos.equals(pos)) {
            if (!this.doubleMine.active) {
               this.doubleMine.copyFrom(this.current);
               this.doubleMine.targetSpeed = 1.0F;
            }

            this.current.reset();
         }

         if (!this.current.active || !this.current.pos.equals(pos)) {
            this.current.start(pos, speed);
         }
      }

      void onTick() {
         this.tickTask(this.current);
         this.tickTask(this.doubleMine);
      }

      private void tickTask(FeetTrapModule.BreakTask task) {
         if (task.active) {
            if (!(IMinecraft.mc.level.getEntity(this.entityId) instanceof Player player)) {
               task.reset();
            } else {
               BlockState state = IMinecraft.mc.level.getBlockState(task.pos);
               if (state.isAir()) {
                  task.active = false;
               } else {
                  float hardness = state.getDestroySpeed(IMinecraft.mc.level, task.pos);
                  if (hardness != -1.0F) {
                     float speed = this.this$0.getMiningSpeed(state, player);
                     task.progress += speed / hardness / 30.0F;
                     if (task.progress >= task.targetSpeed) {
                        task.active = false;
                     }
                  }
               }
            }
         }
      }

      boolean isBreaking(BlockPos pos) {
         return this.current.pos != null && this.current.pos.equals(pos) && this.current.active
            ? true
            : this.doubleMine.pos != null && this.doubleMine.pos.equals(pos) && this.doubleMine.active;
      }
   }

   private static class BreakTask {
      BlockPos pos;
      float targetSpeed;
      float progress;
      boolean active;

      void start(BlockPos pos, float speed) {
         this.pos = pos;
         this.targetSpeed = speed;
         this.progress = 0.0F;
         this.active = true;
      }

      void copyFrom(FeetTrapModule.BreakTask other) {
         this.pos = other.pos;
         this.targetSpeed = other.targetSpeed;
         this.progress = other.progress;
         this.active = other.active;
      }

      void reset() {
         this.active = false;
         this.progress = 0.0F;
      }
   }
}
