package night.modules.impl.player;

import com.mojang.blaze3d.vertex.PoseStack;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.IntFunction;
import java.util.function.Predicate;
import lombok.Generated;
import net.minecraft.client.multiplayer.prediction.BlockStatePredictionHandler;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Plane;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.AttackBlockEvent;
import night.events.impl.ClientDisconnectEvent;
import night.events.impl.DestroyBlockEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.PlayerUpdateEvent;
import night.events.impl.RenderWorldEvent;
import night.mixins.accessors.ClientWorldAccessor;
import night.mixins.accessors.PlayerMoveC2SPacketAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.combat.AutoCrystalModule;
import night.modules.impl.combat.AutoMineModule;
import night.modules.impl.combat.AutoTrapModule;
import night.modules.impl.visuals.LogoutSpotModule;
import night.modules.impl.visuals.PopChamsModule;
import night.pingbypass.PingBypassFlags;
import night.pingbypass.protocol.PbCustomPayload;
import night.pingbypass.protocol.packets.S2CMiningStatePacket;
import night.pingbypass.server.ProxyServerTickListener;
import night.settings.impl.BooleanSetting;
import night.settings.impl.CategorySetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.WhitelistSetting;
import night.utils.IMinecraft;
import night.utils.color.ColorUtils;
import night.utils.graphics.Renderer3D;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.HoleUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.NetworkUtils;
import night.utils.minecraft.WorldUtils;
import night.utils.rotations.RotationUtils;
import night.utils.system.Timer;

@RegisterModule(
   name = "SpeedMine",
   description = "Automatically mines blocks at a faster speed using packets.",
   category = Module.Category.PLAYER
)
public class SpeedMineModule extends Module {
   public ModeSetting switchMode = new ModeSetting(
      "Switch", "The mode that will be used for automatically switching to the fastest item.", "Silent", InventoryUtils.SWITCH_MODES
   );
   public NumberSetting range = new NumberSetting("Range", "The maximum distance at which blocks will be mined.", 6.0, 0.0, 8.0);
   public NumberSetting speed = new NumberSetting("Speed", "The speed at which the module will mine blocks.", 1.0, 0.7, 1.0);
   public BooleanSetting farReach = new BooleanSetting("FarReach", "Bypass for Duration 0.7 on Grim. Try this if normal AutoMine doesn't work.", false);
   public BooleanSetting sixB = new BooleanSetting("6b", "Allows mining bedrock after 40 ticks and enables instant-mining when broken.", false);
   public ModeSetting rotate = new ModeSetting(
      "Rotate", "Automatically rotates to the block when mining it.", "Normal", new String[]{"None", "Normal", "Silent"}
   );
   public BooleanSetting switchReset = new BooleanSetting(
      "SwitchReset", "Resets the mining when switching slots.", new ModeSetting.Visibility(this.switchMode, "None", "AltSwap", "AltPickup"), true
   );
   public BooleanSetting doubleMine = new BooleanSetting("Double", "Allows the mining of 2 blocks at the same time.", false);
   public BooleanSetting shift = new BooleanSetting(
      "Shift",
      "Selects the block behind according to crosshair as secondary when clicking while holding shift.",
      new BooleanSetting.Visibility(this.doubleMine, true),
      true
   );
   public ModeSetting await = new ModeSetting(
      "Await",
      "Wait for blocks to break before swapping back. Off: don't wait. Dynamic: wait only while the secondary isn't close to done yet. Always: always wait. Works around real NCP's FastBreak check on some Paper servers (cancels doubleMine's secondary otherwise) -- costs mining throughput while waiting.",
      new BooleanSetting.Visibility(this.doubleMine, true),
      "Off",
      new String[]{"Off", "Dynamic", "Always"}
   );
   public ModeSetting rebreak = new ModeSetting(
      "Rebreak", "Automatically re-mines blocks once they have been replaced.", "None", new String[]{"None", "Fast", "Instant"}
   );
   public NumberSetting instantDelay = new NumberSetting(
      "InstantDelay",
      "The amount of time that has to pass before instantly mining blocks.",
      new ModeSetting.Visibility(this.rebreak, "Fast", "Instant"),
      0,
      0,
      20
   );
   public NumberSetting instantTimeout = new NumberSetting(
      "InstantTimeout",
      "The amount of time that cancel instantly mine while no block to mine.",
      new ModeSetting.Visibility(this.rebreak, "Fast", "Instant"),
      60,
      0,
      100
   );
   public BooleanSetting async = new BooleanSetting(
      "Async",
      "Keeps instantly re-firing even while the target position is currently air, instead of waiting for it to solidify.",
      new ModeSetting.Visibility(this.rebreak, "Fast", "Instant"),
      false
   );
   public CategorySetting onGroundCheckCategory = new CategorySetting(
      "OnGroundCheck", "Claims onGround on outgoing movement packets while mining, bypassing the not-on-the-ground mining speed penalty."
   );
   public BooleanSetting ncpCheck = new BooleanSetting(
      "NCP",
      "Enables the onGround claim below. Turn off for servers that don't penalize air/liquid mining.",
      new CategorySetting.Visibility(this.onGroundCheckCategory),
      false
   );
   public BooleanSetting airCheck = new BooleanSetting(
      "AirCheck", "Claims onGround while airborne and mining.", new CategorySetting.Visibility(this.onGroundCheckCategory), false
   );
   public BooleanSetting liquidCheck = new BooleanSetting(
      "LiquidCheck", "Claims onGround while in liquid and mining.", new CategorySetting.Visibility(this.onGroundCheckCategory), false
   );
   public BooleanSetting grim = new BooleanSetting("Grim", "Adds a bypass catered to the Grim anticheat.", false);
   public BooleanSetting whileEating = new BooleanSetting("WhileEating", "Mines blocks while eating.", true);
   public ModeSetting whitelistMode = new ModeSetting(
      "Mode",
      "All = mine every block. WhiteList = mine only listed blocks. BlackList = mine every block except listed.",
      "All",
      new String[]{"All", "WhiteList", "BlackList"}
   );
   public WhitelistSetting whitelist = new WhitelistSetting("List", "Blocks the WhiteList/BlackList mode compares against.", WhitelistSetting.Type.BLOCKS);
   public CategorySetting renderCategory = new CategorySetting("Render", "The category containing all settings related to rendering.");
   public ModeSetting render = new ModeSetting(
      "Render",
      "Mode",
      "The rendering that will be applied to the blocks highlighted.",
      new CategorySetting.Visibility(this.renderCategory),
      "Both",
      new String[]{"None", "Fill", "Outline", "Both"}
   );
   public ModeSetting animation = new ModeSetting(
      "Animation",
      "The animation that will be used when rendering the block mining progress.",
      new ModeSetting.Visibility(this.render, "Fill", "Outline", "Both"),
      "Expand",
      new String[]{"None", "Expand", "Rise"}
   );
   public ModeSetting color = new ModeSetting(
      "Color",
      "The color that will be used when rendering the block mining.",
      new ModeSetting.Visibility(this.render, "Fill", "Outline", "Both"),
      "Smooth",
      new String[]{"Static", "Smooth", "Custom"}
   );
   public ColorSetting fillColor = new ColorSetting(
      "FillColor", "The color used for the fill rendering.", new ModeSetting.Visibility(this.render, "Fill", "Both"), ColorUtils.getDefaultFillColor()
   );
   public ColorSetting outlineColor = new ColorSetting(
      "OutlineColor",
      "The color used for the outline rendering.",
      new ModeSetting.Visibility(this.render, "Outline", "Both"),
      ColorUtils.getDefaultOutlineColor()
   );
   public ModeSetting instantRender = new ModeSetting(
      "InstantRender",
      "Instant",
      "The color that will be used for rendering instantly mined blocks.",
      new CategorySetting.Visibility(this.renderCategory),
      "None",
      new String[]{"None", "Default", "Custom"}
   );
   public ColorSetting instantColor = new ColorSetting(
      "InstantColor",
      "The custom color used for instantly mined blocks.",
      new ModeSetting.Visibility(this.instantRender, "Custom"),
      new ColorSetting.Color(new Color(148, 0, 211), false, false)
   );
   private SpeedMineModule.Action primary = null;
   private SpeedMineModule.Secondary secondary = null;
   private static final int SECONDARY_TIMEOUT = 10;
   private int secondaryHoldSlot = -1;
   private int secondaryOriginalSlot = -1;
   private static final int SECONDARY_MAX_TICKS = 60;
   private boolean doubleEngaged = false;
   private boolean primaryPaired = false;
   private boolean handlingSwitchReset = false;
   private final Timer instantTimer = new Timer();
   private static final long INSTANT_ACK_STALL_MS = 200L;
   private final Timer mineTimer = new Timer();
   private double delayBalance = 0.0;
   private long lastStopMs = 0L;
   private static final int STOP_COOLDOWN_TICKS = 6;
   private int stopCooldown = 0;
   private volatile boolean interactPaused = false;
   private volatile long interactPausedAt = 0L;
   private boolean needsRestart = false;
   public final Object interactSyncLock = new Object();
   private static final long INTERACT_PAUSE_TIMEOUT_MS = 750L;
   public volatile BlockPos proxyPrimaryPos = null;
   public volatile float proxyPrimaryProgress = 0.0F;
   public volatile BlockPos proxySecondaryPos = null;
   public volatile float proxySecondaryProgress = 0.0F;
   private volatile float prevProxyPrimaryProgress = 0.0F;
   private volatile long proxyPrimaryUpdateTime = 0L;
   private volatile long proxyPrimaryUpdateInterval = 50L;
   private volatile float prevProxySecondaryProgress = 0.0F;
   private volatile long proxySecondaryUpdateTime = 0L;
   private volatile long proxySecondaryUpdateInterval = 50L;
   private static final int GRIM_DECOY_Y_OFFSET = 2000;

   public SpeedMineModule.Action getPrimary() {
      return this.primary;
   }

   public SpeedMineModule.Secondary getSecondary() {
      return this.secondary;
   }

   public void setDoubleEngaged(boolean engaged) {
      this.doubleEngaged = engaged;
   }

   private boolean hasSecondarySlot() {
      return this.secondary != null;
   }

   private boolean canStartNow() {
      if (this.whileEating.getValue() || !this.interactPaused && (mc.player == null || !mc.player.isUsingItem() && !EntityUtils.isEating())) {
         return !this.farReach.getValue() ? true : this.stopCooldown == 0 && this.canBegin();
      } else {
         return false;
      }
   }

   private boolean canBegin() {
      long delay = System.currentTimeMillis() - this.lastStopMs;
      if (delay >= 275L) {
         return true;
      } else {
         double cost = (300L - delay) * (this.farReach.getValue() ? 2 : 1);
         return this.delayBalance + cost <= 900.0;
      }
   }

   private void trackStarts(int starts) {
      long delay = System.currentTimeMillis() - this.lastStopMs;

      for (int i = 0; i < starts; i++) {
         if (delay >= 275L) {
            this.delayBalance *= 0.9;
         } else {
            this.delayBalance += 300L - delay;
         }
      }

      this.delayBalance = Mth.clamp(this.delayBalance, -1000.0, 1000.0);
   }

   private void markStop() {
      this.markStop(false);
   }

   private void markStop(boolean cooldown) {
      this.lastStopMs = System.currentTimeMillis();
      if (cooldown) {
         this.stopCooldown = 6;
      }
   }

   public BlockPos getMiningPosition() {
      return this.primary != null && this.primary.isMining() ? this.primary.getPosition() : null;
   }

   public boolean isInteractPaused() {
      return this.interactPaused;
   }

   public void setInteractPaused(boolean paused) {
      this.interactPaused = paused;
      if (paused) {
         this.interactPausedAt = System.currentTimeMillis();
      } else {
         this.needsRestart = true;
      }
   }

   public void updateProxyMiningState(BlockPos primaryPos, float primaryProgress, BlockPos secondaryPos, float secondaryProgress) {
      long now = System.currentTimeMillis();
      boolean primaryPosChanged = primaryPos == null ? this.proxyPrimaryPos != null : !primaryPos.equals(this.proxyPrimaryPos);
      this.prevProxyPrimaryProgress = primaryPosChanged ? primaryProgress : this.proxyPrimaryProgress;
      this.proxyPrimaryUpdateInterval = Mth.clamp(now - this.proxyPrimaryUpdateTime, 1L, 500L);
      this.proxyPrimaryUpdateTime = now;
      this.proxyPrimaryPos = primaryPos;
      this.proxyPrimaryProgress = primaryProgress;
      boolean secondaryPosChanged = secondaryPos == null ? this.proxySecondaryPos != null : !secondaryPos.equals(this.proxySecondaryPos);
      this.prevProxySecondaryProgress = secondaryPosChanged ? secondaryProgress : this.proxySecondaryProgress;
      this.proxySecondaryUpdateInterval = Mth.clamp(now - this.proxySecondaryUpdateTime, 1L, 500L);
      this.proxySecondaryUpdateTime = now;
      this.proxySecondaryPos = secondaryPos;
      this.proxySecondaryProgress = secondaryProgress;
   }

   private float interpolatedProgress(float prev, float current, long updateTime, long interval) {
      float t = Mth.clamp((float)(System.currentTimeMillis() - updateTime) / (float)interval, 0.0F, 1.0F);
      return prev + (current - prev) * t;
   }

   public boolean handle(BlockPos position, int priority) {
      if (!this.canHandle(position)) {
         return false;
      } else if ((this.primary == null || !this.primary.getPosition().equals(position))
         && (this.secondary == null || !this.secondary.getPosition().equals(position))) {
         if (this.primary != null && priority <= 0 && this.sixB.getValue() && this.primary.isBedrockOrigin() && priority <= this.primary.getPriority()) {
            return false;
         } else {
            boolean dual = this.doubleMine.getValue() && (this.doubleEngaged || priority > 0);
            if (dual) {
               if (this.secondary != null) {
                  if (this.await.getValue().equalsIgnoreCase("Always")) {
                     return false;
                  }

                  if (this.await.getValue().equalsIgnoreCase("Dynamic") && !this.secondary.isHolding()) {
                     return false;
                  }
               }

               SpeedMineModule.Secondary demoted = this.secondary == null && this.primary != null ? this.primary.demote() : null;
               if (demoted != null) {
                  this.secondary = demoted;
               } else if (this.primary != null) {
                  this.primary.cancel();
               }

               this.primary = new SpeedMineModule.Action(this, position, priority);
               this.primaryPaired = this.hasSecondarySlot();
            } else {
               if (this.primary != null) {
                  this.primary.cancel();
               }

               this.primary = new SpeedMineModule.Action(this, position, priority);
               this.primaryPaired = false;
            }

            return true;
         }
      } else {
         return true;
      }
   }

   public boolean fillSecondary(BlockPos position, int priority) {
      if (this.primary != null && this.primary.isTerrainBase()) {
         return false;
      } else if (!this.canHandle(position)) {
         return false;
      } else if (this.sixB.getValue() && mc.level.getBlockState(position).getBlock() == Blocks.BEDROCK) {
         return false;
      } else if (this.secondary != null) {
         return this.secondary.getPosition().equals(position);
      } else if (this.primary != null && this.primary.getPosition().equals(position)) {
         return true;
      } else {
         SpeedMineModule.Action fresh = new SpeedMineModule.Action(this, position, priority);
         SpeedMineModule.Secondary demoted = fresh.demote();
         if (demoted == null) {
            return false;
         } else {
            this.secondary = demoted;
            return true;
         }
      }
   }

   public boolean isMineTimerReady() {
      return this.mineTimer.hasTimeElapsed(50L);
   }

   public void dropPrimaryIfInvalid(Predicate<BlockPos> stillValid) {
      if (this.primary != null && this.primary.getPriority() == 0) {
         if (!stillValid.test(this.primary.getPosition())) {
            this.dropPrimary();
         }
      }
   }

   public void dropSecondaryIfInvalid(Predicate<BlockPos> stillValid) {
      if (this.secondary != null && this.secondary.getPriority() == 0) {
         if (!stillValid.test(this.secondary.getPosition())) {
            this.dropSecondary();
         }
      }
   }

   public void dropPrimary() {
      if (this.primary != null) {
         this.primary.cancel();
         this.primary = null;
         this.primaryPaired = false;
      }
   }

   public void dropSecondary() {
      if (this.secondary != null) {
         this.secondary.release();
         this.secondary = null;
      }
   }

   public boolean primaryDigging() {
      return this.primary != null && !mc.level.getBlockState(this.primary.getPosition()).canBeReplaced();
   }

   public boolean primaryCamping() {
      if (this.primary != null && this.primary.isInstantMine()) {
         if (!mc.level.getBlockState(this.primary.getPosition()).canBeReplaced() && !this.sixB.getValue()) {
            return false;
         } else {
            SpeedMineModule.Target t = this.getTarget();
            return t != null && this.isTargetSurroundPosition(this.primary.getPosition(), t.player());
         }
      } else {
         return false;
      }
   }

   public boolean slotsFull() {
      return this.primary != null && this.sixB.getValue() && this.primary.isBedrockOrigin()
         ? true
         : (this.primaryDigging() || this.primaryCamping()) && (!this.doubleEngaged || this.hasSecondarySlot() || this.primaryPaired);
   }

   public boolean phaseSlotsFull() {
      return this.primaryDigging() && (!this.doubleEngaged || this.hasSecondarySlot() || this.primaryPaired);
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (!this.isDeferringToProxy()) {
         if (mc.player != null && mc.level != null) {
            if (this.stopCooldown > 0) {
               this.stopCooldown--;
            }

            if (!this.doubleMine.getValue()) {
               this.doubleEngaged = false;
            }

            if (this.secondary != null && !this.doubleMine.getValue()) {
               this.secondary.release();
               this.secondary = null;
            } else if (this.secondary != null && this.secondary.process()) {
               this.secondary = null;
            }

            if (this.primary != null && this.primary.process()) {
               this.primary = null;
               this.primaryPaired = false;
            }

            if (this.isProxyActive()) {
               this.syncMiningStateToClient();
            }

            AutoMineModule autoMine = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoMineModule.class) : null;
            if (autoMine != null) {
               autoMine.placePendingTerrain();
            }

            if (this.primary != null && autoMine != null && autoMine.isProtectedTerrainBase(this.primary.getPosition())) {
               this.primary.cancel();
               this.primary = null;
               this.primaryPaired = false;
            }
         }
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.isDeferringToProxy()) {
            this.renderProxyState(event.getMatrices());
         } else {
            if (this.doubleMine.getValue() && this.secondary != null) {
               this.secondary.render(event.getMatrices());
            }

            if (this.primary != null) {
               this.primary.render(event.getMatrices());
            }
         }
      }
   }

   @SubscribeEvent
   public void night$onBlockUpdate(PacketReceiveEvent event) {
      if (mc.player != null && mc.level != null) {
         if (event.getPacket() instanceof ClientboundBlockUpdatePacket blockPacket) {
            BlockPos pos = blockPacket.getPos();
            if (this.primary != null && pos.equals(this.primary.getPosition())) {
               this.primary.markBroken();
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent.Post event) {
      if (!this.isDeferringToProxy()) {
         if (mc.player != null && mc.level != null) {
            if (!this.handlingSwitchReset) {
               if (event.getPacket() instanceof ServerboundSetCarriedItemPacket
                  && this.switchReset.getValue()
                  && (this.switchMode.getValue().equalsIgnoreCase("AltSwap") || this.switchMode.getValue().equalsIgnoreCase("AltPickup"))) {
                  this.handlingSwitchReset = true;

                  try {
                     if (this.primary != null) {
                        this.primary.cancel();
                        this.primary.tryStart();
                     }
                  } finally {
                     this.handlingSwitchReset = false;
                  }
               }

               ServerboundPlayerActionPacket action;
               Packet<?> packet;
               if (!((packet = event.getPacket()) instanceof ServerboundPlayerActionPacket)
                  || (action = (ServerboundPlayerActionPacket)packet).getAction()
                     != net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK
                  || action.getPos().getY() <= 2000) {
                  if (event.getPacket() instanceof ServerboundMovePlayerPacket movePacket && this.ncpCheck.getValue() && this.primary != null) {
                     boolean airborne = this.airCheck.getValue() && !mc.player.onGround() && !mc.player.isInWater();
                     boolean liquid = this.liquidCheck.getValue() && mc.player.isInWater();
                     if (airborne || liquid) {
                        ((PlayerMoveC2SPacketAccessor)movePacket).setOnGround(true);
                     }
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onAttackBlock(AttackBlockEvent event) {
      if (!this.isDeferringToProxy()) {
         if (mc.player != null && mc.level != null) {
            BlockPos position = event.getPosition();
            if (this.doubleMine.getValue() && this.shift.getValue() && (mc.options.keyShift.isDown() || mc.player.isShiftKeyDown())) {
               Vec3 look = mc.player.getLookAngle();
               double absX = Math.abs(look.x);
               double absY = Math.abs(look.y);
               double absZ = Math.abs(look.z);
               Direction direction = absY > absX && absY > absZ
                  ? (look.y > 0.0 ? Direction.UP : Direction.DOWN)
                  : (absX > absZ ? (look.x > 0.0 ? Direction.EAST : Direction.WEST) : (look.z > 0.0 ? Direction.SOUTH : Direction.NORTH));
               BlockPos behind = position.relative(direction);
               if (this.isValid(behind) && !this.isOutOfRange(behind) && !mc.level.getBlockState(behind).canBeReplaced()) {
                  this.handle(behind, 1);
               }
            }

            if (this.handle(position, 1)) {
               event.setCancelled(true);
            }
         }
      }
   }

   @SubscribeEvent
   public void onClientDisconnect(ClientDisconnectEvent event) {
      this.primary = null;
      this.secondary = null;
      this.doubleEngaged = false;
      this.primaryPaired = false;
   }

   @Override
   public void onEnable() {
      this.doubleEngaged = false;
      this.primaryPaired = false;
   }

   @Override
   public void onDisable() {
      this.doubleEngaged = false;
      this.primaryPaired = false;
      if (!this.isDeferringToProxy()) {
         this.restoreIronSwap();
         if (mc.player != null && mc.level != null) {
            if (this.secondary != null) {
               this.secondary.release();
            }

            this.secondary = null;
            if (this.primary != null) {
               this.primary.cancel();
               this.primary = null;
            }

            this.setInteractPaused(false);
         } else {
            this.primary = null;
            this.secondary = null;
         }
      }
   }

   public void restoreIronSwap() {
      if (this.primary != null) {
         this.primary.restoreIronSwap();
      }

      int hotbarIron;
      if (mc.player != null && (hotbarIron = InventoryUtils.find(Items.IRON_PICKAXE, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END)) != -1) {
         int invSlot = InventoryUtils.findFastestItem(Blocks.OBSIDIAN.defaultBlockState(), InventoryUtils.HOTBAR_END + 1, InventoryUtils.INVENTORY_END);
         if (invSlot == -1) {
            invSlot = InventoryUtils.findEmptySlot(InventoryUtils.HOTBAR_END + 1, InventoryUtils.INVENTORY_END);
         }

         if (invSlot != -1 && invSlot > InventoryUtils.HOTBAR_END) {
            InventoryUtils.swap("Swap", invSlot, hotbarIron);
         }
      }
   }

   @Override
   public String getMetaData() {
      String primaryProgress = this.primary == null ? "0.0" : new DecimalFormat("0.0").format(this.primary.getProgress() / this.primary.getSpeed());
      String secondaryProgress = this.secondary != null && this.doubleMine.getValue()
         ? ", " + new DecimalFormat("0.0").format(this.secondary.getProgress() / this.secondary.getSpeed())
         : "";
      return primaryProgress + secondaryProgress;
   }

   private boolean canHandle(BlockPos position) {
      if (mc.gameMode.getPlayerMode() != GameType.CREATIVE && mc.gameMode.getPlayerMode() != GameType.SPECTATOR) {
         if (mc.level.getBlockState(position).getBlock().defaultDestroyTime() != -1.0F
            || this.sixB.getValue() && mc.level.getBlockState(position).getBlock() == Blocks.BEDROCK) {
            AutoMineModule autoMine = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoMineModule.class) : null;
            if (autoMine != null && autoMine.isProtectedTerrainBase(position)) {
               return false;
            } else {
               boolean listed = this.whitelist.isWhitelistContains(mc.level.getBlockState(position).getBlock());
               String var6 = this.whitelistMode.getValue();

               boolean allowedByList = switch (var6) {
                  case "WhiteList" -> listed;
                  case "BlackList" -> !listed;
                  default -> true;
               };
               return !allowedByList
                  ? false
                  : !(mc.player.getEyePosition().distanceToSqr(Vec3.atCenterOf(position)) > Mth.square(this.range.getValue().doubleValue()));
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean isInvalid(BlockPos position) {
      return !this.isValid(position) ? true : this.isMining(position);
   }

   public boolean isValid(BlockPos position) {
      if (position == null) {
         return false;
      } else {
         return mc.level.getBlockState(position).getBlock().defaultDestroyTime() != -1.0F
               || this.sixB.getValue() && mc.level.getBlockState(position).getBlock() == Blocks.BEDROCK
            ? !mc.level.getBlockState(position).getBlock().equals(Blocks.COBWEB)
            : false;
      }
   }

   public boolean isMining(BlockPos position) {
      if (position == null) {
         return true;
      } else {
         return this.primary != null && this.primary.getPosition().equals(position)
            ? true
            : this.secondary != null && this.secondary.getPosition().equals(position);
      }
   }

   public boolean isTargetSurroundPosition(BlockPos position, Player target) {
      if (position != null && target != null && mc.level != null) {
         AABB box = target.getBoundingBox();

         int yLegs;
         for (int y = yLegs = Mth.floor(target.getY()); y <= yLegs + 2; y++) {
            for (int x = Mth.floor(box.minX); x < Mth.ceil(box.maxX); x++) {
               for (int z = Mth.floor(box.minZ); z < Mth.ceil(box.maxZ); z++) {
                  BlockPos base = new BlockPos(x, y, z);
                  if (position.equals(base)) {
                     return true;
                  }

                  if (y <= yLegs + 1) {
                     for (Direction dir : Plane.HORIZONTAL) {
                        if (position.equals(base.relative(dir))) {
                           return true;
                        }
                     }
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean isOutOfRange(BlockPos position) {
      return position == null ? true : mc.player.getEyePosition().distanceToSqr(Vec3.atCenterOf(position)) > Mth.square(this.range.getValue().doubleValue());
   }

   public SpeedMineModule.Target getTarget() {
      LogoutSpotModule logoutSpot = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(LogoutSpotModule.class) : null;
      PopChamsModule popChams = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(PopChamsModule.class) : null;
      ArrayList<Player> allCandidates = new ArrayList<>(mc.level.players());
      if (logoutSpot != null && logoutSpot.isToggled()) {
         for (Player player : logoutSpot.getGhosts()) {
            if (player != null && !allCandidates.contains(player)) {
               allCandidates.add(player);
            }
         }
      }

      SpeedMineModule.Target optimalTarget = null;

      for (Player playerx : allCandidates) {
         LogoutSpotModule.Spot spot;
         boolean ghost;
         if (playerx != mc.player
            && (popChams == null || !popChams.isGhost(playerx))
            && ((ghost = EntityUtils.isGhost(playerx)) || playerx.isAlive() && !(playerx.getHealth() <= 0.0F))
            && !(mc.player.distanceToSqr(playerx) > Mth.square(this.range.getValue().doubleValue() + 2.0))
            && (
               logoutSpot != null && logoutSpot.isGhost(playerx)
                  ? (spot = logoutSpot.getSpot((RemotePlayer)playerx)) == null || !Night.FRIEND_MANAGER.contains(spot.data.name)
                  : !Night.FRIEND_MANAGER.contains(playerx.getName().getString())
            )) {
            List<SpeedMineModule.Position> feetPositions = this.getPositions(playerx);
            BlockPos position = this.getTargetPosition(feetPositions);
            if (this.doubleMine.getValue() || !feetPositions.isEmpty() && position != null) {
               if (optimalTarget == null) {
                  optimalTarget = new SpeedMineModule.Target(playerx, feetPositions, position);
               } else {
                  boolean bestIsGhost = EntityUtils.isGhost(optimalTarget.player());
                  if (bestIsGhost != ghost) {
                     if (bestIsGhost) {
                        optimalTarget = new SpeedMineModule.Target(playerx, feetPositions, position);
                     }
                  } else if (mc.player.distanceToSqr(playerx) < mc.player.distanceToSqr(optimalTarget.player())) {
                     optimalTarget = new SpeedMineModule.Target(playerx, feetPositions, position);
                  }
               }
            }
         }
      }

      return optimalTarget;
   }

   private BlockPos getTargetPosition(List<SpeedMineModule.Position> positions) {
      BlockPos optimalPosition = null;
      double optimalScore = 0.0;

      for (SpeedMineModule.Position position : positions) {
         if ((!this.doubleMine.getValue() || position.feetPosition())
            && this.isValidPosition(position.position())
            && (!HoleUtils.isPlayerInHole(mc.player) || !HoleUtils.getFeetPositions(mc.player, true, false, true).contains(position.position()))) {
            double score = 0.0;
            if (this.sixB.getValue() && mc.level.getBlockState(position.position()).getBlock() == Blocks.BEDROCK) {
               double var9;
               double var10;
               score = position.feetPosition() ? (var9 = score + 1000.0) : (var10 = score - 1000.0);
            }

            if (position.feetPosition()) {
               score += 5.0;
               if (mc.level.getBlockState(position.position()).getBlock() == Blocks.ENDER_CHEST) {
                  score += 0.95;
               } else if (WorldUtils.isCrystalPlaceable(position.position().offset(0, 1, 0))) {
                  score += 0.35;
               }

               if (this.hasCityPosition(position.position())) {
                  score += 0.6;
               }
            } else {
               double var12;
               double var13;
               double var14;
               score = mc.level.getBlockState(position.position()).getBlock() == Blocks.ENDER_CHEST
                  ? (var12 = score - 2.0)
                  : (WorldUtils.isCrystalPlaceable(position.position().offset(0, 1, 0)) ? (var13 = score + 0.75) : (var14 = score - 2.0));
            }

            if (score >= optimalScore) {
               optimalPosition = position.position();
               optimalScore = score;
            }
         }
      }

      return optimalPosition;
   }

   private List<SpeedMineModule.Position> getPositions(Player player) {
      ArrayList<SpeedMineModule.Position> positions = new ArrayList<>();

      for (BlockPos position : HoleUtils.getFeetPositions(player, true, false, true)) {
         positions.add(new SpeedMineModule.Position(position, true));
         if (!this.doubleMine.getValue()) {
            positions.add(new SpeedMineModule.Position(position.offset(0, 1, 0), false));
         }
      }

      if (!this.doubleMine.getValue()) {
         positions.add(new SpeedMineModule.Position(player.blockPosition().offset(0, 2, 0), false));
      }

      return positions;
   }

   private boolean isValidPosition(BlockPos position) {
      if (mc.level.getBlockState(position).canBeReplaced()) {
         return false;
      } else {
         return mc.level.getBlockState(position).getBlock().defaultDestroyTime() != -1.0F
               || this.sixB.getValue() && mc.level.getBlockState(position).getBlock() == Blocks.BEDROCK
            ? !this.isOutOfRange(position)
            : false;
      }
   }

   private boolean hasCityPosition(BlockPos position) {
      for (Direction dir : Plane.HORIZONTAL) {
         BlockPos offsetPosition = position.relative(dir);
         if (WorldUtils.isPlaceable(offsetPosition)) {
            return true;
         }
      }

      return false;
   }

   private boolean isProxyActive() {
      return PingBypassFlags.proxyForwardingActive && Night.PINGBYPASS_CONFIG != null && Night.PINGBYPASS_CONFIG.isServer() && Night.PROXY_SERVER != null;
   }

   private boolean isDeferringToProxy() {
      return PingBypassFlags.isPingBypassActive();
   }

   private void syncMiningStateToClient() {
      ClientboundCustomPayloadPacket packet = new ClientboundCustomPayloadPacket(
         PbCustomPayload.fromPacket(
            new S2CMiningStatePacket(
               this.primary != null ? this.primary.getPosition() : null,
               this.primary != null ? this.primary.getProgress() / this.primary.getSpeed() : 0.0F,
               this.secondary != null ? this.secondary.getPosition() : null,
               this.secondary != null ? this.secondary.getProgress() / this.secondary.getSpeed() : 0.0F
            )
         )
      );

      for (Connection conn : Night.PROXY_SERVER.getConnections()) {
         if (conn.isConnected()) {
            conn.send(packet);
         }
      }
   }

   private void renderProxyState(PoseStack matrices) {
      if (this.proxyPrimaryPos != null) {
         float progress = this.interpolatedProgress(
            this.prevProxyPrimaryProgress, this.proxyPrimaryProgress, this.proxyPrimaryUpdateTime, this.proxyPrimaryUpdateInterval
         );
         this.renderProxyBlock(matrices, this.proxyPrimaryPos, progress);
      }

      if (this.proxySecondaryPos != null && this.doubleMine.getValue()) {
         float progress = this.interpolatedProgress(
            this.prevProxySecondaryProgress, this.proxySecondaryProgress, this.proxySecondaryUpdateTime, this.proxySecondaryUpdateInterval
         );
         this.renderProxyBlock(matrices, this.proxySecondaryPos, progress);
      }
   }

   private void renderProxyBlock(PoseStack matrices, BlockPos pos, float progress) {
      if (!mc.level.getBlockState(pos).canBeReplaced()) {
         AABB box = new AABB(pos);
         if (this.animation.getValue().equalsIgnoreCase("Expand")) {
            box = new AABB(pos).deflate(0.5).inflate(Mth.clamp(progress / 2.0, 0.0, 0.5));
         }

         if (this.animation.getValue().equalsIgnoreCase("Rise")) {
            box = new AABB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1.0, pos.getY() + progress, pos.getZ() + 1.0);
         }

         Color fill = this.fillColor.getColor();
         Color outline = this.outlineColor.getColor();
         if (this.color.getValue().equalsIgnoreCase("Static")) {
            fill = progress >= 0.9 ? new Color(0, 255, 0, this.fillColor.getAlpha()) : new Color(255, 0, 0, this.fillColor.getAlpha());
            outline = progress >= 0.9 ? new Color(0, 255, 0, this.outlineColor.getAlpha()) : new Color(255, 0, 0, this.outlineColor.getAlpha());
         } else if (this.color.getValue().equalsIgnoreCase("Smooth")) {
            fill = new Color(
               255 - (int)(Mth.clamp(progress, 0.0F, 1.0F) * 255.0F), (int)(Mth.clamp(progress, 0.0F, 1.0F) * 255.0F), 0, this.fillColor.getAlpha()
            );
            outline = new Color(
               255 - (int)(Mth.clamp(progress, 0.0F, 1.0F) * 255.0F), (int)(Mth.clamp(progress, 0.0F, 1.0F) * 255.0F), 0, this.outlineColor.getAlpha()
            );
         }

         if (this.render.getValue().equalsIgnoreCase("Fill") || this.render.getValue().equalsIgnoreCase("Both")) {
            Renderer3D.renderBox(matrices, box, fill);
         }

         if (this.render.getValue().equalsIgnoreCase("Outline") || this.render.getValue().equalsIgnoreCase("Both")) {
            Renderer3D.renderBoxOutline(matrices, box, outline);
         }
      }
   }

   private void serverSend(Packet<?> packet) {
      Connection serverConn;
      if (this.isProxyActive() && (serverConn = Night.PROXY_SERVER.getServerConnection()) != null && serverConn.isConnected()) {
         ProxyServerTickListener.allowSend(() -> serverConn.send(packet));
      } else {
         mc.getConnection().send(packet);
      }
   }

   private <T extends Packet<?>> void serverSendSequenced(IntFunction<T> packetFactory) {
      if (this.isProxyActive()) {
         BlockStatePredictionHandler pending = ((ClientWorldAccessor)mc.level).invokeGetPendingUpdateManager().startPredicting();

         try {
            this.serverSend(packetFactory.apply(pending.currentSequence()));
         } catch (Throwable var6) {
            if (pending != null) {
               try {
                  pending.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (pending != null) {
            pending.close();
         }
      } else {
         NetworkUtils.sendSequencedPacket(seq -> packetFactory.apply(seq));
      }
   }

   private void sendRawPlayerAction(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action action, BlockPos target, Direction face) {
      this.sendRawPlayerAction(action, target, face, false);
   }

   private void sendRawPlayerAction(
      net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action action, BlockPos target, Direction face, boolean cooldown
   ) {
      if (action == net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK) {
         this.markStop(cooldown);
      }

      BlockStatePredictionHandler prediction = ((ClientWorldAccessor)mc.level).invokeGetPendingUpdateManager().startPredicting();

      try {
         this.serverSend(new ServerboundPlayerActionPacket(action, target, face, prediction.currentSequence()));
      } catch (Throwable var9) {
         if (prediction != null) {
            try {
               prediction.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (prediction != null) {
         prediction.close();
      }
   }

   public class Action {
      private final BlockPos position;
      private BlockState state;
      private final int priority;
      private float progress;
      private float prevProgress;
      private int attempts;
      private int ticks;
      private boolean mining;
      private long stallTime;
      private boolean instantMine;
      private int startSlot;
      private boolean started;
      private int brokenCount;
      private int lastBrokenCount;
      private final Timer instantRemineResetTimer;
      private float ghostIronProgress;
      private boolean ironSwapped;
      private int swappedIronInventorySlot;
      private int swappedIronHotbarSlot;
      private boolean terrainBase;
      private boolean terrainSurround;
      private final boolean bedrockOrigin;
      final SpeedMineModule this$0;

      public Action(SpeedMineModule this$0, BlockPos position, int priority) {
         Objects.requireNonNull(SpeedMineModule.this);
         super();
         Objects.requireNonNull(this$0);
         this.this$0 = this$0;
         this.startSlot = -1;
         this.lastBrokenCount = -1;
         this.instantRemineResetTimer = new Timer();
         this.ghostIronProgress = 0.0F;
         this.ironSwapped = false;
         this.swappedIronInventorySlot = -1;
         this.swappedIronHotbarSlot = -1;
         this.position = position;
         this.state = IMinecraft.mc.level.getBlockState(position);
         this.bedrockOrigin = this.state.getBlock() == Blocks.BEDROCK;
         this.priority = priority;
         this.tryStart();
      }

      public BlockPos getPosition() {
         return this.position;
      }

      public BlockState getState() {
         return this.state;
      }

      public float getProgress() {
         return this.progress;
      }

      public int getTicks() {
         return this.ticks;
      }

      public boolean isMining() {
         return this.mining;
      }

      public boolean isInstantMine() {
         return this.instantMine;
      }

      public int getPriority() {
         return this.priority;
      }

      public boolean isTerrainBase() {
         return this.terrainBase;
      }

      public void setTerrainBase(boolean terrainBase) {
         this.terrainBase = terrainBase;
      }

      public boolean isTerrainSurround() {
         return this.terrainSurround;
      }

      public void setTerrainSurround(boolean terrainSurround) {
         this.terrainSurround = terrainSurround;
      }

      public boolean isStarted() {
         return this.started;
      }

      private int getBreakSlot(BlockState state, int defaultSlot) {
         AutoMineModule autoMine = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoMineModule.class) : null;
         int ironSlot;
         return autoMine != null
               && autoMine.isToggled()
               && autoMine.ironPickaxe.getValue()
               && this.ironSwapped
               && (ironSlot = InventoryUtils.find(Items.IRON_PICKAXE, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END)) != -1
            ? ironSlot
            : defaultSlot;
      }

      private long asyncFireDelayMs() {
         long baseDelay = this.this$0.instantDelay.getValue().longValue() * 50L;
         if (this.position == null) {
            return baseDelay;
         } else {
            SpeedMineModule.Target currentTarget = this.this$0.getTarget();
            if (currentTarget != null && currentTarget.player() != null) {
               boolean isHeadPosition = this.position.getY() == Mth.floor(currentTarget.player().getY()) + 2
                  && this.this$0.isTargetSurroundPosition(this.position, currentTarget.player());
               if (!isHeadPosition) {
                  return baseDelay;
               } else {
                  AutoTrapModule autoTrap = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoTrapModule.class) : null;
                  AutoMineModule autoMine = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoMineModule.class) : null;
                  boolean autoTrapActive = autoTrap != null && autoTrap.isToggled();
                  boolean priorityHead = autoMine != null && autoMine.isToggled() && autoMine.priority.getValue().equalsIgnoreCase("Head");
                  return autoTrapActive && priorityHead ? Math.max(baseDelay, (long)Night.SERVER_MANAGER.getPing()) : baseDelay;
               }
            } else {
               return baseDelay;
            }
         }
      }

      private void updateIronGhost() {
         AutoMineModule autoMine = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoMineModule.class) : null;
         boolean isIronPickMode = autoMine != null && autoMine.isToggled() && autoMine.ironPickaxe.getValue();
         int ironSlot;
         if (isIronPickMode
            && !this.ironSwapped
            && (ironSlot = InventoryUtils.find(Items.IRON_PICKAXE, InventoryUtils.HOTBAR_START, InventoryUtils.INVENTORY_END)) != -1
            && this.state != null
            && !this.state.isAir()) {
            float ironDelta = WorldUtils.getMineSpeed(this.state, ironSlot) / Night.WORLD_MANAGER.getTimerMultiplier();
            this.ghostIronProgress = Mth.clamp(this.ghostIronProgress + ironDelta, 0.0F, this.getSpeed());
            if (this.ghostIronProgress >= this.getSpeed()) {
               int fastestHotbarSlot = InventoryUtils.findFastestItem(this.state, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END);
               if (fastestHotbarSlot == -1) {
                  fastestHotbarSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
               }

               if (ironSlot > InventoryUtils.HOTBAR_END) {
                  InventoryUtils.swap("Swap", ironSlot, fastestHotbarSlot);
                  this.ironSwapped = true;
                  this.swappedIronInventorySlot = ironSlot;
                  this.swappedIronHotbarSlot = fastestHotbarSlot;
               } else if (ironSlot != -1) {
                  this.ironSwapped = true;
                  this.swappedIronInventorySlot = -1;
                  this.swappedIronHotbarSlot = ironSlot;
               }
            }
         }
      }

      public void restoreIronSwap() {
         if (this.ironSwapped) {
            if (this.swappedIronInventorySlot > InventoryUtils.HOTBAR_END
               && this.swappedIronHotbarSlot >= 0
               && this.swappedIronHotbarSlot <= InventoryUtils.HOTBAR_END) {
               if (IMinecraft.mc.player != null && IMinecraft.mc.player.getInventory().getItem(this.swappedIronHotbarSlot).is(Items.IRON_PICKAXE)) {
                  InventoryUtils.swap("Swap", this.swappedIronInventorySlot, this.swappedIronHotbarSlot);
               }
            } else {
               int hotbarIron;
               if (IMinecraft.mc.player != null
                  && (hotbarIron = InventoryUtils.find(Items.IRON_PICKAXE, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END)) != -1) {
                  BlockState targetState = this.state != null && !this.state.isAir() ? this.state : Blocks.OBSIDIAN.defaultBlockState();
                  int invSlot = this.swappedIronInventorySlot > InventoryUtils.HOTBAR_END
                     ? this.swappedIronInventorySlot
                     : InventoryUtils.findFastestItem(targetState, InventoryUtils.HOTBAR_END + 1, InventoryUtils.INVENTORY_END);
                  if (invSlot == -1) {
                     invSlot = InventoryUtils.findEmptySlot(InventoryUtils.HOTBAR_END + 1, InventoryUtils.INVENTORY_END);
                  }

                  if (invSlot != -1 && invSlot > InventoryUtils.HOTBAR_END) {
                     InventoryUtils.swap("Swap", invSlot, hotbarIron);
                  }
               }
            }

            this.ironSwapped = false;
            this.swappedIronInventorySlot = -1;
            this.swappedIronHotbarSlot = -1;
            this.ghostIronProgress = 0.0F;
         }
      }

      private SpeedMineModule.Secondary demote() {
         this.restoreIronSwap();
         if (!this.started) {
            return null;
         } else {
            BlockState current = IMinecraft.mc.level.getBlockState(this.position);
            if (current.canBeReplaced()) {
               return null;
            } else if (this.this$0.sixB.getValue() && current.getBlock() == Blocks.BEDROCK) {
               return null;
            } else {
               if (!this.instantMine && this.progress < this.getSpeed()) {
                  Direction direction = WorldUtils.getClosestDirection(this.position, true);
                  int slot = this.this$0.switchMode.getValue().equalsIgnoreCase("None")
                     ? -1
                     : InventoryUtils.findFastestItem(
                        current,
                        InventoryUtils.HOTBAR_START,
                        !this.this$0.switchMode.getValue().equalsIgnoreCase("AltSwap") && !this.this$0.switchMode.getValue().equalsIgnoreCase("AltPickup")
                           ? InventoryUtils.HOTBAR_END
                           : InventoryUtils.INVENTORY_END
                     );
                  if (slot == -1) {
                     slot = IMinecraft.mc.player.getInventory().getSelectedSlot();
                  }

                  this.fireBreakBurst(direction, slot, true);
               }

               return SpeedMineModule.this.new Secondary(this.this$0, this.position, this.priority, current, this.progress);
            }
         }
      }

      private void markBroken() {
         this.brokenCount++;
      }

      private boolean ackStalled() {
         if (this.brokenCount != this.lastBrokenCount) {
            this.instantRemineResetTimer.reset();
            this.lastBrokenCount = this.brokenCount;
         }

         return this.instantRemineResetTimer.hasTimeElapsed(200L);
      }

      private boolean instantAckStalled() {
         return IMinecraft.mc.level.getBlockState(this.position).canBeReplaced() && this.ackStalled();
      }

      private void tryStart() {
         Object object = this.this$0.interactSyncLock;
         synchronized (object) {
            if (this.this$0.canStartNow()) {
               this.start();
            }
         }
      }

      public boolean process() {
         if (this.this$0.isOutOfRange(this.position)) {
            this.cancel();
            return true;
         } else {
            this.updateIronGhost();
            boolean clientEating = IMinecraft.mc.player != null && (IMinecraft.mc.player.isUsingItem() || EntityUtils.isEating());
            if (this.this$0.interactPaused && !clientEating && System.currentTimeMillis() - this.this$0.interactPausedAt >= 750L) {
               this.this$0.setInteractPaused(false);
            }

            if (this.this$0.needsRestart && this.this$0.isProxyActive()) {
               this.this$0.needsRestart = false;
               this.started = false;
            }

            if (!this.started) {
               if (IMinecraft.mc.level.getBlockState(this.position).canBeReplaced()) {
                  return true;
               } else {
                  this.tryStart();
                  return false;
               }
            } else if (!this.this$0.farReach.getValue()) {
               return this.legacyProcess();
            } else if (IMinecraft.mc.level.getBlockState(this.position).canBeReplaced()) {
               if (this.brokenCount == 0) {
                  this.markBroken();
               }

               if (this.this$0.sixB.getValue() && this.state.getBlock() == Blocks.BEDROCK) {
                  this.instantMine = true;
                  return false;
               } else {
                  if (this.this$0.rebreak.getValue().equalsIgnoreCase("Fast")) {
                     this.progress = 0.0F;
                     this.prevProgress = 0.0F;
                  }

                  if (this.instantMine) {
                     if (this.this$0.async.getValue()) {
                        if ((this.this$0.whileEating.getValue() || !EntityUtils.isEating())
                           && !this.isAsyncFireBlockedByCombo()
                           && this.this$0.instantTimer.hasTimeElapsed(this.asyncFireDelayMs())) {
                           Direction asyncDirection = WorldUtils.getClosestDirection(this.position, true);
                           int asyncSlot = this.this$0.switchMode.getValue().equalsIgnoreCase("None")
                              ? -1
                              : InventoryUtils.findFastestItem(
                                 this.state,
                                 InventoryUtils.HOTBAR_START,
                                 !this.this$0.switchMode.getValue().equalsIgnoreCase("AltSwap")
                                       && !this.this$0.switchMode.getValue().equalsIgnoreCase("AltPickup")
                                    ? InventoryUtils.HOTBAR_END
                                    : InventoryUtils.INVENTORY_END
                              );
                           if (asyncSlot == -1) {
                              asyncSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
                           }

                           this.fireBreakBurst(asyncDirection, this.getBreakSlot(this.state, asyncSlot), false, false);
                           this.this$0.instantTimer.reset();
                           this.attempts++;
                        }

                        return false;
                     }

                     if (this.instantAckStalled()) {
                        return false;
                     }

                     long timeoutTicks = this.this$0.instantTimeout.getValue().longValue();
                     boolean timedOut = timeoutTicks > 0L && this.this$0.instantTimer.hasTimeElapsed(timeoutTicks * 50L);
                     if (!timedOut) {
                        return false;
                     }
                  }

                  if (this.this$0.isProxyActive()) {
                     this.this$0.serverSend(new ServerboundSetCarriedItemPacket(IMinecraft.mc.player.getInventory().getSelectedSlot()));
                  }

                  this.cancel();
                  return true;
               }
            } else {
               Direction direction = WorldUtils.getClosestDirection(this.position, true);
               BlockState state = IMinecraft.mc.level.getBlockState(this.position);
               if (!state.canBeReplaced() && state.getBlock() != this.state.getBlock()) {
                  this.state = state;
               }

               if (this.mining) {
                  this.ticks++;
                  int slot = this.this$0.switchMode.getValue().equalsIgnoreCase("None")
                     ? -1
                     : InventoryUtils.findFastestItem(
                        this.state,
                        InventoryUtils.HOTBAR_START,
                        !this.this$0.switchMode.getValue().equalsIgnoreCase("AltSwap") && !this.this$0.switchMode.getValue().equalsIgnoreCase("AltPickup")
                           ? InventoryUtils.HOTBAR_END
                           : InventoryUtils.INVENTORY_END
                     );
                  if (slot == -1) {
                     slot = IMinecraft.mc.player.getInventory().getSelectedSlot();
                  }

                  float delta = this.this$0.sixB.getValue() && this.state.getBlock() == Blocks.BEDROCK
                     ? 0.025F
                     : WorldUtils.getMineSpeed(this.state, slot) / Night.WORLD_MANAGER.getTimerMultiplier();
                  if (this.instantMine) {
                     this.prevProgress = this.getSpeed();
                     this.progress = this.getSpeed();
                  } else {
                     this.prevProgress = this.progress;
                     this.progress = Mth.clamp(this.progress + delta, 0.0F, this.getSpeed());
                  }

                  if (this.this$0.sixB.getValue() && this.state.getBlock() == Blocks.BEDROCK) {
                     if (this.this$0.isProxyActive()) {
                        this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                     } else {
                        IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                     }

                     IMinecraft.mc.player.swing(InteractionHand.MAIN_HAND);
                  }

                  if (this.this$0.rotate.getValue().equalsIgnoreCase("Normal") && this.progress + delta * 2.0F >= this.getSpeed()) {
                     float[] rots = RotationUtils.getRotations(WorldUtils.getHitVector(this.position, direction));
                     if (this.this$0.isProxyActive()) {
                        this.this$0
                           .serverSend(
                              new PosRot(
                                 IMinecraft.mc.player.getX(),
                                 IMinecraft.mc.player.getY(),
                                 IMinecraft.mc.player.getZ(),
                                 rots[0],
                                 rots[1],
                                 IMinecraft.mc.player.onGround(),
                                 IMinecraft.mc.player.horizontalCollision
                              )
                           );
                     } else {
                        Night.ROTATION_MANAGER.legacyRotate(rots, Night.ROTATION_MANAGER.getLegacyModulePriority(this.this$0));
                     }
                  }

                  boolean isEatingNow = IMinecraft.mc.player != null && (IMinecraft.mc.player.isUsingItem() || EntityUtils.isEating());
                  boolean pauseBreak = this.this$0.interactPaused || !this.this$0.whileEating.getValue() && isEatingNow;
                  if (this.progress >= this.getSpeed() && !state.canBeReplaced() && !pauseBreak) {
                     if (this.instantMine && this.brokenCount == 0 && this.ackStalled()) {
                        this.start();
                        return false;
                     }

                     if (!this.instantMine
                        || this.this$0.async.getValue()
                        || this.this$0.instantTimer.hasTimeElapsed(this.this$0.instantDelay.getValue().longValue() * 50L)) {
                        this.fireBreakBurst(direction, this.getBreakSlot(this.state, slot), false, !this.instantMine);
                        if (!this.instantMine) {
                           this.this$0.mineTimer.reset();
                        }

                        this.attempts++;
                        if ((!this.this$0.rebreak.getValue().equalsIgnoreCase("None") || this.this$0.sixB.getValue()) && !this.terrainBase) {
                           this.instantMine = true;
                           if (this.this$0.rebreak.getValue().equalsIgnoreCase("Fast")) {
                              this.progress = 0.0F;
                              this.prevProgress = 0.0F;
                           }

                           this.this$0.instantTimer.reset();
                           this.instantRemineResetTimer.reset();
                        } else {
                           this.mining = false;
                           this.stallTime = System.currentTimeMillis();
                        }
                     }

                     return false;
                  }
               } else if (!IMinecraft.mc.level.getBlockState(this.position).canBeReplaced()
                  && (this.attempts == 0 || System.currentTimeMillis() - this.stallTime >= 150L)) {
                  this.tryStart();
               }

               return false;
            }
         }
      }

      private boolean legacyProcess() {
         this.updateIronGhost();
         if (IMinecraft.mc.level.getBlockState(this.position).canBeReplaced()) {
            if (this.brokenCount == 0) {
               this.markBroken();
            }

            if (this.this$0.sixB.getValue() && this.state.getBlock() == Blocks.BEDROCK) {
               this.instantMine = true;
               return false;
            } else {
               if (this.instantMine) {
                  if (this.this$0.async.getValue()) {
                     if ((this.this$0.whileEating.getValue() || !EntityUtils.isEating())
                        && !this.isAsyncFireBlockedByCombo()
                        && this.this$0.instantTimer.hasTimeElapsed(this.asyncFireDelayMs())) {
                        Direction asyncDirection = WorldUtils.getClosestDirection(this.position, true);
                        int asyncSlot = this.this$0.switchMode.getValue().equalsIgnoreCase("None")
                           ? -1
                           : InventoryUtils.findFastestItem(
                              this.state,
                              InventoryUtils.HOTBAR_START,
                              !this.this$0.switchMode.getValue().equalsIgnoreCase("AltSwap")
                                    && !this.this$0.switchMode.getValue().equalsIgnoreCase("AltPickup")
                                 ? InventoryUtils.HOTBAR_END
                                 : InventoryUtils.INVENTORY_END
                           );
                        if (asyncSlot == -1) {
                           asyncSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
                        }

                        this.legacyFireBreakBurst(asyncDirection, this.getBreakSlot(this.state, asyncSlot));
                        this.this$0.instantTimer.reset();
                        this.attempts++;
                     }

                     return false;
                  }

                  if (this.instantAckStalled()) {
                     return false;
                  }

                  long timeoutTicks = this.this$0.instantTimeout.getValue().longValue();
                  boolean timedOut = timeoutTicks > 0L && this.this$0.instantTimer.hasTimeElapsed(timeoutTicks * 50L);
                  if (!timedOut) {
                     return false;
                  }
               }

               if (this.this$0.isProxyActive()) {
                  this.this$0.serverSend(new ServerboundSetCarriedItemPacket(IMinecraft.mc.player.getInventory().getSelectedSlot()));
               }

               this.cancel();
               return true;
            }
         } else {
            Direction direction = WorldUtils.getClosestDirection(this.position, true);
            BlockState state = IMinecraft.mc.level.getBlockState(this.position);
            if (!state.canBeReplaced() && state.getBlock() != this.state.getBlock()) {
               this.state = state;
            }

            if (!this.mining) {
               if (!IMinecraft.mc.level.getBlockState(this.position).canBeReplaced()
                  && (this.attempts == 0 || System.currentTimeMillis() - this.stallTime >= 150L)) {
                  this.start();
               }
            } else {
               this.ticks++;
               int slot = this.this$0.switchMode.getValue().equalsIgnoreCase("None")
                  ? -1
                  : InventoryUtils.findFastestItem(
                     this.state,
                     InventoryUtils.HOTBAR_START,
                     !this.this$0.switchMode.getValue().equalsIgnoreCase("AltSwap") && !this.this$0.switchMode.getValue().equalsIgnoreCase("AltPickup")
                        ? InventoryUtils.HOTBAR_END
                        : InventoryUtils.INVENTORY_END
                  );
               if (slot == -1) {
                  slot = IMinecraft.mc.player.getInventory().getSelectedSlot();
               }

               float delta = this.this$0.sixB.getValue() && this.state.getBlock() == Blocks.BEDROCK
                  ? 0.025F
                  : WorldUtils.getMineSpeed(this.state, slot) / Night.WORLD_MANAGER.getTimerMultiplier();
               if (this.instantMine) {
                  this.prevProgress = this.getSpeed();
                  this.progress = this.getSpeed();
               } else {
                  this.prevProgress = this.progress;
                  this.progress = Mth.clamp(this.progress + delta, 0.0F, this.getSpeed());
               }

               if (this.this$0.sixB.getValue() && this.state.getBlock() == Blocks.BEDROCK) {
                  if (this.this$0.isProxyActive()) {
                     this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                  } else {
                     IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                  }

                  if (IMinecraft.mc.player == null
                     || !IMinecraft.mc.player.isUsingItem()
                     || IMinecraft.mc.player.getUsedItemHand() != InteractionHand.MAIN_HAND) {
                     IMinecraft.mc.player.swing(InteractionHand.MAIN_HAND);
                  }
               }

               if (this.this$0.rotate.getValue().equalsIgnoreCase("Normal") && this.progress + delta * 2.0F >= this.getSpeed()) {
                  float[] rots = RotationUtils.getRotations(WorldUtils.getHitVector(this.position, direction));
                  if (this.this$0.isProxyActive()) {
                     this.this$0
                        .serverSend(
                           new PosRot(
                              IMinecraft.mc.player.getX(),
                              IMinecraft.mc.player.getY(),
                              IMinecraft.mc.player.getZ(),
                              rots[0],
                              rots[1],
                              IMinecraft.mc.player.onGround(),
                              IMinecraft.mc.player.horizontalCollision
                           )
                        );
                  } else {
                     Night.ROTATION_MANAGER.legacyRotate(rots, Night.ROTATION_MANAGER.getLegacyModulePriority(this.this$0));
                  }
               }

               if (this.progress >= this.getSpeed() && !state.canBeReplaced() && (this.this$0.whileEating.getValue() || !EntityUtils.isEating())) {
                  if (this.instantMine && this.brokenCount == 0 && this.ackStalled()) {
                     this.start();
                     return false;
                  }

                  if (!this.instantMine
                     || this.this$0.async.getValue()
                     || this.this$0.instantTimer.hasTimeElapsed(this.this$0.instantDelay.getValue().longValue() * 50L)) {
                     this.legacyFireBreakBurst(direction, this.getBreakSlot(this.state, slot));
                     this.attempts++;
                     if ((!this.this$0.rebreak.getValue().equalsIgnoreCase("None") || this.this$0.sixB.getValue()) && !this.terrainBase) {
                        this.instantMine = true;
                        if (this.this$0.rebreak.getValue().equalsIgnoreCase("Fast")) {
                           this.progress = 0.0F;
                           this.prevProgress = 0.0F;
                        }

                        this.this$0.instantTimer.reset();
                        this.instantRemineResetTimer.reset();
                     } else {
                        this.mining = false;
                        this.stallTime = System.currentTimeMillis();
                     }
                  }

                  return false;
               }
            }

            return false;
         }
      }

      private boolean isHeadCrystalComboPending() {
         AutoTrapModule autoTrap = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoTrapModule.class) : null;
         if (autoTrap != null && autoTrap.isToggled()) {
            AutoCrystalModule autoCrystal = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoCrystalModule.class) : null;
            if (autoCrystal != null && autoCrystal.isToggled()) {
               SpeedMineModule.Target currentTarget = this.this$0.getTarget();
               if (currentTarget != null && currentTarget.player() != null) {
                  int targetFeetY = Mth.floor(currentTarget.player().getY());
                  return this.position.getY() >= targetFeetY + 2
                     && Math.abs(this.position.getX() + 0.5 - currentTarget.player().getX()) < 1.3
                     && Math.abs(this.position.getZ() + 0.5 - currentTarget.player().getZ()) < 1.3;
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      }

      private boolean isCivBreakComboPending() {
         AutoMineModule autoMine = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoMineModule.class) : null;
         return autoMine != null && autoMine.isToggled() && autoMine.isUpComboActive(this.position);
      }

      private boolean isAsyncFireBlockedByCombo() {
         return this.isHeadCrystalComboPending() || this.isCivBreakComboPending();
      }

      private void checkAndPlaceHeadCrystal(BlockPos pos) {
         if (IMinecraft.mc.player != null && IMinecraft.mc.level != null && IMinecraft.mc.getConnection() != null) {
            if (this.instantMine) {
               AutoTrapModule autoTrap = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoTrapModule.class) : null;
               if (autoTrap != null && autoTrap.isToggled()) {
                  AutoCrystalModule autoCrystal = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoCrystalModule.class) : null;
                  if (autoCrystal != null && autoCrystal.isToggled()) {
                     BlockState blockState = IMinecraft.mc.level.getBlockState(pos);
                     if (blockState.getBlock() == Blocks.OBSIDIAN) {
                        SpeedMineModule.Target currentTarget = this.this$0.getTarget();
                        if (currentTarget != null && currentTarget.player() != null) {
                           int targetFeetY = Mth.floor(currentTarget.player().getY());
                           boolean isHeadPos = pos.getY() >= targetFeetY + 2
                              && Math.abs(pos.getX() + 0.5 - currentTarget.player().getX()) < 1.3
                              && Math.abs(pos.getZ() + 0.5 - currentTarget.player().getZ()) < 1.3;
                           if (isHeadPos) {
                              BlockPos crystalPos = pos.above();
                              if (WorldUtils.isCrystalPlaceable(crystalPos)) {
                                 int crystalSlot = InventoryUtils.findHotbar(Items.END_CRYSTAL);
                                 boolean offhand = IMinecraft.mc.player.getOffhandItem().getItem() == Items.END_CRYSTAL;
                                 if (offhand || crystalSlot != -1) {
                                    InteractionHand hand = offhand ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
                                    Vec3 hitVec = new Vec3(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                                    BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, pos, false);
                                    if (this.this$0.isProxyActive()) {
                                       if (offhand) {
                                          this.this$0.serverSendSequenced(seq -> new ServerboundUseItemOnPacket(hand, hit, seq));
                                          this.this$0.serverSend(new ServerboundSwingPacket(hand));
                                       } else {
                                          int previousSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
                                          this.this$0.serverSend(new ServerboundSetCarriedItemPacket(crystalSlot));
                                          this.this$0.serverSendSequenced(seq -> new ServerboundUseItemOnPacket(hand, hit, seq));
                                          this.this$0.serverSend(new ServerboundSwingPacket(hand));
                                          this.this$0.serverSend(new ServerboundSetCarriedItemPacket(previousSlot));
                                       }
                                    } else if (offhand) {
                                       NetworkUtils.sendSequencedPacket(seq -> new ServerboundUseItemOnPacket(hand, hit, seq));
                                       IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(hand));
                                    } else {
                                       int previousSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
                                       InventoryUtils.switchSlot("Silent", crystalSlot, previousSlot);
                                       NetworkUtils.sendSequencedPacket(seq -> new ServerboundUseItemOnPacket(hand, hit, seq));
                                       IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(hand));
                                       InventoryUtils.switchBack("Silent", crystalSlot, previousSlot);
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      private void legacyFireBreakBurst(Direction direction, int slot) {
         this.checkAndPlaceHeadCrystal(this.position);
         Night.EVENT_HANDLER.post(new DestroyBlockEvent(this.position));
         if (this.this$0.rotate.getValue().equalsIgnoreCase("Silent")) {
            float[] rots = RotationUtils.getRotations(WorldUtils.getHitVector(this.position, direction));
            if (this.this$0.isProxyActive()) {
               this.this$0.serverSend(new Rot(rots[0], rots[1], IMinecraft.mc.player.onGround(), IMinecraft.mc.player.horizontalCollision));
            } else {
               Night.ROTATION_MANAGER.wireRotate("Silent", rots);
            }
         }

         int previousSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
         if (this.this$0.isProxyActive()) {
            int mineSlot = this.this$0.switchMode.getValue().equalsIgnoreCase("None") ? -1 : slot;
            boolean needSwitch = mineSlot != -1 && mineSlot != previousSlot;
            if (needSwitch) {
               this.this$0.serverSend(new ServerboundSetCarriedItemPacket(mineSlot));
            }

            this.stopDestroyBlock(this.position, direction, true);
            if (this.this$0.grim.getValue()) {
               this.this$0
                  .serverSend(
                     new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, this.position.above(500), direction
                     )
                  );
            }

            this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            if (needSwitch) {
               this.this$0.serverSend(new ServerboundSetCarriedItemPacket(previousSlot));
            }
         } else {
            InventoryUtils.switchSlot(this.this$0.switchMode.getValue(), slot, previousSlot);
            this.stopDestroyBlock(this.position, direction, true);
            if (this.this$0.grim.getValue()) {
               IMinecraft.mc
                  .getConnection()
                  .send(
                     new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, this.position.above(500), direction
                     )
                  );
            }

            IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            if (IMinecraft.mc.level.getBlockState(this.position).getBlock() == Blocks.BEDROCK) {
               IMinecraft.mc.player.swing(InteractionHand.MAIN_HAND);
            }

            InventoryUtils.switchBack(this.this$0.switchMode.getValue(), slot, previousSlot);
         }
      }

      private void fireBreakBurst(Direction direction, int slot, boolean demote) {
         this.fireBreakBurst(direction, slot, demote, !demote);
      }

      private void fireBreakBurst(Direction direction, int slot, boolean demote, boolean armCooldown) {
         if (!demote) {
            this.checkAndPlaceHeadCrystal(this.position);
            Night.EVENT_HANDLER.post(new DestroyBlockEvent(this.position));
         }

         if (this.this$0.rotate.getValue().equalsIgnoreCase("Silent")) {
            float[] rots = RotationUtils.getRotations(WorldUtils.getHitVector(this.position, direction));
            if (this.this$0.isProxyActive()) {
               this.this$0.serverSend(new Rot(rots[0], rots[1], IMinecraft.mc.player.onGround(), IMinecraft.mc.player.horizontalCollision));
            } else {
               Night.ROTATION_MANAGER.wireRotate("Silent", rots);
            }
         }

         int previousSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
         if (this.this$0.isProxyActive()) {
            int realPreviousSlot = this.startSlot != -1 ? this.startSlot : previousSlot;
            int mineSlot = this.this$0.switchMode.getValue().equalsIgnoreCase("None") ? -1 : slot;
            if (mineSlot != -1) {
               this.this$0.serverSend(new ServerboundSetCarriedItemPacket(mineSlot));
               if (this.this$0.switchMode.getValue().equalsIgnoreCase("Normal")) {
                  IMinecraft.mc.player.getInventory().setSelectedSlot(mineSlot);
               }
            }

            this.stopDestroyBlock(this.position, direction, !demote, armCooldown);
            if (this.this$0.grim.getValue()) {
               this.this$0
                  .serverSend(
                     new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, this.position.above(500), direction
                     )
                  );
            }

            this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            if (IMinecraft.mc.level.getBlockState(this.position).getBlock() == Blocks.BEDROCK) {
               IMinecraft.mc.player.swing(InteractionHand.MAIN_HAND);
            }

            if (mineSlot != -1) {
               this.this$0.serverSend(new ServerboundSetCarriedItemPacket(realPreviousSlot));
               if (this.this$0.switchMode.getValue().equalsIgnoreCase("Normal")) {
                  IMinecraft.mc.player.getInventory().setSelectedSlot(realPreviousSlot);
               }
            }
         } else {
            InventoryUtils.switchSlot(this.this$0.switchMode.getValue(), slot, previousSlot);
            this.stopDestroyBlock(this.position, direction, !demote, armCooldown);
            if (this.this$0.grim.getValue()) {
               IMinecraft.mc
                  .getConnection()
                  .send(
                     new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, this.position.above(500), direction
                     )
                  );
            }

            IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            if (IMinecraft.mc.level.getBlockState(this.position).getBlock() == Blocks.BEDROCK) {
               IMinecraft.mc.player.swing(InteractionHand.MAIN_HAND);
            }

            InventoryUtils.switchBack(this.this$0.switchMode.getValue(), slot, previousSlot);
         }
      }

      private void stopDestroyBlock(BlockPos position, Direction direction, boolean remove) {
         this.stopDestroyBlock(position, direction, remove, false);
      }

      private void stopDestroyBlock(BlockPos position, Direction direction, boolean remove, boolean cooldown) {
         BlockStatePredictionHandler prediction = ((ClientWorldAccessor)IMinecraft.mc.level).invokeGetPendingUpdateManager().startPredicting();

         try {
            ServerboundPlayerActionPacket packet = new ServerboundPlayerActionPacket(
               net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, position, direction, prediction.currentSequence()
            );
            this.this$0.markStop(cooldown);
            if (this.this$0.isProxyActive()) {
               this.this$0.serverSend(packet);
            } else {
               IMinecraft.mc.getConnection().send(packet);
            }
         } catch (Throwable var9) {
            if (prediction != null) {
               try {
                  prediction.close();
               } catch (Throwable var8) {
                  var9.addSuppressed(var8);
               }
            }

            throw var9;
         }

         if (prediction != null) {
            prediction.close();
         }
      }

      public void render(PoseStack matrices) {
         if (!IMinecraft.mc.level.getBlockState(this.position).canBeReplaced() || this.instantMine) {
            AABB box = new AABB(this.position);
            boolean airWaiting = IMinecraft.mc.level.getBlockState(this.position).canBeReplaced() && this.instantMine;
            double progress = airWaiting
               ? this.progress / this.getSpeed()
               : Mth.clamp(
                  Mth.lerp(
                     IMinecraft.mc.getDeltaTracker().getGameTimeDeltaPartialTick(false), this.prevProgress / this.getSpeed(), this.progress / this.getSpeed()
                  ),
                  0.0F,
                  1.0F
               );
            if (this.this$0.animation.getValue().equalsIgnoreCase("Expand")) {
               box = new AABB(this.position).deflate(0.5).inflate(Mth.clamp(progress / 2.0, 0.0, 0.5));
            }

            if (this.this$0.animation.getValue().equalsIgnoreCase("Rise")) {
               box = new AABB(
                  this.position.getX(),
                  this.position.getY(),
                  this.position.getZ(),
                  this.position.getX() + 1.0,
                  this.position.getY() + progress,
                  this.position.getZ() + 1.0
               );
            }

            Color fill = this.this$0.fillColor.getColor();
            Color outline = this.this$0.outlineColor.getColor();
            if (this.this$0.color.getValue().equalsIgnoreCase("Static")) {
               fill = progress >= 0.9 ? new Color(0, 255, 0, this.this$0.fillColor.getAlpha()) : new Color(255, 0, 0, this.this$0.fillColor.getAlpha());
               outline = progress >= 0.9
                  ? new Color(0, 255, 0, this.this$0.outlineColor.getAlpha())
                  : new Color(255, 0, 0, this.this$0.outlineColor.getAlpha());
            } else if (this.this$0.color.getValue().equalsIgnoreCase("Smooth")) {
               fill = new Color(
                  255 - (int)(Mth.clamp(progress, 0.0, 1.0) * 255.0), (int)(Mth.clamp(progress, 0.0, 1.0) * 255.0), 0, this.this$0.fillColor.getAlpha()
               );
               outline = new Color(
                  255 - (int)(Mth.clamp(progress, 0.0, 1.0) * 255.0), (int)(Mth.clamp(progress, 0.0, 1.0) * 255.0), 0, this.this$0.outlineColor.getAlpha()
               );
            }

            if (progress >= this.getSpeed() && this.instantMine && this.this$0.instantRender.getValue().equalsIgnoreCase("Custom")) {
               fill = ColorUtils.getColor(this.this$0.instantColor.getColor(), this.this$0.fillColor.getAlpha());
               outline = ColorUtils.getColor(this.this$0.instantColor.getColor(), this.this$0.outlineColor.getAlpha());
            }

            if (this.this$0.render.getValue().equalsIgnoreCase("Fill") || this.this$0.render.getValue().equalsIgnoreCase("Both")) {
               Renderer3D.renderBox(matrices, box, fill);
            }

            if (this.this$0.render.getValue().equalsIgnoreCase("Outline") || this.this$0.render.getValue().equalsIgnoreCase("Both")) {
               Renderer3D.renderBoxOutline(matrices, box, outline);
            }
         }
      }

      public void start() {
         if (!this.this$0.farReach.getValue()) {
            this.legacyStart();
         } else {
            this.this$0.trackStarts(this.this$0.farReach.getValue() ? 2 : 1);
            Direction direction = WorldUtils.getClosestDirection(this.position, true);
            if (this.this$0.isProxyActive()) {
               this.startSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
               if (this.this$0.farReach.getValue()) {
                  this.this$0
                     .sendRawPlayerAction(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, this.position, direction
                     );
                  BlockPos decoyPos = this.grimDecoyPos();
                  this.this$0
                     .sendRawPlayerAction(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK,
                        decoyPos,
                        WorldUtils.getClosestDirection(decoyPos, true)
                     );
               } else {
                  this.this$0
                     .serverSendSequenced(
                        seq -> new ServerboundPlayerActionPacket(
                           net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, this.position, direction, seq
                        )
                     );
               }

               this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            } else {
               if (this.this$0.farReach.getValue()) {
                  this.this$0
                     .sendRawPlayerAction(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, this.position, direction
                     );
                  BlockPos decoyPos = this.grimDecoyPos();
                  this.this$0
                     .sendRawPlayerAction(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK,
                        decoyPos,
                        WorldUtils.getClosestDirection(decoyPos, true)
                     );
               } else {
                  NetworkUtils.sendSequencedPacket(
                     seq -> new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, this.position, direction, seq
                     )
                  );
               }

               IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            }

            if (this.state.getBlock() == Blocks.BEDROCK) {
               IMinecraft.mc.player.swing(InteractionHand.MAIN_HAND);
            }

            this.restoreIronSwap();
            this.progress = 0.0F;
            this.prevProgress = 0.0F;
            this.ghostIronProgress = 0.0F;
            this.ironSwapped = false;
            this.swappedIronInventorySlot = -1;
            this.swappedIronHotbarSlot = -1;
            this.attempts = 0;
            this.ticks = 0;
            this.mining = true;
            this.instantMine = false;
            this.started = true;
            this.brokenCount = 0;
            this.lastBrokenCount = -1;
            this.instantRemineResetTimer.reset();
         }
      }

      private void legacyStart() {
         Direction direction = WorldUtils.getClosestDirection(this.position, true);
         if (this.this$0.isProxyActive()) {
            int slot = this.this$0.switchMode.getValue().equalsIgnoreCase("None")
               ? -1
               : InventoryUtils.findFastestItem(
                  this.state,
                  InventoryUtils.HOTBAR_START,
                  !this.this$0.switchMode.getValue().equalsIgnoreCase("AltSwap") && !this.this$0.switchMode.getValue().equalsIgnoreCase("AltPickup")
                     ? InventoryUtils.HOTBAR_END
                     : InventoryUtils.INVENTORY_END
               );
            boolean needSwitch = slot != -1 && slot != IMinecraft.mc.player.getInventory().getSelectedSlot();
            if (needSwitch) {
               this.this$0.serverSend(new ServerboundSetCarriedItemPacket(slot));
            }

            if (this.this$0.doubleMine.getValue()) {
               this.this$0
                  .serverSendSequenced(
                     seq -> new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, this.position, direction, seq
                     )
                  );
               this.this$0
                  .serverSendSequenced(
                     seq -> new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, this.position, direction, seq
                     )
                  );
               this.this$0
                  .serverSendSequenced(
                     seq -> new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, this.position, direction, seq
                     )
                  );
            } else {
               this.this$0
                  .serverSendSequenced(
                     seq -> new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, this.position, direction, seq
                     )
                  );
            }

            this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
         } else {
            if (this.this$0.doubleMine.getValue()) {
               NetworkUtils.sendSequencedPacket(
                  seq -> new ServerboundPlayerActionPacket(
                     net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, this.position, direction, seq
                  )
               );
               NetworkUtils.sendSequencedPacket(
                  seq -> new ServerboundPlayerActionPacket(
                     net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, this.position, direction, seq
                  )
               );
               NetworkUtils.sendSequencedPacket(
                  seq -> new ServerboundPlayerActionPacket(
                     net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, this.position, direction, seq
                  )
               );
            } else {
               NetworkUtils.sendSequencedPacket(
                  seq -> new ServerboundPlayerActionPacket(
                     net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, this.position, direction, seq
                  )
               );
            }

            IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
         }

         if (this.state.getBlock() == Blocks.BEDROCK) {
            IMinecraft.mc.player.swing(InteractionHand.MAIN_HAND);
         }

         this.restoreIronSwap();
         this.progress = 0.0F;
         this.prevProgress = 0.0F;
         this.ghostIronProgress = 0.0F;
         this.ironSwapped = false;
         this.swappedIronInventorySlot = -1;
         this.swappedIronHotbarSlot = -1;
         this.attempts = 0;
         this.ticks = 0;
         this.mining = true;
         this.instantMine = false;
         this.started = true;
         this.brokenCount = 0;
         this.lastBrokenCount = -1;
         this.instantRemineResetTimer.reset();
      }

      public void cancel() {
         if (!this.this$0.farReach.getValue()) {
            this.legacyCancel();
         } else {
            if (!this.this$0.doubleMine.getValue() && this.started) {
               if (this.this$0.farReach.getValue()) {
                  this.this$0
                     .sendRawPlayerAction(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK,
                        this.position,
                        WorldUtils.getClosestDirection(this.position, true)
                     );
                  this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               } else if (this.this$0.isProxyActive()) {
                  this.this$0
                     .serverSendSequenced(
                        seq -> new ServerboundPlayerActionPacket(
                           net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK,
                           this.position,
                           WorldUtils.getClosestDirection(this.position, true),
                           seq
                        )
                     );
                  this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               } else {
                  NetworkUtils.sendSequencedPacket(
                     seq -> new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK,
                        this.position,
                        WorldUtils.getClosestDirection(this.position, true),
                        seq
                     )
                  );
                  IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               }
            }

            if (this.this$0.isProxyActive() && this.startSlot != -1) {
               this.this$0.serverSend(new ServerboundSetCarriedItemPacket(this.startSlot));
               IMinecraft.mc.player.getInventory().setSelectedSlot(this.startSlot);
               this.startSlot = -1;
            }

            this.restoreIronSwap();
            this.progress = 0.0F;
            this.prevProgress = 0.0F;
            this.ghostIronProgress = 0.0F;
            this.ironSwapped = false;
            this.swappedIronInventorySlot = -1;
            this.swappedIronHotbarSlot = -1;
            this.attempts = 0;
            this.mining = false;
            this.started = false;
            this.instantMine = false;
         }
      }

      private void legacyCancel() {
         if (!this.this$0.doubleMine.getValue()) {
            Direction direction = WorldUtils.getClosestDirection(this.position, true);
            if (this.this$0.isProxyActive()) {
               this.this$0
                  .serverSendSequenced(
                     seq -> new ServerboundPlayerActionPacket(
                        net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, this.position, direction, seq
                     )
                  );
               this.this$0.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            } else {
               NetworkUtils.sendSequencedPacket(
                  seq -> new ServerboundPlayerActionPacket(
                     net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, this.position, direction, seq
                  )
               );
               IMinecraft.mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            }
         }

         if (this.this$0.isProxyActive()) {
            this.this$0.serverSend(new ServerboundSetCarriedItemPacket(IMinecraft.mc.player.getInventory().getSelectedSlot()));
         }

         this.restoreIronSwap();
         this.progress = 0.0F;
         this.prevProgress = 0.0F;
         this.ghostIronProgress = 0.0F;
         this.ironSwapped = false;
         this.swappedIronInventorySlot = -1;
         this.swappedIronHotbarSlot = -1;
         this.attempts = 0;
         this.mining = false;
         this.started = false;
         this.instantMine = false;
      }

      private float getSpeed() {
         return this.this$0.speed.getValue().floatValue();
      }

      private BlockPos grimDecoyPos() {
         return this.position.below(2000);
      }

      public int getTicksRemaining() {
         if (!this.mining) {
            return Integer.MAX_VALUE;
         } else if (this.this$0.sixB.getValue() && this.state.getBlock() == Blocks.BEDROCK) {
            float delta2 = 0.025F;
            return Math.max(0, Math.round((this.getSpeed() - this.progress) / delta2));
         } else {
            int bestToolSlot = InventoryUtils.findFastestItem(this.state, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END);
            if (bestToolSlot == -1) {
               bestToolSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
            }

            float delta;
            return (delta = WorldUtils.getMineSpeed(this.state, bestToolSlot) / Night.WORLD_MANAGER.getTimerMultiplier()) <= 0.0F
               ? Integer.MAX_VALUE
               : Math.max(0, Math.round((this.getSpeed() - this.progress) / delta));
         }
      }

      @Generated
      public float getPrevProgress() {
         return this.prevProgress;
      }

      @Generated
      public int getAttempts() {
         return this.attempts;
      }

      @Generated
      public long getStallTime() {
         return this.stallTime;
      }

      @Generated
      public int getStartSlot() {
         return this.startSlot;
      }

      @Generated
      public int getBrokenCount() {
         return this.brokenCount;
      }

      @Generated
      public int getLastBrokenCount() {
         return this.lastBrokenCount;
      }

      @Generated
      public Timer getInstantRemineResetTimer() {
         return this.instantRemineResetTimer;
      }

      @Generated
      public float getGhostIronProgress() {
         return this.ghostIronProgress;
      }

      @Generated
      public boolean isIronSwapped() {
         return this.ironSwapped;
      }

      @Generated
      public int getSwappedIronInventorySlot() {
         return this.swappedIronInventorySlot;
      }

      @Generated
      public int getSwappedIronHotbarSlot() {
         return this.swappedIronHotbarSlot;
      }

      @Generated
      public boolean isBedrockOrigin() {
         return this.bedrockOrigin;
      }

      @Generated
      public void setProgress(float progress) {
         this.progress = progress;
      }
   }

   public record Position(BlockPos position, boolean feetPosition) {
   }

   public class Secondary {
      private final BlockPos position;
      private final int priority;
      private BlockState state;
      private float progress;
      private float prevProgress;
      private int ticks;
      private boolean holding;
      private int holdTicks;
      final SpeedMineModule this$0;

      private Secondary(SpeedMineModule this$0, BlockPos position, int priority, BlockState state, float progress) {
         Objects.requireNonNull(SpeedMineModule.this);
         super();
         Objects.requireNonNull(this$0);
         this.this$0 = this$0;
         this.position = position;
         this.priority = priority;
         this.state = state;
         this.progress = progress;
         this.prevProgress = progress;
      }

      public BlockPos getPosition() {
         return this.position;
      }

      public int getPriority() {
         return this.priority;
      }

      public boolean isMining() {
         return true;
      }

      public boolean isHolding() {
         return this.holding;
      }

      public float getSpeed() {
         return 1.0F;
      }

      public float getProgress() {
         return Mth.clamp(this.progress, 0.0F, 1.0F);
      }

      public boolean process() {
         if (this.this$0.isOutOfRange(this.position)) {
            this.release();
            return true;
         } else {
            boolean clientEating = IMinecraft.mc.player != null && (IMinecraft.mc.player.isUsingItem() || EntityUtils.isEating());
            if (this.this$0.interactPaused && !clientEating && System.currentTimeMillis() - this.this$0.interactPausedAt >= 750L) {
               this.this$0.setInteractPaused(false);
            }

            BlockState current;
            if ((current = IMinecraft.mc.level.getBlockState(this.position)).canBeReplaced()) {
               Night.EVENT_HANDLER.post(new DestroyBlockEvent(this.position));
               this.this$0.mineTimer.reset();
               this.release();
               return true;
            } else {
               this.state = current;
               int bestSlot = InventoryUtils.findFastestItem(this.state, InventoryUtils.HOTBAR_START, InventoryUtils.HOTBAR_END);
               if (bestSlot == -1) {
                  bestSlot = IMinecraft.mc.player.getInventory().getSelectedSlot();
               }

               float delta;
               if ((delta = WorldUtils.getMineSpeed(this.state, bestSlot) / Night.WORLD_MANAGER.getTimerMultiplier()) <= 0.0F) {
                  this.release();
                  return true;
               } else {
                  this.ticks++;
                  this.prevProgress = this.progress;
                  this.progress += delta;
                  boolean canHold = this.this$0.whileEating.getValue() || !clientEating || this.this$0.switchMode.getValue().equalsIgnoreCase("None");
                  if (!this.holding && this.progress + delta >= 1.0F && canHold) {
                     this.hold(bestSlot);
                  }

                  if (this.holding && !this.this$0.farReach.getValue() && ++this.holdTicks >= 3) {
                     this.release();
                     return true;
                  } else if (this.progress >= 1.0F + delta * 10.0F) {
                     this.release();
                     return true;
                  } else if (this.ticks > 60) {
                     this.release();
                     return true;
                  } else {
                     return false;
                  }
               }
            }
         }
      }

      private void hold(int slot) {
         if (!this.this$0.switchMode.getValue().equalsIgnoreCase("None")) {
            int selected = IMinecraft.mc.player.getInventory().getSelectedSlot();
            this.holding = true;
            if (selected != slot) {
               this.this$0.secondaryOriginalSlot = selected;
               this.this$0.secondaryHoldSlot = slot;
               if (this.this$0.isProxyActive()) {
                  this.this$0.serverSend(new ServerboundSetCarriedItemPacket(slot));
               } else {
                  InventoryUtils.switchSlot(this.this$0.switchMode.getValue(), slot, selected);
               }
            }
         }
      }

      private void release() {
         if (this.holding) {
            this.holding = false;
            if (this.this$0.secondaryHoldSlot != -1) {
               int restore = this.this$0.secondaryOriginalSlot;
               int heldSlot = this.this$0.secondaryHoldSlot;
               this.this$0.secondaryHoldSlot = -1;
               this.this$0.secondaryOriginalSlot = -1;
               if (IMinecraft.mc.player != null) {
                  if (!this.this$0.switchMode.getValue().equalsIgnoreCase("Normal") || IMinecraft.mc.player.getInventory().getSelectedSlot() != restore) {
                     if (this.this$0.isProxyActive()) {
                        this.this$0.serverSend(new ServerboundSetCarriedItemPacket(restore));
                     } else {
                        InventoryUtils.switchBack(this.this$0.switchMode.getValue(), heldSlot, restore);
                     }
                  }
               }
            }
         }
      }

      public void render(PoseStack matrices) {
         if (!IMinecraft.mc.level.getBlockState(this.position).canBeReplaced()) {
            double p = Mth.clamp(Mth.lerp(IMinecraft.mc.getDeltaTracker().getGameTimeDeltaPartialTick(false), this.prevProgress, this.progress), 0.0F, 1.0F);
            AABB box = new AABB(this.position);
            if (this.this$0.animation.getValue().equalsIgnoreCase("Expand")) {
               box = new AABB(this.position).deflate(0.5).inflate(Mth.clamp(p / 2.0, 0.0, 0.5));
            }

            if (this.this$0.animation.getValue().equalsIgnoreCase("Rise")) {
               box = new AABB(
                  this.position.getX(),
                  this.position.getY(),
                  this.position.getZ(),
                  this.position.getX() + 1.0,
                  this.position.getY() + p,
                  this.position.getZ() + 1.0
               );
            }

            Color fill = this.this$0.fillColor.getColor();
            Color outline = this.this$0.outlineColor.getColor();
            if (this.this$0.color.getValue().equalsIgnoreCase("Static")) {
               fill = p >= 0.9 ? new Color(0, 255, 0, this.this$0.fillColor.getAlpha()) : new Color(255, 0, 0, this.this$0.fillColor.getAlpha());
               outline = p >= 0.9 ? new Color(0, 255, 0, this.this$0.outlineColor.getAlpha()) : new Color(255, 0, 0, this.this$0.outlineColor.getAlpha());
            } else if (this.this$0.color.getValue().equalsIgnoreCase("Smooth")) {
               fill = new Color(255 - (int)(p * 255.0), (int)(p * 255.0), 0, this.this$0.fillColor.getAlpha());
               outline = new Color(255 - (int)(p * 255.0), (int)(p * 255.0), 0, this.this$0.outlineColor.getAlpha());
            }

            if (this.this$0.render.getValue().equalsIgnoreCase("Fill") || this.this$0.render.getValue().equalsIgnoreCase("Both")) {
               Renderer3D.renderBox(matrices, box, fill);
            }

            if (this.this$0.render.getValue().equalsIgnoreCase("Outline") || this.this$0.render.getValue().equalsIgnoreCase("Both")) {
               Renderer3D.renderBoxOutline(matrices, box, outline);
            }
         }
      }

      @Generated
      public BlockState getState() {
         return this.state;
      }

      @Generated
      public float getPrevProgress() {
         return this.prevProgress;
      }

      @Generated
      public int getTicks() {
         return this.ticks;
      }

      @Generated
      public int getHoldTicks() {
         return this.holdTicks;
      }
   }

   public record Target(Player player, List<SpeedMineModule.Position> feetPositions, BlockPos position) {
   }
}
