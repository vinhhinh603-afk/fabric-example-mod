package night.modules.impl.player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.GrimV3Inventory;
import night.utils.minecraft.GrimV3Policy;
import night.utils.minecraft.HotbarKitIdentity;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.R26InventoryMath;

@RegisterModule(
   name = "Replenish",
   description = "Automatically replenishes stacks in your hotbar with new ones when they meet a specified threshold.",
   category = Module.Category.PLAYER
)
public class ReplenishModule extends Module {
   public ModeSetting switchMode;
   public NumberSetting threshold;
   public NumberSetting minimumCount;
   public BooleanSetting earlyRefill;
   public BooleanSetting keepInventoryStack;
   public BooleanSetting unstackable;
   public BooleanSetting inventory;
   public BooleanSetting slot1;
   public BooleanSetting slot2;
   public BooleanSetting slot3;
   public BooleanSetting slot4;
   public BooleanSetting slot5;
   public BooleanSetting slot6;
   public BooleanSetting slot7;
   public BooleanSetting slot8;
   public BooleanSetting slot9;
   public BooleanSetting debugRefill;
   private final ItemStack[] rememberedStacks;
   private Object rememberedPlayer;
   private Object rememberedLevel;
   private long lastRefillLog;
   private int ticks;
   private final Item[] hotbarItems;
   private final int[] hotbarCounts;
   private Map<Integer, List<Object>> rememberedKitLayout;
   public NumberSetting refillThresholdPercent = new NumberSetting(
      "RefillThresholdPercent", "Hotbar percentage at or below which refill starts (64/16 scaled).", 50, 0, 99
   );
   public NumberSetting donorMinimumPercent = new NumberSetting(
      "DonorMinimumPercent", "Minimum source stack percent, applies even when hotbar is empty. 0 accepts any nonempty source.", 0, 0, 100
   );
   public NumberSetting inventoryReserveCount = new NumberSetting(
      "InventoryReserveCount", "Items kept in each inventory source. Native full/half merges can leave more. Used when KeepInventoryStack is ON.", 1, 0, 64
   );
   public NumberSetting refillDelayMs = new NumberSetting(
      "RefillDelayMs", "Additional module delay, 0-2000 milliseconds. Existing inventory synchronization still applies.", 200, 0, 2000
   );
   private long nextRefillAt;
   private final boolean[] refillActive = new boolean[9];

   public boolean managesHotbarSlot(int slot) {
      return this.isToggled() && this.isSlotEnabled(slot);
   }

   private int findMatchingDonor(ItemStack expected, int minimum) {
      for (int source = 35; source >= 9; source--) {
         ItemStack donor = mc.player.getInventory().getItem(source);
         if (!donor.isEmpty() && donor.getCount() >= minimum && ItemStack.isSameItemSameComponents(expected, donor)) {
            return source;
         }
      }

      return -1;
   }

   private int playerMenuSlot(int inventoryIndex) {
      for (Slot slot : mc.player.containerMenu.slots) {
         if (slot.container == mc.player.getInventory() && slot.getContainerSlot() == inventoryIndex) {
            return slot.index;
         }
      }

      return -1;
   }

   private boolean isSlotEnabled(int slot) {
      return switch (slot) {
         case 0 -> this.slot1.getValue();
         case 1 -> this.slot2.getValue();
         case 2 -> this.slot3.getValue();
         case 3 -> this.slot4.getValue();
         case 4 -> this.slot5.getValue();
         case 5 -> this.slot6.getValue();
         case 6 -> this.slot7.getValue();
         case 7 -> this.slot8.getValue();
         case 8 -> this.slot9.getValue();
         default -> false;
      };
   }

   private boolean allSlotsEnabled() {
      for (int i = 0; i < 9; i++) {
         if (!this.isSlotEnabled(i)) {
            return false;
         }
      }

      return true;
   }

   private Map<Integer, List<Object>> captureKitLayout() {
      RekitModule rekit = Night.MODULE_MANAGER.getModule(RekitModule.class);
      if (rekit != null && !rekit.getActiveKit().isEmpty()) {
         Map<Integer, List<Object>> layout = new HashMap<>();

         for (int i = 0; i < 9; i++) {
            RekitModule.KitItem entry = rekit.getActiveKit().get(i);
            if (entry != null) {
               layout.put(i, Arrays.asList(entry.id, entry.name, entry.count, entry.maxCount));
            }
         }

         layout.put(-1, List.of(true));
         return layout;
      } else {
         return Map.of();
      }
   }

   private void rememberCurrentStacks() {
      if (mc.player != null) {
         RekitModule rekit = Night.MODULE_MANAGER.getModule(RekitModule.class);
         boolean hasKit = rekit != null && !rekit.getActiveKit().isEmpty();

         for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (hasKit) {
               RekitModule.KitItem entry = rekit.getActiveKit().get(i);
               Identifier id = entry != null && entry.id != null && entry.desiredCount() > 0 ? Identifier.tryParse(entry.id) : null;
               Item item = id == null ? null : (Item)BuiltInRegistries.ITEM.getValue(id);
               this.hotbarItems[i] = item;
               if (item == null || item == Items.AIR) {
                  this.rememberedStacks[i] = null;
               } else if (!stack.isEmpty() && stack.getItem() == item) {
                  this.rememberedStacks[i] = stack.copyWithCount(1);
               }
            } else if (!stack.isEmpty()) {
               this.rememberedStacks[i] = stack.copyWithCount(1);
               this.hotbarItems[i] = stack.getItem();
            }
         }
      }
   }

   public ReplenishModule() {
      this.switchMode = new ModeSetting(
         "Switch", "Legacy switch mode; reserve or active-kit refill uses bounded Pickup merge/return.", "Swap", new String[]{"Pickup", "Swap", "Quick"}
      );
      this.threshold = new NumberSetting("Threshold", "The minimum amount of items in a stack before that stack is replaced.", 12, 1, 64);
      this.minimumCount = new NumberSetting("MinimumCount", "The minimum amount of items that should be in the new stack.", 48, 1, 64);
      this.earlyRefill = new BooleanSetting("EarlyRefill", "Refill selected hotbar stacks at half capacity or the configured higher threshold.", true);
      this.keepInventoryStack = new BooleanSetting(
         "KeepInventoryStack",
         "Merge missing hotbar items and return overflow to source; never empty an inventory donor. DonorMinimumPercent and InventoryReserveCount apply.",
         true
      );
      this.unstackable = new BooleanSetting(
         "Unstackable", "Legacy setting retained for saved configs; Replenish now refills stackable items only, never totems.", false
      );
      this.inventory = new BooleanSetting("Inventory", "Allow refill in your own inventory screen; never use shop/chest slots as donors.", false);
      this.slot1 = new BooleanSetting("Slot1", "Replenish hotbar slot 1.", true);
      this.slot2 = new BooleanSetting("Slot2", "Replenish hotbar slot 2.", true);
      this.slot3 = new BooleanSetting("Slot3", "Replenish hotbar slot 3.", true);
      this.slot4 = new BooleanSetting("Slot4", "Replenish hotbar slot 4.", true);
      this.slot5 = new BooleanSetting("Slot5", "Replenish hotbar slot 5.", true);
      this.slot6 = new BooleanSetting("Slot6", "Replenish hotbar slot 6.", true);
      this.slot7 = new BooleanSetting("Slot7", "Replenish hotbar slot 7.", true);
      this.slot8 = new BooleanSetting("Slot8", "Replenish hotbar slot 8.", true);
      this.slot9 = new BooleanSetting("Slot9", "Replenish hotbar slot 9.", true);
      this.debugRefill = new BooleanSetting("DebugRefill", "Log refill decisions at most once every two seconds.", false);
      this.rememberedStacks = new ItemStack[9];
      this.hotbarItems = new Item[9];
      this.hotbarCounts = new int[9];
      this.switchMode.getVisibility().setVisible(false);
      this.threshold.getVisibility().setVisible(false);
      this.minimumCount.getVisibility().setVisible(false);
      this.earlyRefill.getVisibility().setVisible(false);
      this.unstackable.getVisibility().setVisible(false);
   }

   @Override
   public void onEnable() {
      this.rememberedPlayer = null;
      this.rememberedLevel = null;
      this.refreshContext();
      this.rememberCurrentStacks();
   }

   private void refreshContext() {
      Map var1 = this.captureKitLayout();
      if (this.rememberedPlayer != mc.player || this.rememberedLevel != mc.level || !Objects.equals(this.rememberedKitLayout, var1)) {
         this.rememberedPlayer = mc.player;
         this.rememberedLevel = mc.level;
         this.rememberedKitLayout = var1;
         Arrays.fill(this.hotbarItems, null);
         Arrays.fill(this.hotbarCounts, 0);
         Arrays.fill(this.rememberedStacks, null);
         Arrays.fill(this.refillActive, false);
         this.ticks = 0;
         this.nextRefillAt = 0L;
      }
   }

   private void logRefill(String var1) {
      long var2 = System.currentTimeMillis();
      if (this.debugRefill.getValue() && var2 - this.lastRefillLog >= 2000L) {
         this.lastRefillLog = var2;
         System.out
            .println(
               "[Replenish] player="
                  + (mc.player == null ? "none" : mc.player.getName().getString())
                  + " triggerPercent="
                  + this.refillThresholdPercent.getValue()
                  + " donorMinimumPercent="
                  + this.donorMinimumPercent.getValue()
                  + " reserve="
                  + this.inventoryReserveCount.getValue()
                  + " delayMs="
                  + this.refillDelayMs.getValue()
                  + " "
                  + var1
            );
      }
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent var1) {
      this.refreshContext();
      if (GrimV3Inventory.enabled()) {
         this.grimTick();
      } else if (!GrimV3Inventory.routineBlocked()) {
         this.rememberCurrentStacks();
         this.legacyUpdate(var1);
      }
   }

   private void grimTick() {
      if (System.currentTimeMillis() >= this.nextRefillAt) {
         if (!GrimV3Inventory.canPlan()) {
            this.logRefill("WAIT inventory transaction/shop/use/unsafe context");
         } else {
            this.rememberCurrentStacks();
            List var1 = this.findRefillPlan();
            if (!var1.isEmpty()) {
               if (GrimV3Inventory.submit(this, var1)) {
                  this.nextRefillAt = System.currentTimeMillis() + this.refillDelayMs.getValue().longValue();
                  this.logRefill("SUBMIT " + var1);
               }
            } else {
               for (int var2 = 0; var2 < 9; var2++) {
                  ItemStack var3 = mc.player.getInventory().getItem(var2);
                  if (!var3.isEmpty()) {
                     this.hotbarItems[var2] = var3.getItem();
                  }

                  this.hotbarCounts[var2] = var3.getCount();
               }
            }
         }
      }
   }

   public boolean hasReadyRefill() {
      this.refreshContext();
      return this.isToggled() && GrimV3Inventory.enabled() && System.currentTimeMillis() >= this.nextRefillAt && !this.findRefillPlan().isEmpty();
   }

   private List<GrimV3Inventory.Click> findRefillPlan() {
      if (mc.player != null && mc.level != null) {
         RekitModule var1 = Night.MODULE_MANAGER.getModule(RekitModule.class);
         boolean var2 = var1 != null && !var1.getActiveKit().isEmpty();
         ArrayList var3 = new ArrayList();

         for (int var4 = 0; var4 < 9; var4++) {
            if (this.isSlotEnabled(var4)) {
               var3.add(var4);
            }
         }

         var3.sort((var1x, var2x) -> {
            ItemStack var3x = mc.player.getInventory().getItem(var1x);
            ItemStack var4x = mc.player.getInventory().getItem(var2x);
            int var5x = var3x.isEmpty() && this.rememberedStacks[var1x] != null ? this.rememberedStacks[var1x].getMaxStackSize() : var3x.getMaxStackSize();
            int var6x = var4x.isEmpty() && this.rememberedStacks[var2x] != null ? this.rememberedStacks[var2x].getMaxStackSize() : var4x.getMaxStackSize();
            return Integer.compare(var3x.getCount() * Math.max(1, var6x), var4x.getCount() * Math.max(1, var5x));
         });

         for (int var5 : var3) {
            ItemStack var6 = mc.player.getInventory().getItem(var5);
            Item var7 = this.hotbarItems[var5];
            if (this.isSlotEnabled(var5)) {
               RekitModule.KitItem var8 = var2 ? var1.getActiveKit().get(var5) : null;
               if (!var2 || var8 != null && var8.id != null && !var8.id.isBlank() && var8.desiredCount() > 0) {
                  String var9 = HotbarKitIdentity.resolve(
                     var2,
                     var8 == null ? null : var8.id,
                     var6.isEmpty() ? null : BuiltInRegistries.ITEM.getKey(var6.getItem()).toString(),
                     var7 != null && var7 != Items.AIR ? BuiltInRegistries.ITEM.getKey(var7).toString() : null
                  );
                  Identifier var10 = var9 == null ? null : Identifier.tryParse(var9);
                  Item var11 = var10 == null ? null : (Item)BuiltInRegistries.ITEM.getValue(var10);
                  if (var11 != null && var11 != Items.AIR && (var6.isEmpty() || var6.getItem() == var11)) {
                     ItemStack var12 = this.rememberedStacks[var5];
                     boolean var13 = !var6.isEmpty() || var12 != null && var12.getItem() == var11;
                     ItemStack var14 = !var6.isEmpty() ? var6 : (var13 ? var12 : new ItemStack(var11));
                     if (GrimV3Policy.stackRefill(var11 == Items.TOTEM_OF_UNDYING, var14.getMaxStackSize())) {
                        int var15 = var14.getMaxStackSize();
                        if (var6.getCount() < var15) {
                           int var16 = R26InventoryMath.percent(var14.getMaxStackSize(), this.refillThresholdPercent.getValue().intValue());
                           if (var6.getCount() <= var16) {
                              this.refillActive[var5] = true;
                           }

                           if (this.refillActive[var5]) {
                              int var17 = R26InventoryMath.percent(var14.getMaxStackSize(), this.donorMinimumPercent.getValue().intValue());
                              ArrayList var18 = new ArrayList();

                              for (int var19 = 9; var19 < 36; var19++) {
                                 var18.add(var19);
                              }

                              var18.sort(
                                 (var0, var1x) -> Integer.compare(
                                    mc.player.getInventory().getItem(var1x).getCount(), mc.player.getInventory().getItem(var0).getCount()
                                 )
                              );

                              for (int var20 : var18) {
                                 ItemStack var21 = mc.player.getInventory().getItem(var20);
                                 if (!var21.isEmpty()
                                    && var21.getItem() == var11
                                    && var21.getCount() >= Math.max(1, var17)
                                    && (!var13 || ItemStack.isSameItemSameComponents(var14, var21))) {
                                    int var22 = 36 + var5;
                                    RekitModule.KitItem var23 = var2 ? var1.getActiveKit().get(var20) : null;
                                    if (!var2 || var23 != null && this.matchesKit(var21, var23)) {
                                       int var24 = this.keepInventoryStack.getValue() ? this.inventoryReserveCount.getValue().intValue() : 0;
                                       int var25 = R26InventoryMath.strategy(var21.getCount(), var6.getCount(), var15, var24);
                                       if (var25 != 0 && (var25 != 1 || var15 >= var14.getMaxStackSize() || var21.getCount() <= var15 - var6.getCount())) {
                                          ArrayList var26 = new ArrayList();
                                          var26.add(new GrimV3Inventory.Click(var20, var25 == 2 ? 1 : 0, ContainerInput.PICKUP));
                                          var26.add(new GrimV3Inventory.Click(var22, 0, ContainerInput.PICKUP));
                                          int var27 = var25 == 2 ? (var21.getCount() + 1) / 2 : var21.getCount();
                                          if (var27 > var15 - var6.getCount()) {
                                             var26.add(new GrimV3Inventory.Click(var20, 0, ContainerInput.PICKUP));
                                          }

                                          this.logRefill(
                                             "PLAN slot="
                                                + (var5 + 1)
                                                + " source="
                                                + var20
                                                + " sourceCount="
                                                + var21.getCount()
                                                + " hotbar="
                                                + var6.getCount()
                                                + " trigger="
                                                + var16
                                                + " minimum="
                                                + var17
                                                + " strategy="
                                                + var25
                                          );
                                          return var26;
                                       }
                                    }
                                 }
                              }
                           }
                        } else {
                           this.refillActive[var5] = false;
                        }
                     }
                  }
               }
            }
         }

         this.logRefill("NO_PLAN threshold/reserve/kit/components/no donor");
         return List.of();
      } else {
         return List.of();
      }
   }

   public boolean ownsReserveSlot(int var1) {
      return this.managesHotbarSlot(var1);
   }

   public List<GrimV3Inventory.Click> repairKitSlot(int var1) {
      return List.of();
   }

   private void legacyUpdate(PlayerUpdateEvent var1) {
      if (mc.player != null
         && mc.level != null
         && mc.gameMode != null
         && mc.player.containerMenu == mc.player.inventoryMenu
         && mc.player.containerMenu.getCarried().isEmpty()
         && !InventoryUtils.hasActiveSilentSwitch()
         && System.currentTimeMillis() >= this.nextRefillAt) {
         AutoShopModule var2 = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
         if (var2 == null || !var2.isRunning()) {
            if (mc.gui.screen() == null || this.inventory.getValue() && mc.gui.screen() instanceof InventoryScreen) {
               List var3 = this.findRefillPlan();
               if (!var3.isEmpty()) {
                  for (GrimV3Inventory.Click var5 : var3) {
                     mc.gameMode.handleContainerInput(mc.player.inventoryMenu.containerId, var5.slot(), var5.button(), var5.type(), mc.player);
                  }

                  this.nextRefillAt = System.currentTimeMillis() + this.refillDelayMs.getValue().longValue();
               }
            }
         }
      }
   }

   @Override
   public String getMetaData() {
      return this.refillThresholdPercent.getValue().intValue() + "%";
   }

   private boolean matchesKit(ItemStack var1, RekitModule.KitItem var2) {
      return var2 != null && var2.id != null && var2.id.equals(BuiltInRegistries.ITEM.getKey(var1.getItem()).toString());
   }
}
