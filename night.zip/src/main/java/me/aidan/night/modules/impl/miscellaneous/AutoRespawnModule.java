package night.modules.impl.miscellaneous;

import night.modules.Module;
import night.modules.RegisterModule;

@RegisterModule(
   name = "AutoRespawn",
   description = "Makes it so that you respawn immediately after dying.",
   category = Module.Category.MISCELLANEOUS
)
public class AutoRespawnModule extends Module {
}
