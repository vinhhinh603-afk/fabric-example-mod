package night.modules.impl.movement;

import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import night.events.SubscribeEvent;
import night.events.impl.PlayerMoveEvent;
import night.modules.Module;
import night.modules.RegisterModule;

@RegisterModule(
   name = "AntiVoid",
   description = "Prevents you from falling into the void.",
   category = Module.Category.MOVEMENT
)
public class AntiVoidModule extends Module {
   @SubscribeEvent
   public void onPlayerMove(PlayerMoveEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.falling()) {
            event.setCancelled(true);
            event.setMovement(new Vec3(event.getMovement().x, 0.0, event.getMovement().z));
            mc.getConnection().send(new Pos(mc.player.getX(), mc.player.getY(), mc.player.getZ(), true, mc.player.horizontalCollision));
         }
      }
   }

   private boolean falling() {
      if (mc.player != null && mc.level != null) {
         int minY = mc.level.getMinY();

         for (int i = (int)mc.player.getY(); i >= minY; i--) {
            BlockPos pos = BlockPos.containing(mc.player.getX(), i, mc.player.getZ());
            BlockState state = mc.level.getBlockState(pos);
            if (!state.isAir() && !state.getCollisionShape(mc.level, pos).isEmpty()) {
               return false;
            }
         }

         return mc.player.fallDistance > 0.0;
      } else {
         return false;
      }
   }
}
