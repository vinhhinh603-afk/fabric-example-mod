package night.modules.impl.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import night.events.SubscribeEvent;
import night.events.impl.EntitySpawnEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.RenderWorldEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.CategorySetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.NumberSetting;
import night.utils.IMinecraft;
import night.utils.animations.Animation;
import night.utils.animations.Easing;
import night.utils.graphics.Renderer2D;

@RegisterModule(
   name = "Icons",
   description = "Renders icons for specific events.",
   category = Module.Category.VISUALS
)
public class IconsModule extends Module {
   public CategorySetting chorusCategory = new CategorySetting("Chorus", "The category for chorus icons.");
   public BooleanSetting chorus = new BooleanSetting(
      "Chorus", "Enabled", "Renders an icon for chorus positions.", new CategorySetting.Visibility(this.chorusCategory), true
   );
   public ColorSetting chorusColor = new ColorSetting(
      "ChorusColor",
      "Color",
      "The color for the chorus icons.",
      new CategorySetting.Visibility(this.chorusCategory),
      new ColorSetting.Color(new Color(192, 147, 212), false, false)
   );
   public NumberSetting duration = new NumberSetting(
      "Duration", "The duration of icon renders.", new CategorySetting.Visibility(this.chorusCategory), 1500, 0, 5000
   );
   public CategorySetting pearlsCategory = new CategorySetting("Pearls", "The category for pearl icons.");
   public BooleanSetting pearls = new BooleanSetting(
      "Pearls", "Enabled", "Renders an icon for pearl positions.", new CategorySetting.Visibility(this.pearlsCategory), true
   );
   public ColorSetting pearlsColor = new ColorSetting(
      "PearlsColor",
      "Color",
      "The color for the pearl icons.",
      new CategorySetting.Visibility(this.pearlsCategory),
      new ColorSetting.Color(new Color(30, 131, 89), false, false)
   );
   public NumberSetting scale = new NumberSetting("Scale", "The scaling that will be applied to the text ESP rendering.", 40, 10, 50);
   private final ArrayList<IconsModule.Icon> iconList = new ArrayList<>();
   private final Map<IconsModule.Icon, Integer> pearlMap = new HashMap<>();

   @SubscribeEvent
   public void onEntitySpawn(EntitySpawnEvent event) {
      if (!this.getNull()) {
         ArrayList<IconsModule.Icon> arrayList = this.iconList;
         synchronized (arrayList) {
            if (event.getEntity() instanceof ThrownEnderpearl pearl) {
               mc.level.players().stream().min(Comparator.comparingDouble(p -> p.distanceTo(pearl))).ifPresent(player -> {
                  Vec3 landing = this.projectPearl(pearl.position(), player.getYRot(), player.getXRot(), player.getDeltaMovement());
                  if (landing != null) {
                     IconsModule.Icon icon = new IconsModule.Icon(this, new Vec3(landing.x, landing.y, landing.z), IconsModule.Icon.Type.PEARL);
                     this.pearlMap.put(icon, pearl.getId());
                     this.iconList.add(icon);
                  }
               });
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (!this.getNull()) {
         ArrayList<IconsModule.Icon> arrayList = this.iconList;
         synchronized (arrayList) {
            Packet<?> packet2 = event.getPacket();
            ClientboundSoundPacket packet;
            SoundEvent sound;
            if (packet2 instanceof ClientboundSoundPacket
               && (
                  (sound = (SoundEvent)(packet = (ClientboundSoundPacket)packet2).getSound().value()) == SoundEvents.CHORUS_FRUIT_TELEPORT
                     || sound == SoundEvents.ENDERMAN_TELEPORT
               )) {
               this.iconList.add(new IconsModule.Icon(this, new Vec3(packet.getX(), packet.getY(), packet.getZ()), IconsModule.Icon.Type.CHORUS));
            }
         }
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (!this.getNull()) {
         PoseStack matrices = event.getMatrices();
         ArrayList<IconsModule.Icon> arrayList = this.iconList;
         synchronized (arrayList) {
            this.iconList
               .removeIf(
                  icon -> icon.type == IconsModule.Icon.Type.CHORUS && System.currentTimeMillis() - icon.time >= this.duration.getValue().intValue() + 1200
                     || icon.type == IconsModule.Icon.Type.PEARL
                        && !(mc.level.getEntity(this.pearlMap.get(icon)) instanceof ThrownEnderpearl)
                        && icon.animation.value() == 0.0F
               );
            if (this.chorus.getValue()) {
               for (IconsModule.Icon icon2 : this.iconList.stream().filter(icon -> icon.type == IconsModule.Icon.Type.CHORUS).toList()) {
                  icon2.render(
                     matrices,
                     System.currentTimeMillis() - icon2.time >= 600 + this.duration.getValue().intValue() ? 0.0F : 1.0F,
                     () -> Renderer2D.renderTexture(
                        matrices, -6.0F, -6.5F, 6.0F, 6.5F, Identifier.fromNamespaceAndPath("night", "textures/chorus.png"), Color.WHITE
                     ),
                     this.chorusColor.getColor()
                  );
               }
            }

            if (this.pearls.getValue()) {
               for (IconsModule.Icon icon2 : this.iconList.stream().filter(icon -> icon.type == IconsModule.Icon.Type.PEARL).toList()) {
                  icon2.render(
                     matrices,
                     !(mc.level.getEntity(this.pearlMap.get(icon2)) instanceof ThrownEnderpearl) ? 0.0F : 1.0F,
                     () -> Renderer2D.renderTexture(
                        matrices, -6.5F, -6.5F, 6.5F, 6.5F, Identifier.fromNamespaceAndPath("night", "textures/pearl.png"), Color.WHITE
                     ),
                     this.pearlsColor.getColor()
                  );
               }
            }
         }
      }
   }

   private Vec3 projectPearl(Vec3 vec3d, float yaw, float pitch, Vec3 velocity) {
      double x = vec3d.x;
      double y = vec3d.y;
      double z = vec3d.z;
      y = y + mc.player.getEyeHeight(mc.player.getPose()) - 0.1000000014901161;
      float maxDistance = 0.4F;
      double motionX = -Mth.sin(yaw / 180.0F * (float) Math.PI) * Mth.cos(pitch / 180.0F * (float) Math.PI) * maxDistance;
      double motionY = -Mth.sin(pitch / 180.0F * 3.141593F) * maxDistance;
      double motionZ = Mth.cos(yaw / 180.0F * (float) Math.PI) * Mth.cos(pitch / 180.0F * (float) Math.PI) * maxDistance;
      float distance = Mth.sqrt((float)(motionX * motionX + motionY * motionY + motionZ * motionZ));
      motionX /= distance;
      motionY /= distance;
      motionZ /= distance;
      float pow = 1.5F;
      motionX *= pow;
      motionY *= pow;
      motionZ *= pow;
      motionX += velocity.x;
      motionY += velocity.y;
      motionZ += velocity.z;

      while (y > -65.0) {
         Vec3 lastPosition = new Vec3(x, y, z);
         if (mc.level.getBlockState(new BlockPos((int)(x += motionX), (int)(y += motionY), (int)(z += motionZ))).getBlock() == Blocks.WATER) {
            motionX *= 0.8;
            motionY *= 0.8;
            motionZ *= 0.8;
         } else {
            motionX *= 0.99;
            motionY *= 0.99;
            motionZ *= 0.99;
         }

         motionY -= 0.03F;
         Vec3 position = new Vec3(x, y, z);

         for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity != mc.player
               && !(entity instanceof Arrow)
               && !(entity instanceof ThrownEnderpearl)
               && entity.getBoundingBox().intersects(new AABB(x - 1.0, y - 1.0, z - 1.0, x + 1.0, y + 1.0, z + 1.0))) {
               return entity.getBoundingBox().getCenter();
            }
         }

         BlockHitResult possibleResult = mc.level.clip(new ClipContext(lastPosition, position, Block.OUTLINE, Fluid.NONE, mc.player));
         if (possibleResult != null && possibleResult.getType() != net.minecraft.world.phys.HitResult.Type.MISS) {
            return possibleResult.getLocation();
         }
      }

      return null;
   }

   private class Icon {
      private final Vec3 pos;
      private final Animation animation;
      private final IconsModule.Icon.Type type;
      private final long time;
      final IconsModule this$0;

      public Icon(IconsModule iconsModule, Vec3 pos, IconsModule.Icon.Type type) {
         Objects.requireNonNull(IconsModule.this);
         super();
         Objects.requireNonNull(iconsModule);
         this.this$0 = iconsModule;
         this.pos = pos;
         this.animation = new Animation(0.0F, 1.0F, 600, Easing.Method.EASE_IN_OUT_ELASTIC);
         this.type = type;
         this.time = System.currentTimeMillis();
      }

      private void render(PoseStack matrices, float target, Runnable runnable, Color color) {
         float progress = this.animation.get(target);
         float distance = (float)Math.sqrt(IMinecraft.mc.gameRenderer.mainCamera().position().distanceToSqr(this.pos.x, this.pos.y, this.pos.z));
         float scaling = 0.0018F + this.this$0.scale.getValue().floatValue() / 10000.0F * distance;
         if (distance <= 4.0) {
            scaling = 0.0245F;
         }

         Vec3 vec3d = new Vec3(
            this.pos.x - IMinecraft.mc.gameRenderer.mainCamera().position().x,
            this.pos.y - IMinecraft.mc.gameRenderer.mainCamera().position().y,
            this.pos.z - IMinecraft.mc.gameRenderer.mainCamera().position().z
         );
         matrices.pushPose();
         matrices.translate(vec3d.x, vec3d.y, vec3d.z);
         matrices.mulPose(IMinecraft.mc.gameRenderer.mainCamera().rotation());
         matrices.scale(scaling, -scaling, scaling);
         matrices.scale(progress, progress, 1.0F);
         Renderer2D.renderCircle(matrices, 0.0F, 0.0F, 12.0F, new Color(0, 0, 0, 100));
         Renderer2D.renderCircle(matrices, 0.0F, 0.0F, 10.0F, color);
         runnable.run();
         matrices.popPose();
      }

      @Generated
      public Vec3 getPos() {
         return this.pos;
      }

      @Generated
      public Animation getAnimation() {
         return this.animation;
      }

      @Generated
      public IconsModule.Icon.Type getType() {
         return this.type;
      }

      @Generated
      public long getTime() {
         return this.time;
      }

      public static enum Type {
         CHORUS,
         PEARL;
      }
   }
}
