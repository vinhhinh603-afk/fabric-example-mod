package night.modules.impl.movement;

import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import night.Night;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.api.ISprintModule;
import night.modules.impl.combat.SoloBotModule;
import night.modules.impl.player.MultiTaskModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.utils.minecraft.BotPearlAccess;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.NetworkUtils;

@RegisterModule(
   name = "Phase",
   description = "Throws an ender pearl to phase into blocks. KingMC Crawl mode requires crawling away from the target block before throwing.",
   category = Module.Category.MOVEMENT
)
public class PhaseModule extends Module {
   public ModeSetting logic = new ModeSetting(
      "Logic",
      "Phase bypass targeting logic: KingMC (bedrock = Grim behavior, crawl requires crawling away from block before throwing), Grim, or NCP.",
      "KingMC",
      new String[]{"KingMC", "Grim", "NCP"}
   );
   public ModeSetting swap = new ModeSetting(
      "Swap", "The mode that will be used for switching to the pearl before throwing it.", "Silent", InventoryUtils.SWITCH_MODES
   );
   public BooleanSetting crawl = new BooleanSetting("Crawl", "Crawl phase mode. In KingMC mode, crawl away from the target block before throwing.", false);
   public BooleanSetting antiVoid = new BooleanSetting("AntiVoid", "Prevents phasing into or through blocks that lead directly into the void.", true);
   public BooleanSetting debug = new BooleanSetting(
      "Debug", "Chat-prints pos/yaw/pitch/target for every throw, so a failed (popped-up) attempt can be matched back to its exact numbers.", false
   );
   private Float requestedYaw;
   public ModeSetting ncpMode = new ModeSetting(
      "NCP-Mode",
      "Item used to bypass pearl distance checks on NCP.",
      new ModeSetting.Visibility(this.logic, "NCP"),
      "FireCharge",
      new String[]{"FireCharge", "FlintAndSteel", "Cobweb"}
   );
   public ModeSetting bypassSwitch = new ModeSetting(
      "Switch",
      "The mode that will be used for switching to the bypass item.",
      new ModeSetting.Visibility(this.logic, "NCP"),
      "Silent",
      new String[]{"Normal", "Silent", "AltPickup", "AltSwap"}
   );
   public BooleanSetting autoRemove = new BooleanSetting(
      "AutoRemove", "Automatically removes the bypass block/fire once you have phased.", new ModeSetting.Visibility(this.logic, "NCP"), true
   );
   private static final double CORNER_THRESHOLD = 0.5;
   private static final double CORNER_OFFSET = 0.5;
   private int attempt = 0;

   public void phaseTowards(float yaw) {
      if (!this.isToggled()) {
         this.requestedYaw = yaw;

         try {
            this.setToggled(true);
         } finally {
            this.requestedYaw = null;
         }
      }
   }

   private boolean isInWeb(Entity entity) {
      if (entity.getInBlockState().is(Blocks.COBWEB)) {
         return true;
      } else {
         for (BlockPos pos : BlockPos.betweenClosed(
            BlockPos.containing(entity.getBoundingBox().minX, entity.getBoundingBox().minY, entity.getBoundingBox().minZ),
            BlockPos.containing(entity.getBoundingBox().maxX, entity.getBoundingBox().maxY, entity.getBoundingBox().maxZ)
         )) {
            if (entity.level().getBlockState(pos).is(Blocks.COBWEB)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean isInLadder(Entity entity) {
      if (entity.getInBlockState().is(Blocks.LADDER)) {
         return true;
      } else {
         for (BlockPos pos : BlockPos.betweenClosed(
            BlockPos.containing(entity.getBoundingBox().minX, entity.getBoundingBox().minY, entity.getBoundingBox().minZ),
            BlockPos.containing(entity.getBoundingBox().maxX, entity.getBoundingBox().maxY, entity.getBoundingBox().maxZ)
         )) {
            if (entity.level().getBlockState(pos).is(Blocks.LADDER)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean isPlayerCrawling() {
      return mc.player == null ? false : mc.player.getPose() == Pose.SWIMMING || mc.player.isVisuallyCrawling() || mc.player.getEyeHeight() <= 1.0F;
   }

   private float getPhaseYaw() {
      if (this.requestedYaw != null) {
         return this.requestedYaw;
      } else if (mc.player == null) {
         return 0.0F;
      } else {
         float realYaw = mc.player.getYRot();
         ISprintModule sprint;
         if (Night.MODULE_MANAGER != null && (sprint = (ISprintModule)Night.MODULE_MANAGER.getModule("Sprint")) != null && sprint.isGrimCompensating()) {
            return sprint.getGrimYaw();
         } else {
            int inputX = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
            int inputZ = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
            if (inputX == 0 && inputZ == 0) {
               return realYaw;
            } else {
               float moveAngle = (float)Math.toDegrees(Math.atan2(inputX, inputZ));
               return Mth.wrapDegrees(realYaw + moveAngle);
            }
         }
      }
   }

   private boolean isOnBedrock() {
      if (mc.player != null && mc.level != null) {
         double minY = mc.player.getBoundingBox().minY;
         BlockPos below = BlockPos.containing(mc.player.getX(), minY - 0.1, mc.player.getZ());
         if (mc.level.getBlockState(below).is(Blocks.BEDROCK)) {
            return true;
         } else {
            return mc.level.getBlockState(mc.player.blockPosition().below()).is(Blocks.BEDROCK)
               ? true
               : mc.level.getBlockState(mc.player.blockPosition()).is(Blocks.BEDROCK);
         }
      } else {
         return false;
      }
   }

   private Vec3 calculateKingMCStandingTarget(float rawYaw) {
      double px = mc.player.getX();
      double py = mc.player.getY();
      double pz = mc.player.getZ();
      double yawRad = Math.toRadians(rawYaw);
      Vec3 lookDir = new Vec3(-Math.sin(yawRad), 0.0, Math.cos(yawRad)).normalize();
      float mod90 = (rawYaw % 90.0F + 90.0F) % 90.0F;
      boolean nearCardinal = Math.min(mod90, 90.0F - mod90) < 22.5F;
      double SAFE_OFFSET = 0.165;
      if (nearCardinal) {
         boolean zAxis = Math.abs(lookDir.z) > Math.abs(lookDir.x);
         if (zAxis) {
            double boundaryZ = lookDir.z > 0.0 ? Math.floor(pz) + 1.0 : Math.floor(pz);
            double targetZ = lookDir.z > 0.0 ? boundaryZ - 0.165 : boundaryZ + 0.165;
            return new Vec3(px, py, targetZ);
         } else {
            double boundaryX = lookDir.x > 0.0 ? Math.floor(px) + 1.0 : Math.floor(px);
            double targetX = lookDir.x > 0.0 ? boundaryX - 0.165 : boundaryX + 0.165;
            return new Vec3(targetX, py, pz);
         }
      } else {
         double boundaryX = lookDir.x > 0.0 ? Math.floor(px) + 1.0 : Math.floor(px);
         double boundaryZ = lookDir.z > 0.0 ? Math.floor(pz) + 1.0 : Math.floor(pz);
         double targetX = lookDir.x > 0.0 ? boundaryX - 0.165 : boundaryX + 0.165;
         double targetZ = lookDir.z > 0.0 ? boundaryZ - 0.165 : boundaryZ + 0.165;
         return new Vec3(targetX, py, targetZ);
      }
   }

   private Vec3 calculateKingMCCrawlTarget(float rawYaw) {
      Vec3 eyePos = this.getEffectiveEyePos();
      float cameraYaw;
      double camYawRad;
      Vec3 camLookDir;
      BlockHitResult hit = mc.level
         .clip(
            new ClipContext(
               eyePos,
               eyePos.add(
                  (camLookDir = new Vec3(-Math.sin(camYawRad = Math.toRadians(cameraYaw = mc.player.getYRot())), 0.0, Math.cos(camYawRad)).normalize())
                     .scale(4.0)
               ),
               Block.COLLIDER,
               Fluid.NONE,
               mc.player
            )
         );
      Vec3 lookDir;
      if (hit != null && hit.getType() == Type.BLOCK) {
         rawYaw = cameraYaw;
         lookDir = camLookDir;
      } else {
         double yawRad = Math.toRadians(rawYaw);
         lookDir = new Vec3(-Math.sin(yawRad), 0.0, Math.cos(yawRad)).normalize();
         hit = mc.level.clip(new ClipContext(eyePos, eyePos.add(lookDir.scale(4.0)), Block.COLLIDER, Fluid.NONE, mc.player));
      }

      BlockPos targetBlock = null;
      Direction hitSide = null;
      Vec3 hitPos = null;
      if (hit != null && hit.getType() == Type.BLOCK) {
         targetBlock = hit.getBlockPos();
         hitSide = hit.getDirection();
         hitPos = hit.getLocation();
      } else {
         Direction facing = Direction.fromYRot(rawYaw);
         targetBlock = mc.player.blockPosition().relative(facing, 1);
         hitSide = facing.getOpposite();
      }

      double targetY = targetBlock.getY() + 0.52;
      float mod90 = (rawYaw % 90.0F + 90.0F) % 90.0F;
      boolean nearCardinal = Math.min(mod90, 90.0F - mod90) < 22.5F;
      if (nearCardinal && hitSide != null && hitSide.getAxis().isHorizontal()) {
         double targetX;
         double targetZ;
         if (hitSide.getAxis() == Axis.Z) {
            targetZ = hitSide == Direction.NORTH ? targetBlock.getZ() : targetBlock.getZ() + 1.0;
            targetX = hitPos != null && Math.abs(hitPos.x - Math.round(hitPos.x)) < 0.25 ? Math.round(hitPos.x) : targetBlock.getX() + 0.5;
         } else {
            targetX = hitSide == Direction.WEST ? targetBlock.getX() : targetBlock.getX() + 1.0;
            targetZ = hitPos != null && Math.abs(hitPos.z - Math.round(hitPos.z)) < 0.25 ? Math.round(hitPos.z) : targetBlock.getZ() + 0.5;
         }

         return new Vec3(targetX, targetY, targetZ);
      } else {
         double seamZ;
         double seamX;
         if (hitPos != null) {
            seamX = Math.round(hitPos.x);
            seamZ = Math.round(hitPos.z);
         } else {
            seamX = Math.round(mc.player.getX() + lookDir.x);
            seamZ = Math.round(mc.player.getZ() + lookDir.z);
         }

         return new Vec3(seamX, targetY, seamZ);
      }
   }

   private Vec3 calculateTargetPos() {
      double playerX = mc.player.getX();
      double playerZ = mc.player.getZ();
      double y = this.crawl.getValue() && this.isPlayerCrawling() ? mc.player.blockPosition().below().getY() : mc.player.getY() - 0.5;
      double nearestIntX = Math.round(playerX);
      double nearestIntZ = Math.round(playerZ);
      double dxCorner = nearestIntX - playerX;
      double dzCorner = nearestIntZ - playerZ;
      if (Math.abs(dxCorner) <= 0.5 && Math.abs(dzCorner) <= 0.5) {
         return new Vec3(playerX + Mth.clamp(dxCorner, -0.5, 0.5), y, playerZ + Mth.clamp(dzCorner, -0.5, 0.5));
      } else {
         double A = Math.PI / 13;
         double B = Math.PI / 4;
         double x = playerX
            + Mth.clamp(this.toClosest(playerX, Math.floor(playerX) + (Math.PI / 13), Math.floor(playerX) + (Math.PI / 4)) - playerX, -0.2, 0.2);
         double z = playerZ
            + Mth.clamp(this.toClosest(playerZ, Math.floor(playerZ) + (Math.PI / 13), Math.floor(playerZ) + (Math.PI / 4)) - playerZ, -0.2, 0.2);
         return new Vec3(x, y, z);
      }
   }

   private double toClosest(double num, double min, double max) {
      return num - min > max - num ? max : min;
   }

   private Vec3 calculateGrimSectorTarget() {
      double px = mc.player.getX();
      double pz = mc.player.getZ();
      double y = this.crawl.getValue() && this.isPlayerCrawling() ? mc.player.blockPosition().below().getY() : mc.player.getY() - 0.5;
      double floorX = Math.floor(px);
      double floorZ = Math.floor(pz);
      double centerZ = floorZ + 0.5;
      double centerX;
      double angle = Math.toDegrees(Math.atan2(pz - centerZ, px - (centerX = floorX + 0.5)));
      if (angle < 0.0) {
         angle += 360.0;
      }

      int sector = (int)Math.floor((angle + 22.5) / 45.0) & 7;
      double x1 = floorX + 1.0;
      double z1 = floorZ + 1.0;

      return switch (sector) {
         case 0 -> new Vec3(x1, y, centerZ);
         case 1 -> new Vec3(x1, y, z1);
         case 2 -> new Vec3(centerX, y, z1);
         case 3 -> new Vec3(floorX, y, z1);
         case 4 -> new Vec3(floorX, y, centerZ);
         case 5 -> new Vec3(floorX, y, floorZ);
         case 6 -> new Vec3(centerX, y, floorZ);
         default -> new Vec3(x1, y, floorZ);
      };
   }

   private Vec3 boundaryTarget(float yawDeg) {
      double px = mc.player.getX();
      double pz = mc.player.getZ();
      double y = this.crawl.getValue() && this.isPlayerCrawling() ? mc.player.blockPosition().below().getY() : mc.player.getY() - 0.5;
      double rad = Math.toRadians(yawDeg);
      Vec3 lookDir = new Vec3(-Math.sin(rad), 0.0, Math.cos(rad)).normalize();
      boolean zAxis = Math.abs(lookDir.z) > Math.abs(lookDir.x);
      if (zAxis) {
         double boundaryZ = lookDir.z > 0.0 ? Math.floor(pz) + 1.0 : Math.floor(pz);
         return new Vec3(px, y, boundaryZ);
      } else {
         double boundaryX = lookDir.x > 0.0 ? Math.floor(px) + 1.0 : Math.floor(px);
         return new Vec3(boundaryX, y, pz);
      }
   }

   private Vec3 getEffectiveEyePos() {
      if (mc.player == null) {
         return Vec3.ZERO;
      } else {
         double eyeY = mc.player.getEyeY() - 0.1;
         return new Vec3(mc.player.getX(), eyeY, mc.player.getZ());
      }
   }

   private float calcYaw(Vec3 target) {
      Vec3 eye = this.getEffectiveEyePos();
      Vec3 diff = target.subtract(eye);
      return (float)Math.toDegrees(Math.atan2(-diff.x, diff.z));
   }

   private float solvePitch(Vec3 target) {
      Vec3 eye = this.getEffectiveEyePos();
      double d = Math.hypot(target.x - eye.x, target.z - eye.z);
      double dy = target.y - eye.y;
      if (d < 1.0E-4) {
         return dy < 0.0 ? 85.0F : -85.0F;
      } else {
         double lo = -85.0;
         double hi = 89.9;

         for (int i = 0; i < 30; i++) {
            double mid = (lo + hi) * 0.5;
            double simY = simulatePearlYAtDist(mid, d);
            if (simY < dy) {
               hi = mid;
            } else {
               lo = mid;
            }
         }

         return (float)((lo + hi) * 0.5);
      }
   }

   private static double simulatePearlYAtDist(double pitchDeg, double targetDist) {
      double p = Math.toRadians(pitchDeg);
      double vh = 1.5 * Math.cos(p);
      double vy = -1.5 * Math.sin(p);
      double x = 0.0;
      double y = 0.0;

      for (int i = 0; i < 100; i++) {
         double prevX = x;
         double prevY = y;
         x += vh;
         y += vy;
         if (x >= targetDist) {
            double f = (targetDist - prevX) / (x - prevX);
            return prevY + (y - prevY) * f;
         }

         vh *= 0.99;
         vy = vy * 0.99 - 0.03;
      }

      return y;
   }

   private boolean isFloorVoid(double x, double y, double z) {
      if (mc.level == null) {
         return false;
      } else {
         int minY = mc.level.getMinY();
         int startY = (int)Math.floor(y);
         if (startY < minY) {
            return true;
         } else {
            for (int checkY = startY; checkY >= minY; checkY--) {
               BlockPos pos = BlockPos.containing(x, checkY, z);
               BlockState state = mc.level.getBlockState(pos);
               if (!state.isAir() && !state.getCollisionShape(mc.level, pos).isEmpty()) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   private boolean isVoidHazard(Vec3 target, float rawYaw) {
      if (mc.player != null && mc.level != null) {
         double px = mc.player.getX();
         double py = mc.player.getY();
         double pz = mc.player.getZ();
         int minY = mc.level.getMinY();
         if (py < minY) {
            return true;
         } else {
            double rad = Math.toRadians(rawYaw);
            Vec3 lookDir = new Vec3(-Math.sin(rad), 0.0, Math.cos(rad)).normalize();
            BlockPos targetPos = BlockPos.containing(target.x, target.y, target.z);
            BlockPos destPos = BlockPos.containing(px + lookDir.x * 0.5, py, pz + lookDir.z * 0.5);
            boolean targetHasFloor = !this.isFloorVoid(targetPos.getX() + 0.5, target.y, targetPos.getZ() + 0.5);
            boolean destHasFloor = !this.isFloorVoid(destPos.getX() + 0.5, py, destPos.getZ() + 0.5);
            return !targetHasFloor && !destHasFloor;
         }
      } else {
         return false;
      }
   }

   @Override
   public void onEnable() {
      if (mc.player != null && mc.level != null) {
         for (BlockPos scaffoldPosition : new BlockPos[]{mc.player.blockPosition(), mc.player.blockPosition().below()}) {
            if (mc.level.getBlockState(scaffoldPosition).is(Blocks.SCAFFOLDING)) {
               NetworkUtils.sendSequencedPacket(
                  sequence -> new ServerboundPlayerActionPacket(Action.START_DESTROY_BLOCK, scaffoldPosition, Direction.UP, sequence)
               );
               NetworkUtils.sendSequencedPacket(
                  sequence -> new ServerboundPlayerActionPacket(Action.STOP_DESTROY_BLOCK, scaffoldPosition, Direction.UP, sequence)
               );
               mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               mc.level.removeBlock(scaffoldPosition, false);
            }
         }

         boolean isKingMC = this.logic.getValue().equalsIgnoreCase("KingMC");
         boolean swimPose = this.isPlayerCrawling();
         if (!this.crawl.getValue() && swimPose && !isKingMC) {
            this.logPhaseOutcome("crawl_disabled");
            this.setToggled(false);
         } else {
            boolean isCrawling = this.crawl.getValue() && swimPose;
            boolean crawlSwimStuck = isCrawling && swimPose;
            boolean inCobweb = this.isInWeb(mc.player);
            boolean inLadder = this.isInLadder(mc.player);
            boolean inRail = mc.level.getBlockState(mc.player.blockPosition()).is(BlockTags.RAILS);
            if (inRail) {
               Night.LOGGER
                  .info(
                     "[PhaseRail] player={} position={} block={} logic={} event=attempt",
                     new Object[]{
                        mc.player.getName().getString(), mc.player.position(), mc.level.getBlockState(mc.player.blockPosition()), this.logic.getValue()
                     }
                  );
            }

            if (!crawlSwimStuck && !inCobweb && !inLadder && !inRail && !mc.level.getBlockState(mc.player.blockPosition()).canBeReplaced()) {
               this.logPhaseOutcome("current_block_not_replaceable");
               this.setToggled(false);
            } else if (mc.player.isCrouching()) {
               this.logPhaseOutcome("crouching");
               this.setToggled(false);
            } else if (mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))) {
               this.logPhaseOutcome("pearl_cooldown");
               this.setToggled(false);
            } else {
               MultiTaskModule multiTask = Night.MODULE_MANAGER.getModule(MultiTaskModule.class);
               boolean keepEating = multiTask != null && multiTask.isToggled() && multiTask.pearl.getValue() && mc.player.isUsingItem();
               boolean botPearl = BotPearlAccess.active();
               String pearlMode = botPearl ? BotPearlAccess.mode() : (keepEating ? "AltSwap" : this.swap.getValue());
               int slot = botPearl
                  ? BotPearlAccess.find(pearlMode)
                  : InventoryUtils.find(Items.ENDER_PEARL, 0, !pearlMode.equalsIgnoreCase("AltSwap") && !pearlMode.equalsIgnoreCase("AltPickup") ? 8 : 35);
               if (!botPearl && slot == -1 && !pearlMode.equalsIgnoreCase("AltSwap") && !pearlMode.equalsIgnoreCase("AltPickup")) {
                  slot = InventoryUtils.findInventory(Items.ENDER_PEARL);
                  if (slot != -1) {
                     pearlMode = "AltSwap";
                  }
               }

               int previousSlot = mc.player.getInventory().getSelectedSlot();
               boolean didPlaceBypass = false;
               if (slot == -1) {
                  Night.CHAT_MANAGER.tagged("No pearls could be found in your hotbar.", this.getName());
                  this.logPhaseOutcome("no_pearl");
                  this.setToggled(false);
               } else {
                  float prevYaw = mc.player.getYRot();
                  float prevPitch = mc.player.getXRot();
                  BlockPos downPosition = mc.player.blockPosition().below();
                  float rawYaw = Mth.wrapDegrees(this.getPhaseYaw());
                  float mod90 = (rawYaw % 90.0F + 90.0F) % 90.0F;
                  boolean nearCardinal = Math.min(mod90, 90.0F - mod90) < 22.5F;
                  boolean onBedrock = this.isOnBedrock();
                  boolean isGrim = this.logic.getValue().equalsIgnoreCase("Grim");
                  Vec3 target;
                  if (isKingMC && !onBedrock) {
                     target = isCrawling ? this.calculateKingMCCrawlTarget(rawYaw) : this.calculateKingMCStandingTarget(rawYaw);
                  } else if (isGrim) {
                     target = this.calculateGrimSectorTarget();
                  } else {
                     target = nearCardinal ? this.boundaryTarget(rawYaw) : this.calculateTargetPos();
                  }

                  if (this.antiVoid.getValue() && this.isVoidHazard(target, rawYaw)) {
                     Night.CHAT_MANAGER.tagged("Phase cancelled to prevent falling into the void.", this.getName());
                     if (mc.getSoundManager() != null) {
                        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_PLING, 1.5F));
                     }

                     this.logPhaseOutcome("anti_void");
                     this.setToggled(false);
                  } else {
                     float yaw = this.calcYaw(target);
                     float pitch = this.solvePitch(target);
                     if (this.debug.getValue()) {
                        this.attempt++;
                        Night.CHAT_MANAGER
                           .tagged(
                              String.format(
                                 "#%d [%s%s] pos=(%.4f, %.4f, %.4f) yaw=%.2f pitch=%.2f target=(%.4f, %.4f, %.4f) sector=%s",
                                 this.attempt,
                                 this.logic.getValue(),
                                 isKingMC && onBedrock ? "/Bedrock" : (isKingMC && isCrawling ? "/Crawl" : (isKingMC ? "/Standing" : "")),
                                 mc.player.getX(),
                                 mc.player.getY(),
                                 mc.player.getZ(),
                                 yaw,
                                 pitch,
                                 target.x,
                                 target.y,
                                 target.z,
                                 nearCardinal ? "straight" : "corner"
                              ),
                              this.getName()
                           );
                     }

                     if (this.logic.getValue().equalsIgnoreCase("NCP")
                        && (mc.level.getBlockState(mc.player.blockPosition()).isAir() || inCobweb || inLadder)
                        && !mc.level.getBlockState(downPosition).canBeReplaced()) {
                        String bypassSlot = this.ncpMode.getValue();

                        Item targetItem = switch (bypassSlot) {
                           case "FlintAndSteel" -> Items.FLINT_AND_STEEL;
                           case "Cobweb" -> Items.COBWEB;
                           default -> Items.FIRE_CHARGE;
                        };
                        int bypassSlot = InventoryUtils.find(
                           targetItem,
                           InventoryUtils.HOTBAR_START,
                           !this.bypassSwitch.getValue().equalsIgnoreCase("AltSwap") && !this.bypassSwitch.getValue().equalsIgnoreCase("AltPickup") ? 8 : 35
                        );
                        if (bypassSlot != -1) {
                           Night.ROTATION_MANAGER.packetRotate(yaw, 90.0F, true);
                           InventoryUtils.switchSlot(this.bypassSwitch.getValue(), bypassSlot, previousSlot);
                           NetworkUtils.sendSequencedPacket(
                              sequence -> new ServerboundUseItemOnPacket(
                                 InteractionHand.MAIN_HAND,
                                 new BlockHitResult(Vec3.atCenterOf(downPosition).add(0.0, 1.0, 0.0), Direction.UP, downPosition, false),
                                 sequence
                              )
                           );
                           mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                           InventoryUtils.switchBack(this.bypassSwitch.getValue(), bypassSlot, previousSlot);
                           didPlaceBypass = true;
                        }
                     }

                     Night.ROTATION_MANAGER.packetRotate(yaw, pitch, true);
                     if (InventoryUtils.switchSlot(pearlMode, slot, previousSlot)) {
                        NetworkUtils.sendSequencedPacket(sequence -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, sequence, yaw, pitch));
                        mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                        InventoryUtils.switchBack(pearlMode, slot, previousSlot);
                        this.logPhaseOutcome("use_packet_requested");
                     } else {
                        this.logPhaseOutcome("switch_failed");
                     }

                     if (didPlaceBypass && this.autoRemove.getValue()) {
                        NetworkUtils.sendSequencedPacket(
                           sequence -> new ServerboundPlayerActionPacket(Action.START_DESTROY_BLOCK, mc.player.blockPosition(), Direction.UP, sequence)
                        );
                        NetworkUtils.sendSequencedPacket(
                           sequence -> new ServerboundPlayerActionPacket(Action.STOP_DESTROY_BLOCK, mc.player.blockPosition(), Direction.UP, sequence)
                        );
                        mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                     }

                     this.setToggled(false);
                  }
               }
            }
         }
      } else {
         this.logPhaseOutcome("no_world");
         this.setToggled(false);
      }
   }

   private void logPhaseOutcome(String reason) {
      if (mc.player != null && mc.level != null && mc.level.getBlockState(mc.player.blockPosition()).is(BlockTags.RAILS)) {
         Night.LOGGER
            .info(
               "[PhaseRail] player={} reason={} position={} logic={}",
               new Object[]{mc.player.getName().getString(), reason, mc.player.position(), this.logic.getValue()}
            );
      }

      SoloBotModule bot = Night.MODULE_MANAGER.getModule(SoloBotModule.class);
      if (bot != null && bot.isToggled()) {
         Night.LOGGER
            .info(
               "[BotPhaseResult] player={} reason={} position={} logic={} switch={}",
               new Object[]{
                  mc.player == null ? "none" : mc.player.getName().getString(),
                  reason,
                  mc.player == null ? "none" : mc.player.position(),
                  this.logic.getValue(),
                  this.swap.getValue()
               }
            );
      }
   }
}
