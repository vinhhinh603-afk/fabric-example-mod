package night.modules.impl.movement;

import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ServerboundClientTickEndPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PacketSendEvent;
import night.managers.RotationManager;
import night.mixins.accessors.EntityAccessor;
import night.mixins.accessors.PlayerMoveC2SPacketAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.utils.EarlyTickHooks;

@RegisterModule(
   name = "AirStuck",
   description = "Legacy packet freeze or experimental V2 local hold with native packets.",
   category = Module.Category.MOVEMENT
)
public class AirStuckModule extends Module {
   public final BooleanSetting onlyWhenFalling;
   private Vec3 savedVelocity;
   private final Runnable earlyTickCallback;
   public final BooleanSetting allowRotation;
   private float mouseYaw;
   private float mousePitch;
   private float sentYaw;
   private float sentPitch;
   private boolean mouseLookValid;
   private boolean sentLook;
   private boolean sentGround;
   private boolean sentCollision;
   private boolean forwardingLook;
   private long lookAttempts;
   private long acceptedLooks;
   private long nextDiagnostic;
   public final BooleanSetting pearlMouseLook;
   public final ModeSetting mode = new ModeSetting(
      "Mode",
      "Legacy freezes packets. V2 holds local movement while preserving native packets; server corrections still apply.",
      "Legacy",
      new String[]{"Legacy", "V2"}
   );
   public final BooleanSetting debugV2;
   private boolean v2Active;
   private boolean modeWasNative;
   private long v2Moves;
   private long v2Rotations;
   private long v2TickEnds;
   private long v2Commands;
   private long nextV2Diagnostic;
   private volatile long v2Corrections;
   private volatile int v2LastCorrectionId;
   private float v2LastYaw;
   private float v2LastPitch;

   private static AirStuckModule instance() {
      return Night.MODULE_MANAGER == null ? null : Night.MODULE_MANAGER.getModule(AirStuckModule.class);
   }

   public static void localPlayerConstructed() {
      AirStuckModule module = instance();
      if (module != null && module.isToggled()) {
         module.setToggled(false, false);
      }
   }

   private void captureMouseLook() {
      if (!this.getNull() && !RotationManager.swapActive) {
         EntityAccessor var1 = (EntityAccessor)mc.player;
         float var2 = var1.getRawYRot();
         float var3 = var1.getRawXRot();
         if (Float.isFinite(var2) && Float.isFinite(var3)) {
            this.mouseYaw = var2;
            this.mousePitch = var3;
            this.mouseLookValid = true;
         }
      }
   }

   private void sendMouseLook(boolean var1, boolean var2) {
      if (this.mouseLookValid && mc.getConnection() != null) {
         if (!this.sentLook || this.sentYaw != this.mouseYaw || this.sentPitch != this.mousePitch || this.sentGround != var1 || this.sentCollision != var2) {
            this.lookAttempts++;
            this.forwardingLook = true;

            try {
               mc.getConnection().send(new Rot(this.mouseYaw, this.mousePitch, var1, var2));
            } finally {
               this.forwardingLook = false;
            }
         }
      }
   }

   @SubscribeEvent
   public void onMouseLookSent(PacketSendEvent.Post var1) {
      if (this.forwardingLook && var1.getPacket() instanceof Rot var2) {
         this.sentYaw = var2.getYRot(0.0F);
         this.sentPitch = var2.getXRot(0.0F);
         this.sentGround = var2.isOnGround();
         this.sentCollision = var2.horizontalCollision();
         this.sentLook = true;
         this.acceptedLooks++;
      }
   }

   private void logLook(String var1) {
      System.out
         .println(
            "[AirStuckRotation] "
               + var1
               + " allowRotation="
               + this.allowRotation.getValue()
               + " active="
               + this.isActive()
               + " swap="
               + RotationManager.swapActive
               + " mouse="
               + this.mouseYaw
               + ","
               + this.mousePitch
               + " lastAccepted="
               + this.sentYaw
               + ","
               + this.sentPitch
               + " attempts="
               + this.lookAttempts
               + " acceptedByClient="
               + this.acceptedLooks
         );
   }

   private void sendPearlLook(ServerboundUseItemPacket var1) {
      if (this.pearlMouseLook.getValue() && !this.forwardingLook && mc.getConnection() != null) {
         ItemStack var2;
         if (var1.getHand() == InteractionHand.OFF_HAND) {
            var2 = mc.player.getOffhandItem();
         } else {
            int var3 = Night.POSITION_MANAGER == null ? -1 : Night.POSITION_MANAGER.getServerSlot();
            var2 = var3 >= 0 && var3 <= 8 ? mc.player.getInventory().getItem(var3) : mc.player.getMainHandItem();
         }

         if (var2.getItem() == Items.ENDER_PEARL && !mc.player.getCooldowns().isOnCooldown(var2)) {
            float var8 = var1.getYRot();
            float var4 = var1.getXRot();
            if (Float.isFinite(var8) && Float.isFinite(var4) && !(var4 < -90.0F) && !(var4 > 90.0F)) {
               this.lookAttempts++;
               this.forwardingLook = true;

               try {
                  mc.getConnection().send(new Rot(var8, var4, mc.player.onGround(), mc.player.horizontalCollision));
               } finally {
                  this.forwardingLook = false;
               }

               System.out
                  .println(
                     "[AirStuckPearlLook] hand="
                        + var1.getHand()
                        + " sequence="
                        + var1.getSequence()
                        + " yaw="
                        + var8
                        + " pitch="
                        + var4
                        + " allowRotation="
                        + this.allowRotation.getValue()
                        + " clientAcceptedCount="
                        + this.acceptedLooks
                  );
            }
         }
      }
   }

   public AirStuckModule() {
      this.onlyWhenFalling = new BooleanSetting("Only When Falling", "Only captures velocity while falling.", false);
      this.allowRotation = new BooleanSetting(
         "AllowRotation", "Legacy: send your mouse look each tick when it changes.", new ModeSetting.Visibility(this.mode, "Legacy"), true
      );
      this.pearlMouseLook = new BooleanSetting(
         "PearlMouseLook",
         "Legacy: send the throw view before using a pearl, even when AllowRotation is OFF.",
         new ModeSetting.Visibility(this.mode, "Legacy"),
         true
      );
      this.debugV2 = new BooleanSetting(
         "DebugV2",
         "Log local hold, native packet counts and correction IDs at most once per second; this is not server acceptance.",
         new ModeSetting.Visibility(this.mode, "V2"),
         false
      );
      this.v2LastCorrectionId = -1;
      this.savedVelocity = Vec3.ZERO;
      this.earlyTickCallback = this::onEarlyTick;
   }

   @Override
   public void onEnable() {
      this.mouseLookValid = false;
      this.sentLook = false;
      this.lookAttempts = 0L;
      this.acceptedLooks = 0L;
      this.nextDiagnostic = 0L;
      this.v2Active = false;
      this.modeWasNative = this.isNativeMode();
      this.resetV2Diagnostics();
      this.syncMode();
      if (this.isNativeMode()) {
         EarlyTickHooks.register(this.earlyTickCallback);
      } else {
         this.captureMouseLook();
         System.out.println("[AirStuckRotation] ENABLE allowRotation=" + this.allowRotation.getValue());
         EarlyTickHooks.register(this.earlyTickCallback);
      }
   }

   @Override
   public void onDisable() {
      if (!this.isNativeMode() && !this.modeWasNative) {
         this.logLook("DISABLE");
      }

      this.mouseLookValid = false;
      this.sentLook = false;
      EarlyTickHooks.unregister(this.earlyTickCallback);
      if (!this.isNativeMode() && !this.modeWasNative && !this.getNull() && !this.savedVelocity.equals(Vec3.ZERO)) {
         mc.player.setDeltaMovement(this.savedVelocity);
      }

      this.savedVelocity = Vec3.ZERO;
      this.v2Active = false;
      this.forwardingLook = false;
      this.resetV2Diagnostics();
   }

   private void onEarlyTick() {
      if (this.isToggled() && !this.getNull()) {
         this.syncMode();
         if (this.isNativeMode()) {
            if (this.debugV2.getValue()) {
               this.logV2();
            }
         } else {
            this.captureMouseLook();
            if ((!this.onlyWhenFalling.getValue() || !(mc.player.fallDistance <= 0.0)) && this.savedVelocity.equals(Vec3.ZERO) && !mc.player.isSprinting()) {
               this.savedVelocity = mc.player.getDeltaMovement();
            }

            if (this.isActive() && this.allowRotation.getValue()) {
               this.sendMouseLook(mc.player.onGround(), mc.player.horizontalCollision);
            }

            long var1 = System.currentTimeMillis();
            if (var1 >= this.nextDiagnostic) {
               this.nextDiagnostic = var1 + 1000L;
               this.logLook("TICK");
            }
         }
      } else {
         this.v2Active = false;
      }
   }

   private boolean isActive() {
      if (this.isToggled() && !this.getNull()) {
         this.syncMode();
         return this.isNativeMode() ? this.v2Active : !this.savedVelocity.equals(Vec3.ZERO);
      } else {
         this.v2Active = false;
         return false;
      }
   }

   private boolean isNativeMode() {
      return "V2".equals(this.mode.getValue());
   }

   private void syncMode() {
      boolean var1 = this.isNativeMode();
      if (var1 != this.modeWasNative) {
         this.savedVelocity = Vec3.ZERO;
         this.v2Active = false;
         this.mouseLookValid = false;
         this.sentLook = false;
         this.forwardingLook = false;
         this.resetV2Diagnostics();
         this.modeWasNative = var1;
      }

      if (var1 && !this.v2Active && !this.getNull() && (!this.onlyWhenFalling.getValue() || mc.player.fallDistance > 0.0)) {
         this.v2Active = true;
      }
   }

   private void resetV2Diagnostics() {
      this.v2Moves = 0L;
      this.v2Rotations = 0L;
      this.v2TickEnds = 0L;
      this.v2Commands = 0L;
      this.v2Corrections = 0L;
      this.v2LastCorrectionId = -1;
      this.v2LastYaw = 0.0F;
      this.v2LastPitch = 0.0F;
      this.nextV2Diagnostic = 0L;
   }

   private void logV2() {
      long var1 = System.currentTimeMillis();
      if (var1 >= this.nextV2Diagnostic) {
         this.nextV2Diagnostic = var1 + 1000L;
         System.out
            .println(
               "[AirStuckV2] active="
                  + this.v2Active
                  + " local="
                  + mc.player.getX()
                  + ","
                  + mc.player.getY()
                  + ","
                  + mc.player.getZ()
                  + " observedMoves="
                  + this.v2Moves
                  + " observedRotations="
                  + this.v2Rotations
                  + " lastObservedAim="
                  + this.v2LastYaw
                  + ","
                  + this.v2LastPitch
                  + " observedTickEnds="
                  + this.v2TickEnds
                  + " observedCommands="
                  + this.v2Commands
                  + " observedCorrections="
                  + this.v2Corrections
                  + " lastCorrectionId="
                  + this.v2LastCorrectionId
            );
      }
   }

   @SubscribeEvent
   public void onV2PacketReceive(PacketReceiveEvent var1) {
      if (this.isToggled() && !this.getNull() && this.isNativeMode() && this.v2Active && this.debugV2.getValue()) {
         if (var1.getPacket() instanceof ClientboundPlayerPositionPacket var2) {
            this.v2Corrections++;
            this.v2LastCorrectionId = var2.id();
         }
      }
   }

   @SubscribeEvent(
      priority = Integer.MAX_VALUE
   )
   public void onPacketSend(PacketSendEvent var1) {
      if (this.isActive()) {
         Packet var2 = var1.getPacket();
         if (this.isNativeMode()) {
            if (this.debugV2.getValue()) {
               if (var2 instanceof ServerboundMovePlayerPacket var6) {
                  this.v2Moves++;
                  if (var6.hasRotation()) {
                     this.v2Rotations++;
                     this.v2LastYaw = var6.getYRot(0.0F);
                     this.v2LastPitch = var6.getXRot(0.0F);
                  }
               } else if (var2 instanceof ServerboundClientTickEndPacket) {
                  this.v2TickEnds++;
               } else if (var2 instanceof ServerboundPlayerCommandPacket) {
                  this.v2Commands++;
               }
            }
         } else if (var2 instanceof ServerboundUseItemPacket var5) {
            if (!var1.isCancelled()) {
               this.sendPearlLook(var5);
            }
         } else if (var2 instanceof ServerboundMovePlayerPacket var3) {
            if (!this.forwardingLook || !(var2 instanceof Rot)) {
               if (this.allowRotation.getValue() && var3.hasRotation()) {
                  this.captureMouseLook();
                  if (this.mouseLookValid) {
                     PlayerMoveC2SPacketAccessor var4 = (PlayerMoveC2SPacketAccessor)var3;
                     var4.setYaw(this.mouseYaw);
                     var4.setPitch(this.mousePitch);
                  }
               }

               var1.setCancelled(true);
            }
         } else {
            if (var2 instanceof ServerboundClientTickEndPacket || var2 instanceof ServerboundPlayerCommandPacket) {
               var1.setCancelled(true);
            }
         }
      }
   }

   public static Vec3 movementDisplacement(Vec3 var0) {
      AirStuckModule var1 = instance();
      if (var1 != null && var1.isActive()) {
         return var1.isNativeMode() ? Vec3.ZERO : new Vec3(0.0, -1.0E-10, 0.0);
      } else {
         return var0;
      }
   }
}
