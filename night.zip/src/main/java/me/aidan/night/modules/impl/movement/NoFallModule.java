package night.modules.impl.movement;

import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import night.events.SubscribeEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.PlayerUpdateEvent;
import night.mixins.accessors.PlayerMoveC2SPacketAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.ModeSetting;

@RegisterModule(
   name = "NoFall",
   description = "Prevents you from taking fall damage.",
   category = Module.Category.MOVEMENT
)
public class NoFallModule extends Module {
   public ModeSetting mode = new ModeSetting("Mode", "The method that will be used in preventing fall damage.", "Packet", new String[]{"Packet", "Grim"});

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (this.isFalling()) {
         if (this.mode.getValue().equalsIgnoreCase("Grim")) {
            mc.getConnection()
               .send(
                  new PosRot(
                     mc.player.getX(),
                     mc.player.getY() + 1.0E-9,
                     mc.player.getZ(),
                     mc.player.getYRot(),
                     mc.player.getXRot(),
                     false,
                     mc.player.horizontalCollision
                  )
               );
            mc.player.resetFallDistance();
         }
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.mode.getValue().equalsIgnoreCase("Packet")) {
            if (event.getPacket() instanceof ServerboundMovePlayerPacket packet2 && this.isFalling()) {
               ((PlayerMoveC2SPacketAccessor)packet2).setOnGround(true);
            }
         }
      }
   }

   @Override
   public String getMetaData() {
      return this.mode.getValue();
   }

   private boolean isFalling() {
      return mc.player.fallDistance > mc.player.getAttributeValue(Attributes.SAFE_FALL_DISTANCE) && !mc.player.onGround() && !mc.player.isFallFlying();
   }
}
