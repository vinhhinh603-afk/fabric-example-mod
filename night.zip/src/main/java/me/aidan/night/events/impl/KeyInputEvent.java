package night.events.impl;

import lombok.Generated;
import night.events.Event;

public class KeyInputEvent extends Event {
   private final int key;
   private final int modifiers;

   @Generated
   @Override
   public boolean equals(Object o) {
      if (o == this) {
         return true;
      } else if (!(o instanceof KeyInputEvent other)) {
         return false;
      } else if (!other.canEqual(this)) {
         return false;
      } else if (!super.equals(o)) {
         return false;
      } else {
         return this.getKey() != other.getKey() ? false : this.getModifiers() == other.getModifiers();
      }
   }

   @Generated
   @Override
   protected boolean canEqual(Object other) {
      return other instanceof KeyInputEvent;
   }

   @Generated
   @Override
   public int hashCode() {
      int PRIME = 59;
      int result = super.hashCode();
      result = result * 59 + this.getKey();
      return result * 59 + this.getModifiers();
   }

   @Generated
   public KeyInputEvent(int key, int modifiers) {
      this.key = key;
      this.modifiers = modifiers;
   }

   @Generated
   public int getKey() {
      return this.key;
   }

   @Generated
   public int getModifiers() {
      return this.modifiers;
   }

   @Generated
   @Override
   public String toString() {
      return "KeyInputEvent(key=" + this.getKey() + ", modifiers=" + this.getModifiers() + ")";
   }
}
