package night.events.impl;

import night.events.Event;

public class GameLoopEvent extends Event {
}
