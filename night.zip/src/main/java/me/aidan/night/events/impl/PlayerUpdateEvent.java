package night.events.impl;

import night.events.Event;

public class PlayerUpdateEvent extends Event {
   public static class Peri extends Event {
   }

   public static class Post extends Event {
   }
}
