package night.events.impl;

import night.events.Event;

public class UpdateMovementEvent extends Event {
   public static class Post extends Event {
   }
}
